"""Git commands that HIT also supports: show, blame, revert, cherry-pick,
mv, clean, gc, fsck and the plumbing-style helpers (ls-files, ls-tree,
rev-parse, describe, shortlog, count-objects).

Everything here works on the same .hit (or .git) repository as the rest of HIT.
"""
from __future__ import annotations

import difflib
import os
import shutil
from pathlib import Path
from typing import TYPE_CHECKING

from . import output as o
from .diff import is_binary, tree_changes, unified
from .index import IndexEntry
from .objects import Commit, flatten_tree, hash_object
from .repo import HitError

if TYPE_CHECKING:
    from .repo import Repository


# --------------------------------------------------------------------------
# show
# --------------------------------------------------------------------------

def show(repo: "Repository", rev: str = "HEAD", stat_only: bool = False,
         name_only: bool = False) -> None:
    """Show one commit: metadata plus the changes it introduced."""
    sha = repo.resolve(rev)
    cm = repo.store.read_commit(sha)
    parent_files = repo.commit_files(cm.parents[0]) if cm.parents else {}
    files = repo.commit_files(sha)
    changes = tree_changes(parent_files, files)

    import datetime
    o.say(o.yellow(f"commit {cm.sha}") + ("" if not cm.parents else ""))
    if len(cm.parents) > 1:
        o.field("merge", " ".join(p[:7] for p in cm.parents))
    o.field("author", f"{cm.author} <{cm.author_email}>")
    o.field("date", datetime.datetime.fromtimestamp(cm.author_time).strftime("%a %b %d %H:%M:%S %Y")
            + "  " + o.dim(o.relative_time(cm.commit_time)))
    o.blank()
    for line in cm.message.rstrip("\n").split("\n"):
        o.say("    " + line)
    o.blank()

    counts: dict[str, int] = {}
    for ch in changes:
        counts[ch.status] = counts.get(ch.status, 0) + 1
    o.field("files", f"{len(changes)} changed" + (f"  {o.DOT}  " + o.summary_counts(counts) if counts else ""))
    o.blank()

    if name_only:
        for ch in changes:
            o.say(ch.path)
        return
    if stat_only:
        o.file_list([(ch.status, ch.path) for ch in changes], limit=10_000)
        return

    for ch in changes:
        a = repo.store.read_blob(ch.old_sha) if ch.old_sha else b""
        b = repo.store.read_blob(ch.new_sha) if ch.new_sha else b""
        _print_file_diff(ch.path, ch.status, a, b)


def _print_file_diff(path: str, status: str, a: bytes, b: bytes) -> None:
    o.say(o.bold(f"── {path} ") + o.dim("─" * max(0, 60 - len(path))))
    if status == "A":
        o.say(o.green("   (new file)"))
    elif status == "D":
        o.say(o.red("   (deleted)"))
    text = unified(a, b, f"a/{path}", f"b/{path}")
    for line in text.splitlines():
        if line.startswith(("--- ", "+++ ")):
            continue
        if line.startswith("+"):
            o.say(o.green(line))
        elif line.startswith("-"):
            o.say(o.red(line))
        elif line.startswith("@@"):
            o.say(o.cyan(line))
        else:
            o.say(line)


# --------------------------------------------------------------------------
# plumbing-style helpers
# --------------------------------------------------------------------------

def ls_files(repo: "Repository", show_status: bool = False) -> None:
    paths = repo.index.paths()
    if not paths:
        o.info("no files are tracked yet")
        return
    for p in paths:
        if show_status:
            e = repo.index.get(p)
            o.say(f"{e.sha[:7]}  {p}")
        else:
            o.say(p)


def ls_tree(repo: "Repository", rev: str = "HEAD", recursive: bool = True) -> None:
    sha = repo.resolve(rev)
    files = repo.commit_files(sha)
    if not files:
        o.info("that commit has no files")
        return
    rows = [[o.dim(f"{mode:06o}"), o.dim(blob[:7]), path] for path, (mode, blob) in sorted(files.items())]
    o.table(["mode", "object", "path"], rows)


def rev_parse(repo: "Repository", revs: list[str]) -> None:
    for rev in revs or ["HEAD"]:
        o.say(repo.resolve(rev))


def describe(repo: "Repository", rev: str = "HEAD") -> None:
    """Nearest tag that is an ancestor of rev, plus the distance."""
    sha = repo.resolve(rev)
    tags: dict[str, str] = {}
    for name, tsha in repo.refs.tags().items():
        try:
            tags[repo.store.read_commit(tsha).sha] = name
        except Exception:
            continue
    if not tags:
        raise HitError("no tags in this repository", "create one with `hit tag v1.0`")
    distance = 0
    cur = sha
    while True:
        if cur in tags:
            name = tags[cur]
            o.say(name if distance == 0 else f"{name}-{distance}-g{sha[:7]}")
            return
        cm = repo.store.read_commit(cur)
        if not cm.parents:
            raise HitError("no tag found on this history")
        cur = cm.parents[0]
        distance += 1


def shortlog(repo: "Repository") -> None:
    """Commit counts per author, like `git shortlog -sn`."""
    commits = repo.log(limit=100_000)
    if not commits:
        o.info("no commits yet")
        return
    counts: dict[str, int] = {}
    for cm in commits:
        counts[f"{cm.author} <{cm.author_email}>"] = counts.get(f"{cm.author} <{cm.author_email}>", 0) + 1
    rows = [[str(n), who] for who, n in sorted(counts.items(), key=lambda kv: -kv[1])]
    o.table(["commits", "author"], rows)
    o.blank()
    o.field("total", f"{len(commits)} {o.plural(len(commits), 'commit')} by {len(counts)} {o.plural(len(counts), 'author')}")


def count_objects(repo: "Repository") -> None:
    shas = repo.store.all_shas()
    size = 0
    for root, _dirs, files in os.walk(repo.store.dir):
        for f in files:
            try:
                size += (Path(root) / f).stat().st_size
            except OSError:
                pass
    o.ok(f"{len(shas)} {o.plural(len(shas), 'object')} in the store")
    o.field("size", o.human_size(size))
    o.field("commits", str(len(repo.log(limit=100_000)) if repo.refs.head() else 0))


# --------------------------------------------------------------------------
# blame
# --------------------------------------------------------------------------

def blame(repo: "Repository", path: str) -> None:
    """Show which commit last changed each line of a file."""
    rel = repo.rel(path)
    history = [c for c in reversed(repo.log(limit=100_000)) if _touches(repo, c, rel)]
    if not history:
        raise HitError(f"'{rel}' is not in any commit", "commit it first, or check the path")

    attribution: list[Commit] = []
    previous: list[str] = []
    for cm in history:
        files = repo.commit_files(cm.sha)
        if rel not in files:
            previous, attribution = [], []
            continue
        data = repo.store.read_blob(files[rel][1])
        if is_binary(data):
            raise HitError(f"'{rel}' is a binary file — blame needs text")
        lines = data.decode("utf-8", "replace").splitlines()
        new_attr: list[Commit] = [cm] * len(lines)
        for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, previous, lines, autojunk=False).get_opcodes():
            if tag == "equal":
                for k in range(j2 - j1):
                    new_attr[j1 + k] = attribution[i1 + k]
        previous, attribution = lines, new_attr

    width = max((len(f"{c.author}") for c in attribution), default=6)
    for i, (line, cm) in enumerate(zip(previous, attribution), 1):
        o.say(f"{o.yellow(cm.short)} ({cm.author.ljust(width)} {o.dim(o.relative_time(cm.commit_time)):>9}) "
              f"{o.dim(str(i).rjust(4))} {line}")


def _touches(repo: "Repository", cm: Commit, rel: str) -> bool:
    files = repo.commit_files(cm.sha)
    parent = repo.commit_files(cm.parents[0]) if cm.parents else {}
    return files.get(rel) != parent.get(rel)


# --------------------------------------------------------------------------
# revert / cherry-pick
# --------------------------------------------------------------------------

def revert(repo: "Repository", rev: str, message: str | None = None) -> Commit:
    """Create a new commit that undoes the changes of `rev` (history is kept)."""
    sha = repo.resolve(rev)
    cm = repo.store.read_commit(sha)
    target = repo.commit_files(sha)
    base = repo.commit_files(cm.parents[0]) if cm.parents else {}
    current = repo.index.as_tree_files()

    new = dict(current)
    conflicts: list[str] = []
    for ch in tree_changes(base, target):
        cur = current.get(ch.path)
        if ch.status == "A":
            if cur and cur[1] != ch.new_sha:
                conflicts.append(ch.path)
            new.pop(ch.path, None)
        elif ch.status == "D":
            new[ch.path] = (ch.old_mode, ch.old_sha)
        else:  # M -> put the old content back
            if cur and cur[1] != ch.new_sha:
                conflicts.append(ch.path)
            new[ch.path] = (ch.old_mode, ch.old_sha)
    if conflicts:
        o.warn(f"{len(conflicts)} {o.plural(len(conflicts), 'file')} changed since that commit; "
               "the older version is being restored")
        o.file_list([("M", p) for p in conflicts])
    repo.checkout_tree(new, force=True)
    return repo.commit(message or f'Revert "{cm.summary}"\n\nThis reverts commit {sha}.')


def cherry_pick(repo: "Repository", rev: str, message: str | None = None) -> Commit:
    """Apply the changes of `rev` on top of the current branch."""
    from .merge import merge_blobs
    sha = repo.resolve(rev)
    cm = repo.store.read_commit(sha)
    target = repo.commit_files(sha)
    base = repo.commit_files(cm.parents[0]) if cm.parents else {}
    current = repo.index.as_tree_files()

    new = dict(current)
    conflicts: list[str] = []
    for ch in tree_changes(base, target):
        cur = current.get(ch.path)
        if ch.status == "D":
            new.pop(ch.path, None)
            continue
        if cur is None or cur[1] == (ch.old_sha or ""):
            new[ch.path] = (ch.new_mode, ch.new_sha)
            continue
        merged, conflict = merge_blobs(
            repo.store.read_blob(ch.old_sha) if ch.old_sha else b"",
            repo.store.read_blob(cur[1]),
            repo.store.read_blob(ch.new_sha),
            repo.refs.current_branch() or "HEAD", cm.short)
        new[ch.path] = (ch.new_mode, repo.store.write_blob(merged))
        if conflict:
            conflicts.append(ch.path)
    repo.checkout_tree(new, force=True)
    if conflicts:
        o.warn(f"{len(conflicts)} {o.plural(len(conflicts), 'file')} need your attention "
               "(conflict markers were written)")
        o.file_list([("C", p) for p in conflicts])
        o.hint("edit the files, then `hit add <file>` and `hit commit`")
        raise HitError("cherry-pick stopped because of conflicts")
    return repo.commit(message or cm.message)


# --------------------------------------------------------------------------
# mv / clean
# --------------------------------------------------------------------------

def move(repo: "Repository", sources: list[str], destination: str) -> list[tuple[str, str]]:
    """Rename or move tracked files, updating the staging area."""
    dest = Path(destination)
    dest_abs = dest if dest.is_absolute() else Path.cwd() / dest
    moved: list[tuple[str, str]] = []
    into_dir = dest_abs.is_dir() or len(sources) > 1
    if into_dir:
        dest_abs.mkdir(parents=True, exist_ok=True)
    for src in sources:
        src_rel = repo.rel(src)
        src_abs = repo.root / src_rel
        if not src_abs.exists():
            raise HitError(f"'{src}' does not exist")
        target_abs = (dest_abs / src_abs.name) if into_dir else dest_abs
        target_rel = repo.rel(target_abs)
        if target_abs.exists():
            raise HitError(f"'{target_rel}' already exists")
        target_abs.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src_abs), str(target_abs))
        entry = repo.index.get(src_rel)
        if entry:
            repo.index.remove(src_rel)
            sha, mode = repo._hash_file(target_rel)
            repo.index.add(IndexEntry.from_file(repo.root, target_rel, sha, mode))
        moved.append((src_rel, target_rel))
    repo.index.save()
    return moved


def clean(repo: "Repository", dry_run: bool = True, directories: bool = False) -> list[str]:
    """Find (and optionally delete) files HIT does not track."""
    st = repo.status()
    targets = list(st.untracked)
    if not dry_run:
        for rel in targets:
            p = repo.root / rel
            if p.exists():
                p.unlink()
                repo._prune_empty_dirs(p.parent)
    return targets


# --------------------------------------------------------------------------
# maintenance
# --------------------------------------------------------------------------

def gc(repo: "Repository") -> tuple[int, int]:
    """Pack loose objects to save space. Returns (before, after) object counts."""
    before = len(repo.store.all_shas())
    try:
        from dulwich.repo import Repo as DRepo
        (repo.hit_dir / "objects" / "pack").mkdir(parents=True, exist_ok=True)
        drepo = DRepo(str(repo.root), controldir=str(repo.hit_dir))
        drepo.object_store.pack_loose_objects()
    except Exception as e:  # noqa: BLE001
        raise HitError(f"could not pack objects: {e}")
    repo.store._packs = None
    after = len(repo.store.all_shas())
    return before, after


def repair_line_endings(repo: "Repository") -> int:
    """Rewrite ref/HEAD files that an older HIT saved with Windows (CRLF) line
    endings. Content is unchanged; only the line ending. Returns files fixed."""
    fixed = 0
    candidates = [repo.hit_dir / n for n in ("HEAD", "ORIG_HEAD", "MERGE_HEAD", "PREV_HEAD", "packed-refs")]
    refs_dir = repo.hit_dir / "refs"
    if refs_dir.exists():
        candidates += [p for p in refs_dir.rglob("*") if p.is_file()]
    for p in candidates:
        try:
            data = p.read_bytes()
        except OSError:
            continue
        if b"\r\n" in data:
            p.write_bytes(data.replace(b"\r\n", b"\n"))
            fixed += 1
    return fixed


def fsck(repo: "Repository") -> tuple[int, list[str]]:
    """Verify every object hashes correctly and every reference resolves."""
    problems: list[str] = []
    shas = repo.store.all_shas()

    def verify(sha: str) -> str | None:
        try:
            kind, body = repo.store.read(sha)
        except Exception as e:  # noqa: BLE001
            return f"unreadable object {sha[:7]}: {e}"
        if hash_object(kind, body) != sha:
            return f"corrupt object {sha[:7]} ({kind})"
        return None

    from concurrent.futures import ThreadPoolExecutor
    from .repo import WORKERS
    with ThreadPoolExecutor(max_workers=WORKERS) as pool:
        results = list(pool.map(verify, shas))
    checked = sum(1 for r in results if r is None or not r.startswith("unreadable"))
    problems += [r for r in results if r]
    for name, sha in {**repo.refs.branches(), **repo.refs.tags()}.items():
        try:
            repo.store.read(sha)
        except Exception:
            problems.append(f"ref '{name}' points at missing object {sha[:7]}")
    head = repo.refs.head()
    if head:
        try:
            for cm in repo.log(limit=100_000):
                flatten_tree(repo.store, cm.tree)
        except Exception as e:  # noqa: BLE001
            problems.append(f"history is not fully readable: {e}")
    return checked, problems
