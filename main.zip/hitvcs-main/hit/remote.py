"""Push / pull / clone with GitHub (or any Git server) using Dulwich.

The on-disk format is Git's, so Dulwich can open .hit/ directly as a Git
control directory. Network is touched only here, and only when the user
explicitly runs push / pull / fetch / clone.
"""
from __future__ import annotations

import base64
import json
import os
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING
from urllib.parse import urlparse

from .repo import HitError, global_hit_dir

if TYPE_CHECKING:
    from .repo import Repository


# --------------------------------------------------------------------------
# Credentials (stored locally, only ever sent to the host they belong to)
# --------------------------------------------------------------------------

def _cred_file() -> Path:
    return global_hit_dir() / "credentials.json"


def _obscure(s: str) -> str:
    return base64.b64encode(s.encode()).decode()


def _reveal(s: str) -> str:
    return base64.b64decode(s.encode()).decode()


def save_credential(host: str, username: str, token: str) -> None:
    creds = _load_creds()
    creds[host] = {"username": username, "token": _obscure(token)}
    try:
        import keyring  # optional, nicer
        keyring.set_password(f"hit:{host}", username, token)
        creds[host]["token"] = "keyring"
    except Exception:
        pass
    _cred_file().write_text(json.dumps(creds, indent=2))
    try:
        os.chmod(_cred_file(), 0o600)
    except OSError:
        pass


def _load_creds() -> dict:
    f = _cred_file()
    if not f.exists():
        return {}
    try:
        return json.loads(f.read_text())
    except json.JSONDecodeError:
        return {}


def get_credential(host: str) -> tuple[str, str] | None:
    c = _load_creds().get(host)
    if not c:
        env = os.environ.get("HIT_TOKEN") or os.environ.get("GITHUB_TOKEN")
        if env:
            return (os.environ.get("HIT_USERNAME", "x-access-token"), env)
        return None
    if c["token"] == "keyring":
        try:
            import keyring
            tok = keyring.get_password(f"hit:{host}", c["username"])
            if tok:
                return c["username"], tok
        except Exception:
            return None
        return None
    return c["username"], _reveal(c["token"])


def delete_credential(host: str) -> bool:
    creds = _load_creds()
    if host in creds:
        del creds[host]
        _cred_file().write_text(json.dumps(creds, indent=2))
        return True
    return False


def host_of(url: str) -> str:
    if url.startswith("git@"):
        return url[4:].split(":")[0]
    return urlparse(url).hostname or url


# --------------------------------------------------------------------------
# Remotes config
# --------------------------------------------------------------------------

def get_remote(repo: "Repository", name: str = "origin") -> str | None:
    return repo.config.get(f'remote "{name}"', "url")


def set_remote(repo: "Repository", name: str, url: str) -> None:
    url = normalize_url(url)
    repo.config.set(f'remote "{name}"', "url", url, repo.hit_dir / "config")
    repo.config.set(f'remote "{name}"', "fetch", f"+refs/heads/*:refs/remotes/{name}/*", repo.hit_dir / "config")


def list_remotes(repo: "Repository") -> dict[str, str]:
    out = {}
    for section in repo.config.cp.sections():
        m = re.match(r'^remote "(.+)"$', section)
        if m:
            out[m.group(1)] = repo.config.cp.get(section, "url", fallback="")
    return out


def remove_remote(repo: "Repository", name: str) -> bool:
    section = f'remote "{name}"'
    if repo.config.cp.has_section(section):
        import configparser
        cp = configparser.ConfigParser()
        cp.read(str(repo.hit_dir / "config"))
        cp.remove_section(section)
        with open(repo.hit_dir / "config", "w", newline="\n") as f:
            cp.write(f)
        repo.config.cp.remove_section(section)
        return True
    return False


def web_url(url: str | None) -> str | None:
    """Turn a push URL into a browsable one (GitHub https only)."""
    if not url:
        return None
    if url.startswith("git@github.com:"):
        url = "https://github.com/" + url[len("git@github.com:"):]
    if url.startswith("https://github.com/"):
        return url[:-4] if url.endswith(".git") else url
    return None


@dataclass
class SyncState:
    connected: bool
    url: str | None
    web: str | None
    pushed: bool            # local branch head is on the remote
    ahead: int              # local commits not on the remote
    remote_sha: str | None
    branch: str | None

    @property
    def label(self) -> str:
        if not self.connected:
            return "not connected to GitHub"
        if self.remote_sha is None:
            return "never pushed"
        if self.pushed:
            return "pushed to GitHub"
        return f"{self.ahead} commit(s) not pushed"


def sync_state(repo: "Repository", remote: str = "origin") -> SyncState:
    url = get_remote(repo, remote)
    branch = repo.refs.current_branch()
    head = repo.refs.head()
    if not url or not branch or not head:
        return SyncState(bool(url), url, web_url(url), False, 0, None, branch)
    remote_sha = repo.refs.read(f"refs/remotes/{remote}/{branch}")
    if not remote_sha:
        return SyncState(True, url, web_url(url), False, len(repo.log()), None, branch)
    if remote_sha == head:
        return SyncState(True, url, web_url(url), True, 0, remote_sha, branch)
    try:
        remote_anc = repo.ancestors(remote_sha)
    except Exception:
        remote_anc = set()
    ahead = sum(1 for c in repo.log() if c.sha not in remote_anc)
    return SyncState(True, url, web_url(url), head in remote_anc, ahead, remote_sha, branch)


def normalize_url(url: str) -> str:
    url = url.strip()
    # "user/repo" shorthand -> GitHub
    if re.match(r"^[\w.-]+/[\w.-]+$", url):
        url = f"https://github.com/{url}"
    if url.startswith("https://github.com/") and not url.endswith(".git"):
        url = url.rstrip("/") + ".git"
    return url


# --------------------------------------------------------------------------
# Dulwich glue
# --------------------------------------------------------------------------

def _dulwich_repo(repo: "Repository"):
    from dulwich.repo import Repo
    (repo.hit_dir / "objects" / "pack").mkdir(parents=True, exist_ok=True)
    (repo.hit_dir / "objects" / "info").mkdir(parents=True, exist_ok=True)
    return Repo(str(repo.root), controldir=str(repo.hit_dir))


def is_local_path(url: str) -> bool:
    return bool(re.match(r"^[A-Za-z]:[\/]", url)) or url.startswith(("/", "./", "../", "\\\\")) or Path(url).exists()


def _client(url: str, quiet: bool = True):
    from dulwich.client import get_transport_and_path
    if is_local_path(url):
        from dulwich.client import LocalGitClient
        return LocalGitClient(), str(Path(url))
    host = host_of(url)
    kwargs = {}
    if url.startswith("http"):
        cred = get_credential(host)
        if cred:
            kwargs["username"], kwargs["password"] = cred
    client, path = get_transport_and_path(url, quiet=quiet, **kwargs)
    return client, path


def _auth_hint(url: str) -> str:
    host = host_of(url)
    if url.startswith("http"):
        return (f"run `hit login` to save a GitHub token for {host} "
                "(Settings → Developer settings → Personal access tokens, scope: repo)")
    return "make sure your SSH key is added to GitHub and to your ssh-agent"


@dataclass
class PushResult:
    branch: str
    remote: str
    old: str | None
    new: str
    status: str            # "ok" | "up-to-date" | "rejected"
    reason: str = ""


def push(repo: "Repository", remote: str = "origin", branch: str | None = None,
         force: bool = False, progress=None) -> PushResult:
    url = get_remote(repo, remote)
    if not url:
        raise HitError(f"no remote named '{remote}'",
                       "add one with `hit remote add origin https://github.com/you/repo.git`")
    branch = branch or repo.refs.current_branch()
    if not branch:
        raise HitError("not on a branch")
    local_sha = repo.refs.read(f"refs/heads/{branch}")
    if not local_sha:
        raise HitError("nothing to push yet", "make a commit first")

    drepo = _dulwich_repo(repo)
    client, path = _client(url)
    refname = f"refs/heads/{branch}".encode()
    remote_old: str | None = None

    def update_refs(refs: dict) -> dict:
        nonlocal remote_old
        old = refs.get(refname)
        remote_old = old.decode() if old else None
        if old and not force:
            old_s = old.decode()
            if old_s != local_sha and not (drepo.object_store.contains_loose(old) or
                                          drepo.object_store.contains_packed(old)) :
                raise HitError("remote has commits you don't have",
                               "run `hit pull` first, then push again (or `hit push --force` to overwrite)")
            if old_s != local_sha and old_s not in repo.ancestors(local_sha):
                raise HitError("remote has commits you don't have",
                               "run `hit pull` first, then push again (or `hit push --force` to overwrite)")
        new = dict(refs)
        new[refname] = local_sha.encode()
        return new

    def generate_pack(have, want, ofs_delta=False, progress=None):
        return drepo.object_store.generate_pack_data(have, want, ofs_delta=ofs_delta, progress=progress)

    try:
        result = client.send_pack(path, update_refs, generate_pack, progress=progress)
    except HitError:
        raise
    except Exception as e:  # noqa: BLE001
        raise _translate(e, url)
    err = (result.ref_status or {}).get(refname)
    if err:
        return PushResult(branch, remote, remote_old, local_sha, "rejected", err)
    repo.refs.write(f"refs/remotes/{remote}/{branch}", local_sha)
    repo.config.set(f'branch "{branch}"', "remote", remote, repo.hit_dir / "config")
    repo.config.set(f'branch "{branch}"', "merge", f"refs/heads/{branch}", repo.hit_dir / "config")
    status = "up-to-date" if remote_old == local_sha else "ok"
    return PushResult(branch, remote, remote_old, local_sha, status)


@dataclass
class FetchResult:
    remote: str
    updated: dict[str, tuple[str | None, str]] = field(default_factory=dict)  # branch -> (old, new)


def fetch(repo: "Repository", remote: str = "origin", progress=None) -> FetchResult:
    url = get_remote(repo, remote)
    if not url:
        raise HitError(f"no remote named '{remote}'",
                       "add one with `hit remote add origin <url>`")
    drepo = _dulwich_repo(repo)
    client, path = _client(url)
    try:
        res = client.fetch(path, drepo, progress=progress)
    except Exception as e:  # noqa: BLE001
        raise _translate(e, url)
    out = FetchResult(remote)
    for ref, sha in res.refs.items():
        if not ref.startswith(b"refs/heads/"):
            continue
        name = ref[len(b"refs/heads/"):].decode()
        local = f"refs/remotes/{remote}/{name}"
        old = repo.refs.read(local)
        new = sha.decode()
        if old != new:
            repo.refs.write(local, new)
            out.updated[name] = (old, new)
    # tags
    for ref, sha in res.refs.items():
        if ref.startswith(b"refs/tags/") and not ref.endswith(b"^{}"):
            name = ref.decode()
            if not repo.refs.exists(name):
                repo.refs.write(name, sha.decode())
    return out


def default_branch_of(repo: "Repository", remote: str = "origin") -> str | None:
    url = get_remote(repo, remote)
    if not url:
        return None
    try:
        client, path = _client(url)
        refs = client.get_refs(path)
    except Exception:
        return None
    head = refs.get(b"HEAD")
    if head:
        for ref, sha in refs.items():
            if ref.startswith(b"refs/heads/") and sha == head:
                return ref[len(b"refs/heads/"):].decode()
    return None


def clone(url: str, target: Path | None = None, progress=None) -> "Repository":
    from .repo import Repository
    url = normalize_url(url)
    if target is None:
        name = url.rstrip("/").rsplit("/", 1)[-1]
        target = Path.cwd() / (name[:-4] if name.endswith(".git") else name)
    target = Path(target)
    if target.exists() and any(target.iterdir()):
        raise HitError(f"{target} already exists and is not empty")
    target.mkdir(parents=True, exist_ok=True)
    repo = Repository.init(target)
    set_remote(repo, "origin", url)
    res = fetch(repo, "origin", progress=progress)
    if not res.updated:
        return repo  # empty remote
    branch = default_branch_of(repo) or ("main" if "main" in res.updated else next(iter(res.updated)))
    sha = repo.refs.read(f"refs/remotes/origin/{branch}")
    repo.refs.create_branch(branch, sha)
    repo.refs.set_head_branch(branch)
    repo.checkout_tree(repo.commit_files(sha), force=True)
    repo.config.set(f'branch "{branch}"', "remote", "origin", repo.hit_dir / "config")
    repo.config.set(f'branch "{branch}"', "merge", f"refs/heads/{branch}", repo.hit_dir / "config")
    return repo


def _translate(e: Exception, url: str) -> HitError:
    from dulwich.client import HTTPUnauthorized
    from dulwich.errors import NotGitRepository
    msg = str(e)
    if isinstance(e, HTTPUnauthorized) or "401" in msg or "403" in msg or "Unauthorized" in msg:
        return HitError(f"GitHub rejected your credentials for {host_of(url)}", _auth_hint(url))
    if isinstance(e, NotGitRepository) or "404" in msg or "not found" in msg.lower():
        return HitError(f"repository not found: {url}",
                        "check the URL, and that the repo exists on GitHub (create it there first)")
    if "getaddrinfo" in msg or "Name or service" in msg or "Max retries" in msg or "resolve" in msg.lower():
        return HitError("cannot reach the server — are you online?",
                        "HIT works fully offline; only push/pull need internet")
    return HitError(f"network error: {msg}")
