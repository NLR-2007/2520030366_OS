"""The HIT logo for the terminal.

The mark is the logo's "H" drawn in block characters, with the commit path cut
through it: three green commits and an arrow back, as in the brand artwork
(website/images/brand/hit-logo-primary.png). The blocks use the terminal's own
text colour, so the mark is black on light terminals - like the logo - and
light on dark ones.
"""
from __future__ import annotations

import shutil

from . import __version__
from .output import UNICODE, USE_COLOR, bold, dim, green, say

MARK = [
    "█████      █████",
    "██●██      █████",
    "██│██      █████",
    "██╰────●─────╮██",
    "█████████████│██",
    "█████      ██●██",
    "█████     ◀──╯██",
    "█████      █████",
]
WIDTH = len(MARK[0])
TEXT_ROW = 2          # the text block starts beside this row of the mark
GAP = 4


def _paint(row: str) -> str:
    if not USE_COLOR:
        return row
    return "".join(green(ch) if ch == "●" else ch for ch in row)


def banner_lines(tagline: str = "An NLR Group of Companies product",
                 url: str = "https://hitvcs.vercel.app") -> list[str]:
    text = [bold("HIT"), f"VERSION CONTROL  {__version__}", dim(tagline), dim(url)]
    if not UNICODE:
        return [bold(f"HIT - Version Control System {__version__}"), "  " + dim(tagline), "  " + dim(url)]
    longest = max(len(tagline), len(url), 22)
    beside = shutil.get_terminal_size((80, 24)).columns >= 2 + WIDTH + GAP + longest
    lines = []
    for i, row in enumerate(MARK):
        line = "  " + _paint(row)
        j = i - TEXT_ROW
        if beside and 0 <= j < len(text):
            line += " " * GAP + text[j]
        lines.append(line.rstrip())
    if not beside:
        lines += [""] + ["  " + t for t in text]
    return lines


# Compact mark for the dashboard header (4 rows).
MINI = [
    "█●█      ███",
    "█╰────●───╮█",
    "██████████│█",
    "███     ◀─●█",
]


def rich_header(lines: list[str], green_style: str = "#23aa69") -> str:
    """The compact mark with up to four lines of Rich markup text beside it."""
    out = []
    for i, row in enumerate(MINI):
        art = "".join(f"[{green_style}]●[/]" if ch == "●" else ch for ch in row)
        out.append(art + ("   " + lines[i] if i < len(lines) else ""))
    return "\n".join(out)


def print_banner(**kw) -> None:
    say("")
    for line in banner_lines(**kw):
        say(line)
    say("")
