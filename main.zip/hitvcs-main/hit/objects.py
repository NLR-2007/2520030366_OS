"""Git-compatible object store: blobs, trees, commits, tags.

Objects are stored exactly like Git does it (SHA-1 over "<type> <size>\\0<body>",
zlib-compressed, under objects/xx/yyyy...), so a HIT repo can be read by any
Git tool and pushed to GitHub without conversion.
"""
from __future__ import annotations

import hashlib
import os
import threading
import stat
import time
import zlib
from dataclasses import dataclass, field
from pathlib import Path

MODE_FILE = 0o100644
MODE_EXEC = 0o100755
MODE_DIR = 0o040000
MODE_LINK = 0o120000


class ObjectNotFound(Exception):
    pass


# --------------------------------------------------------------------------
# Low level: hash / read / write
# --------------------------------------------------------------------------

def hash_object(kind: str, body: bytes) -> str:
    header = f"{kind} {len(body)}\0".encode()
    return hashlib.sha1(header + body).hexdigest()


class ObjectStore:
    """Loose objects are handled here directly. Packfiles (which appear after a
    fetch/clone, or if someone runs `git gc` on the repo) are read through
    Dulwich's pack reader as a fallback."""

    def __init__(self, hit_dir: Path):
        self.dir = Path(hit_dir) / "objects"
        self._packs = None
        self._known_dirs: set[str] = set()
        self._size_cache: dict[str, int] | None = None

    def _path(self, sha: str) -> Path:
        return self.dir / sha[:2] / sha[2:]

    def _pack_store(self):
        if self._packs is None:
            try:
                from dulwich.object_store import DiskObjectStore
                self._packs = DiskObjectStore(str(self.dir))
            except Exception:
                self._packs = False
        return self._packs or None

    def _has_packs(self) -> bool:
        pack_dir = self.dir / "pack"
        return pack_dir.exists() and any(pack_dir.glob("*.idx"))

    def _read_packed(self, sha: str) -> tuple[str, bytes] | None:
        if not self._has_packs():
            return None
        ps = self._pack_store()
        if ps is None:
            return None
        try:
            ps._update_pack_cache()
            obj = ps[sha.encode()]
        except KeyError:
            return None
        return obj.type_name.decode(), obj.as_raw_string()

    def exists(self, sha: str) -> bool:
        return self._path(sha).exists() or self._read_packed(sha) is not None

    def write(self, kind: str, body: bytes) -> str:
        """Store an object. Safe to call from several threads at once."""
        sha = hash_object(kind, body)
        p = self._path(sha)
        if not p.exists():
            fan = sha[:2]
            if fan not in self._known_dirs:
                p.parent.mkdir(parents=True, exist_ok=True)
                self._known_dirs.add(fan)
            header = f"{kind} {len(body)}\0".encode()
            # unique temp name: two threads may store the same content at once
            tmp = p.with_name(f"{p.name}.{os.getpid()}.{threading.get_ident()}.tmp")
            tmp.write_bytes(zlib.compress(header + body, 1 if len(body) > 1_000_000 else 6))
            try:
                os.replace(tmp, p)
            except OSError:
                # another thread won the race with identical content — that's fine
                try:
                    tmp.unlink()
                except OSError:
                    pass
        return sha

    # ---- sizes without decompressing whole files ---------------------------

    def _size_cache_file(self) -> Path:
        return self.dir.parent / "hit" / "sizes.json"

    def _load_sizes(self) -> dict[str, int]:
        if self._size_cache is None:
            import json
            try:
                self._size_cache = json.loads(self._size_cache_file().read_text())
            except (OSError, ValueError):
                self._size_cache = {}
        return self._size_cache

    def _header_size(self, sha: str) -> int:
        """Read only the object header ("blob 1234\0") to learn the size."""
        p = self._path(sha)
        if p.exists():
            with open(p, "rb") as f:
                d = zlib.decompressobj()
                head = b""
                while b"\0" not in head:
                    chunk = f.read(256)
                    if not chunk:
                        break
                    head += d.decompress(chunk, 64)
            return int(head.split(b"\0", 1)[0].split(b" ", 1)[1])
        packed = self._read_packed(sha)
        return len(packed[1]) if packed else 0

    def sizes(self, shas) -> dict[str, int]:
        """Sizes of many blobs. Objects never change, so results are cached on disk."""
        cache = self._load_sizes()
        missing = [s for s in dict.fromkeys(shas) if s not in cache]
        if missing:
            from concurrent.futures import ThreadPoolExecutor
            with ThreadPoolExecutor(max_workers=min(16, len(missing))) as pool:
                for sha, n in zip(missing, pool.map(self._header_size, missing)):
                    cache[sha] = n
            try:
                import json
                f = self._size_cache_file()
                f.parent.mkdir(parents=True, exist_ok=True)
                f.write_text(json.dumps(cache))
            except OSError:
                pass
        return {s: cache.get(s, 0) for s in shas}

    def read(self, sha: str) -> tuple[str, bytes]:
        p = self._path(sha)
        if not p.exists():
            packed = self._read_packed(sha)
            if packed is None:
                raise ObjectNotFound(sha)
            return packed
        raw = zlib.decompress(p.read_bytes())
        nul = raw.index(b"\0")
        header = raw[:nul].decode()
        kind, _size = header.split(" ", 1)
        return kind, raw[nul + 1:]

    def resolve_prefix(self, prefix: str) -> str:
        """Expand an abbreviated SHA to the full one."""
        prefix = prefix.lower()
        if len(prefix) == 40 and self.exists(prefix):
            return prefix
        if len(prefix) < 4:
            raise ObjectNotFound(prefix)
        sub = self.dir / prefix[:2]
        matches = []
        if sub.exists():
            matches = [prefix[:2] + f.name for f in sub.iterdir()
                       if (prefix[:2] + f.name).startswith(prefix) and not f.name.endswith(".tmp")]
        if self._has_packs():
            ps = self._pack_store()
            if ps is not None:
                try:
                    ps._update_pack_cache()
                    for pack in ps.packs:
                        for sha_b in pack.index.iterentries():
                            h = sha_b[0].hex()
                            if h.startswith(prefix) and h not in matches:
                                matches.append(h)
                except Exception:
                    pass
        if len(matches) == 1:
            return matches[0]
        if not matches:
            raise ObjectNotFound(prefix)
        raise ObjectNotFound(f"{prefix} is ambiguous ({len(matches)} matches)")

    def all_shas(self) -> list[str]:
        out = []
        if not self.dir.exists():
            return out
        for sub in self.dir.iterdir():
            if sub.is_dir() and len(sub.name) == 2:
                for f in sub.iterdir():
                    if not f.name.endswith(".tmp"):
                        out.append(sub.name + f.name)
        if self._has_packs():
            ps = self._pack_store()
            if ps is not None:
                try:
                    ps._update_pack_cache()
                    for pack in ps.packs:
                        for entry in pack.index.iterentries():
                            out.append(entry[0].hex())
                except Exception:
                    pass
        return out

    # ---- typed helpers ----------------------------------------------------

    def write_blob(self, data: bytes) -> str:
        return self.write("blob", data)

    def read_blob(self, sha: str) -> bytes:
        kind, body = self.read(sha)
        if kind != "blob":
            raise ValueError(f"{sha} is a {kind}, not a blob")
        return body

    def write_tree(self, tree: "Tree") -> str:
        return self.write("tree", tree.serialize())

    def read_tree(self, sha: str) -> "Tree":
        kind, body = self.read(sha)
        if kind != "tree":
            raise ValueError(f"{sha} is a {kind}, not a tree")
        return Tree.parse(body)

    def write_commit(self, commit: "Commit") -> str:
        return self.write("commit", commit.serialize())

    def read_commit(self, sha: str) -> "Commit":
        kind, body = self.read(sha)
        if kind == "tag":
            tag = Tag.parse(body)
            return self.read_commit(tag.object)
        if kind != "commit":
            raise ValueError(f"{sha} is a {kind}, not a commit")
        c = Commit.parse(body)
        c.sha = sha
        return c


# --------------------------------------------------------------------------
# Tree
# --------------------------------------------------------------------------

@dataclass
class TreeEntry:
    mode: int
    name: str
    sha: str

    @property
    def is_dir(self) -> bool:
        return self.mode == MODE_DIR


@dataclass
class Tree:
    entries: list[TreeEntry] = field(default_factory=list)

    def serialize(self) -> bytes:
        # Git sorts tree entries by name, with directories compared as "name/"
        def key(e: TreeEntry):
            return e.name + ("/" if e.is_dir else "")
        out = b""
        for e in sorted(self.entries, key=key):
            out += f"{e.mode:o} {e.name}\0".encode() + bytes.fromhex(e.sha)
        return out

    @classmethod
    def parse(cls, body: bytes) -> "Tree":
        entries = []
        i = 0
        while i < len(body):
            sp = body.index(b" ", i)
            nul = body.index(b"\0", sp)
            mode = int(body[i:sp], 8)
            name = body[sp + 1:nul].decode("utf-8", "surrogateescape")
            sha = body[nul + 1:nul + 21].hex()
            entries.append(TreeEntry(mode, name, sha))
            i = nul + 21
        return cls(entries)

    def get(self, name: str) -> TreeEntry | None:
        for e in self.entries:
            if e.name == name:
                return e
        return None


def flatten_tree(store: ObjectStore, tree_sha: str, prefix: str = "") -> dict[str, tuple[int, str]]:
    """Return {path: (mode, blob_sha)} for every file under a tree."""
    out: dict[str, tuple[int, str]] = {}
    tree = store.read_tree(tree_sha)
    for e in tree.entries:
        path = f"{prefix}{e.name}"
        if e.is_dir:
            out.update(flatten_tree(store, e.sha, path + "/"))
        else:
            out[path] = (e.mode, e.sha)
    return out


def build_tree(store: ObjectStore, files: dict[str, tuple[int, str]]) -> str:
    """Build nested tree objects from {path: (mode, blob_sha)}; returns root sha."""
    root: dict = {}
    for path, (mode, sha) in files.items():
        parts = path.split("/")
        node = root
        for part in parts[:-1]:
            node = node.setdefault(part, {})
        node[parts[-1]] = (mode, sha)

    def write(node: dict) -> str:
        tree = Tree()
        for name, val in node.items():
            if isinstance(val, dict):
                tree.entries.append(TreeEntry(MODE_DIR, name, write(val)))
            else:
                tree.entries.append(TreeEntry(val[0], name, val[1]))
        return store.write_tree(tree)

    return write(root)


# --------------------------------------------------------------------------
# Commit / Tag
# --------------------------------------------------------------------------

def _format_ident(name: str, email: str, ts: int, tz: str) -> str:
    return f"{name} <{email}> {ts} {tz}"


def _parse_ident(s: str) -> tuple[str, str, int, str]:
    lt = s.rindex("<")
    gt = s.rindex(">")
    name = s[:lt].strip()
    email = s[lt + 1:gt]
    rest = s[gt + 1:].strip().split()
    ts = int(rest[0]) if rest else 0
    tz = rest[1] if len(rest) > 1 else "+0000"
    return name, email, ts, tz


def local_tz() -> str:
    offset = -time.timezone if not time.localtime().tm_isdst else -time.altzone
    sign = "+" if offset >= 0 else "-"
    offset = abs(offset)
    return f"{sign}{offset // 3600:02d}{(offset % 3600) // 60:02d}"


@dataclass
class Commit:
    tree: str
    parents: list[str]
    author: str
    author_email: str
    author_time: int
    author_tz: str
    committer: str
    committer_email: str
    commit_time: int
    commit_tz: str
    message: str
    sha: str = ""
    extra: list[tuple[str, str]] = field(default_factory=list)

    @classmethod
    def new(cls, tree: str, parents: list[str], name: str, email: str, message: str,
            ts: int | None = None) -> "Commit":
        ts = int(time.time()) if ts is None else ts
        tz = local_tz()
        return cls(tree, parents, name, email, ts, tz, name, email, ts, tz, message)

    def serialize(self) -> bytes:
        lines = [f"tree {self.tree}"]
        for p in self.parents:
            lines.append(f"parent {p}")
        lines.append("author " + _format_ident(self.author, self.author_email, self.author_time, self.author_tz))
        lines.append("committer " + _format_ident(self.committer, self.committer_email, self.commit_time, self.commit_tz))
        for k, v in self.extra:
            lines.append(f"{k} {v}")
        msg = self.message if self.message.endswith("\n") else self.message + "\n"
        return ("\n".join(lines) + "\n\n" + msg).encode()

    @classmethod
    def parse(cls, body: bytes) -> "Commit":
        text = body.decode("utf-8", "replace")
        header, _, message = text.partition("\n\n")
        tree = ""
        parents: list[str] = []
        author = committer = ("", "", 0, "+0000")
        extra: list[tuple[str, str]] = []
        for line in header.split("\n"):
            key, _, val = line.partition(" ")
            if key == "tree":
                tree = val
            elif key == "parent":
                parents.append(val)
            elif key == "author":
                author = _parse_ident(val)
            elif key == "committer":
                committer = _parse_ident(val)
            elif key:
                extra.append((key, val))
        return cls(tree, parents, *author, *committer, message, extra=extra)

    @property
    def summary(self) -> str:
        return self.message.strip().split("\n", 1)[0]

    @property
    def short(self) -> str:
        return self.sha[:7]


@dataclass
class Tag:
    object: str
    type: str
    tag: str
    tagger: str
    message: str

    def serialize(self) -> bytes:
        s = f"object {self.object}\ntype {self.type}\ntag {self.tag}\ntagger {self.tagger}\n\n{self.message}"
        if not s.endswith("\n"):
            s += "\n"
        return s.encode()

    @classmethod
    def parse(cls, body: bytes) -> "Tag":
        text = body.decode("utf-8", "replace")
        header, _, message = text.partition("\n\n")
        d = {}
        for line in header.split("\n"):
            k, _, v = line.partition(" ")
            d[k] = v
        return cls(d.get("object", ""), d.get("type", "commit"), d.get("tag", ""), d.get("tagger", ""), message)


def mode_from_stat(st: os.stat_result) -> int:
    if stat.S_ISLNK(st.st_mode):
        return MODE_LINK
    if os.name != "nt" and st.st_mode & stat.S_IXUSR:
        return MODE_EXEC
    return MODE_FILE


def mode_for_path(path: Path) -> int:
    st = path.lstat()
    if stat.S_ISLNK(st.st_mode):
        return MODE_LINK
    if os.name != "nt" and st.st_mode & stat.S_IXUSR:
        return MODE_EXEC
    return MODE_FILE
