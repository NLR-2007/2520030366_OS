"""The undo journal: every state-changing command records what it did so
`hit undo` can reverse it.

Each entry stores the full ref state (HEAD + all branches) before and after,
plus a snapshot of the index. Because objects are never deleted from the
store by normal commands, restoring refs + index is enough to undo
commits, resets, merges, switches, purges and restores.
"""
from __future__ import annotations

import json
import shutil
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .repo import Repository


@dataclass
class RefState:
    head_symbolic: str | None
    head_sha: str | None
    branches: dict[str, str]
    tags: dict[str, str]


@dataclass
class Entry:
    id: int
    time: int
    command: str
    description: str
    before: dict
    after: dict
    index_before: str | None = None     # filename inside hit/journal-index/
    index_after: str | None = None
    worktree_snapshot: str | None = None  # snapshot name if the worktree was changed destructively
    undone: bool = False


class Journal:
    def __init__(self, repo: "Repository"):
        self.repo = repo
        self.dir = repo.extras_dir
        self.file = self.dir / "journal.json"
        self.idx_dir = self.dir / "journal-index"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.idx_dir.mkdir(exist_ok=True)

    # ---- state capture ----------------------------------------------------

    def capture_refs(self) -> dict:
        r = self.repo.refs
        return asdict(RefState(r.read_symbolic("HEAD"), r.head(), r.branches(), r.tags()))

    def _save_index(self, tag: str) -> str | None:
        src = self.repo.hit_dir / "index"
        if not src.exists():
            return None
        name = f"{int(time.time() * 1000)}-{tag}.idx"
        shutil.copy2(src, self.idx_dir / name)
        return name

    def _restore_index(self, name: str | None) -> None:
        dst = self.repo.hit_dir / "index"
        if name and (self.idx_dir / name).exists():
            shutil.copy2(self.idx_dir / name, dst)
        elif dst.exists():
            dst.unlink()
        from .index import Index
        self.repo.index = Index(dst)

    def restore_refs(self, state: dict) -> None:
        r = self.repo.refs
        for name in list(r.branches()):
            if name not in state["branches"]:
                r.delete_branch(name)
        for name, sha in state["branches"].items():
            r.update_branch(name, sha)
        for name in list(r.tags()):
            if name not in state["tags"]:
                r.delete(f"refs/tags/{name}")
        for name, sha in state["tags"].items():
            r.write(f"refs/tags/{name}", sha)
        if state["head_symbolic"]:
            r.write_symbolic("HEAD", state["head_symbolic"])
        elif state["head_sha"]:
            r.set_head_detached(state["head_sha"])

    # ---- persistence ------------------------------------------------------

    def entries(self) -> list[Entry]:
        if not self.file.exists():
            return []
        try:
            return [Entry(**e) for e in json.loads(self.file.read_text())]
        except (json.JSONDecodeError, TypeError):
            return []

    def _write(self, entries: list[Entry]) -> None:
        self.file.write_text(json.dumps([asdict(e) for e in entries], indent=1))

    # ---- recording --------------------------------------------------------

    def begin(self, command: str) -> dict:
        return {"command": command, "before": self.capture_refs(),
                "index_before": self._save_index("before"), "t": int(time.time())}

    def end(self, token: dict, description: str, worktree_snapshot: str | None = None) -> Entry:
        entries = self.entries()
        e = Entry(
            id=(entries[-1].id + 1) if entries else 1,
            time=token["t"],
            command=token["command"],
            description=description,
            before=token["before"],
            after=self.capture_refs(),
            index_before=token["index_before"],
            index_after=self._save_index("after"),
            worktree_snapshot=worktree_snapshot,
        )
        entries.append(e)
        # keep the journal bounded
        for old in entries[:-200]:
            for n in (old.index_before, old.index_after):
                if n and (self.idx_dir / n).exists():
                    (self.idx_dir / n).unlink()
        entries = entries[-200:]
        self._write(entries)
        return e

    # ---- undo / redo ------------------------------------------------------

    def undo(self, steps: int = 1) -> list[Entry]:
        entries = self.entries()
        done: list[Entry] = []
        for e in reversed(entries):
            if steps == 0:
                break
            if e.undone:
                continue
            self.restore_refs(e.before)
            self._restore_index(e.index_before)
            if e.worktree_snapshot:
                from .snapshot import restore_worktree_snapshot
                restore_worktree_snapshot(self.repo, e.worktree_snapshot)
            else:
                self.repo.checkout_tree(self.repo.index.as_tree_files(), force=True)
            e.undone = True
            done.append(e)
            steps -= 1
        self._write(entries)
        return done

    def redo(self, steps: int = 1) -> list[Entry]:
        entries = self.entries()
        done: list[Entry] = []
        for e in entries:
            pass
        # redo the most recently undone entries, in order
        undone = [e for e in entries if e.undone]
        for e in undone[-steps:]:
            self.restore_refs(e.after)
            self._restore_index(e.index_after)
            self.repo.checkout_tree(self.repo.index.as_tree_files(), force=True)
            e.undone = False
            done.append(e)
        self._write(entries)
        return done

    def last(self) -> Entry | None:
        for e in reversed(self.entries()):
            if not e.undone:
                return e
        return None
