"""History rewriting: purge files from all commits, drop commits, squash.

All rewriting goes through `rewrite_history`, which walks every commit
reachable from every branch/tag (oldest first), applies a transform to the
file map, and writes new commits. Branch/tag refs are moved to the rewritten
commits. Old objects are left in the store (undo can bring them back).
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Callable

from .objects import Commit, build_tree, flatten_tree

if TYPE_CHECKING:
    from .repo import Repository

FileMap = dict[str, tuple[int, str]]


def _all_commits_topo(repo: "Repository") -> list[Commit]:
    """Every reachable commit, parents before children."""
    heads = list(repo.refs.branches().values()) + list(repo.refs.tags().values())
    h = repo.refs.head()
    if h:
        heads.append(h)
    order: list[Commit] = []
    seen: set[str] = set()

    def visit(sha: str) -> None:
        stack = [(sha, False)]
        while stack:
            s, done = stack.pop()
            if done:
                order.append(repo.store.read_commit(s))
                continue
            if s in seen:
                continue
            seen.add(s)
            stack.append((s, True))
            c = repo.store.read_commit(s)
            for p in c.parents:
                if p not in seen:
                    stack.append((p, False))

    for hd in dict.fromkeys(heads):
        try:
            c = repo.store.read_commit(hd)
            visit(c.sha)
        except Exception:
            continue
    return order


def rewrite_history(repo: "Repository",
                    transform: Callable[[Commit, FileMap], FileMap | None],
                    ) -> dict[str, str]:
    """Rewrite all commits. transform(commit, files) returns the new file map,
    or None to drop the commit entirely (children re-parent onto its parents).
    Returns {old_sha: new_sha} (dropped commits map to their first surviving parent)."""
    mapping: dict[str, str] = {}
    for c in _all_commits_topo(repo):
        files = flatten_tree(repo.store, c.tree)
        new_files = transform(c, files)
        new_parents: list[str] = []
        for p in c.parents:
            m = mapping.get(p, p)
            if m and m not in new_parents:
                new_parents.append(m)
        if new_files is None:
            mapping[c.sha] = new_parents[0] if new_parents else ""
            continue
        tree = build_tree(repo.store, new_files)
        # skip commits that became empty relative to their parent (nothing changed)
        if new_parents and len(new_parents) == 1:
            parent_tree = repo.store.read_commit(new_parents[0]).tree
            if parent_tree == tree and repo.store.read_commit(new_parents[0]).tree != c.tree:
                pass  # keep it: preserves message/history; user can squash if wanted
        if tree == c.tree and new_parents == c.parents:
            mapping[c.sha] = c.sha
            continue
        nc = Commit(tree, new_parents, c.author, c.author_email, c.author_time, c.author_tz,
                    c.committer, c.committer_email, c.commit_time, c.commit_tz, c.message, extra=c.extra)
        mapping[c.sha] = repo.store.write_commit(nc)

    # move refs
    for name, sha in repo.refs.branches().items():
        new = mapping.get(sha, sha)
        if new and new != sha:
            repo.refs.update_branch(name, new)
        elif not new:
            repo.refs.delete_branch(name)
    for name, sha in repo.refs.tags().items():
        kind, _ = repo.store.read(sha)
        if kind == "tag":
            continue  # annotated tags keep pointing at old commits; rare, acceptable
        new = mapping.get(sha, sha)
        if new and new != sha:
            repo.refs.write(f"refs/tags/{name}", new)
        elif not new:
            repo.refs.delete(f"refs/tags/{name}")
    if not repo.refs.current_branch():
        h = repo.refs.head()
        if h and h in mapping:
            repo.refs.set_head_detached(mapping[h] or h)
    return mapping


def purge_paths(repo: "Repository", paths: list[str]) -> tuple[dict[str, str], int]:
    """Remove files/folders from every commit. Returns (mapping, commits_touched)."""
    norm = [p.strip("/") for p in paths]
    touched = 0

    def matches(path: str) -> bool:
        return any(path == n or path.startswith(n + "/") for n in norm)

    def transform(c: Commit, files: FileMap) -> FileMap:
        nonlocal touched
        new = {p: v for p, v in files.items() if not matches(p)}
        if len(new) != len(files):
            touched += 1
        return new

    mapping = rewrite_history(repo, transform)
    # update index/worktree to the rewritten HEAD
    for n in norm:
        for rel in list(repo.index.paths()):
            if rel == n or rel.startswith(n + "/"):
                repo.index.remove(rel)
                p = repo.root / rel
                if p.exists():
                    p.unlink()
    repo.index.save()
    return mapping, touched


def drop_commit(repo: "Repository", sha: str) -> dict[str, str]:
    """Remove one commit from history; its changes disappear from later commits."""
    target = repo.store.read_commit(sha)
    target_files = flatten_tree(repo.store, target.tree)
    parent_files = flatten_tree(repo.store, repo.store.read_commit(target.parents[0]).tree) if target.parents else {}
    from .diff import tree_changes
    changes = tree_changes(parent_files, target_files)
    descendants = {c.sha for c in _all_commits_topo(repo) if sha in repo.ancestors(c.sha) and c.sha != sha}

    def transform(c: Commit, files: FileMap) -> FileMap | None:
        if c.sha == sha:
            return None
        if c.sha not in descendants:
            return files
        # undo the dropped commit's changes in descendants, where they still hold
        new = dict(files)
        for ch in changes:
            cur = new.get(ch.path)
            if ch.status == "A" and cur and cur[1] == ch.new_sha:
                del new[ch.path]
            elif ch.status == "D" and ch.path not in new:
                new[ch.path] = (ch.old_mode, ch.old_sha)
            elif ch.status == "M" and cur and cur[1] == ch.new_sha:
                new[ch.path] = (ch.old_mode, ch.old_sha)
        return new

    mapping = rewrite_history(repo, transform)
    repo.reset("HEAD", "mixed")
    repo.checkout_tree(repo.index.as_tree_files(), force=True)
    return mapping


def squash(repo: "Repository", count: int | None, message: str) -> str:
    """Squash the last `count` commits on the current branch (all if None) into one."""
    from .repo import HitError
    head = repo.refs.head()
    if not head:
        raise HitError("no commits to squash")
    chain = repo.log()
    if count is not None:
        if count < 2:
            raise HitError("need at least 2 commits to squash")
        chain = chain[:count]
    oldest = chain[-1]
    tree = repo.store.read_commit(head).tree
    name, email = repo.identity()
    c = Commit.new(tree, oldest.parents, name, email, message)
    c.author, c.author_email, c.author_time, c.author_tz = oldest.author, oldest.author_email, oldest.author_time, oldest.author_tz
    sha = repo.store.write_commit(c)
    repo.refs.update_head(sha)
    return sha
