"""Snapshots: save the entire repository history (all objects + refs + index)
into one file, and restore it later. Also used as the automatic backup before
destructive commands (purge, restore, project delete).

Format: a zip named <name>.hitsnap containing the whole .hit/ folder minus
the snapshots/backups folders themselves. Optionally the working tree too.
"""
from __future__ import annotations

import json
import os
import re
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .repo import Repository

EXT = ".hitsnap"
SKIP_DIRS = ("hit/snapshots", "hit/backups", "hit/journal-index")


@dataclass
class SnapshotInfo:
    name: str
    path: Path
    time: int
    size: int
    branch: str | None
    head: str | None
    message: str
    commits: int
    kind: str          # "snapshot" | "backup"
    with_worktree: bool


def _safe_name(name: str) -> str:
    name = re.sub(r"[^A-Za-z0-9._-]+", "-", name.strip()).strip("-")
    return name or time.strftime("%Y-%m-%d_%H-%M-%S")


def _meta(repo: "Repository", name: str, kind: str, with_worktree: bool) -> dict:
    head = repo.refs.head()
    msg = ""
    commits = 0
    if head:
        c = repo.store.read_commit(head)
        msg = c.summary
        commits = len(repo.log())
    return {"name": name, "time": int(time.time()), "branch": repo.refs.current_branch(),
            "head": head, "message": msg, "commits": commits, "kind": kind,
            "with_worktree": with_worktree, "project": repo.root.name}


def create(repo: "Repository", name: str | None = None, kind: str = "snapshot",
           with_worktree: bool = False) -> Path:
    name = _safe_name(name or "")
    folder = repo.extras_dir / ("snapshots" if kind == "snapshot" else "backups")
    folder.mkdir(parents=True, exist_ok=True)
    if kind == "backup":
        name = f"{time.strftime('%Y-%m-%d_%H-%M-%S')}-{name}"
    out = folder / f"{name}{EXT}"
    if out.exists() and kind == "snapshot":
        from .repo import HitError
        raise HitError(f"snapshot '{name}' already exists", "pick another name or delete it first")
    meta = _meta(repo, name, kind, with_worktree)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("hitsnap.json", json.dumps(meta, indent=2))
        for root, dirs, files in os.walk(repo.hit_dir):
            rel_root = Path(root).relative_to(repo.hit_dir).as_posix()
            rel_root = "" if rel_root == "." else rel_root
            dirs[:] = [d for d in dirs if (f"{rel_root}/{d}" if rel_root else d) not in SKIP_DIRS]
            for f in files:
                if f.endswith((".lock", ".tmp")):
                    continue
                rel = f"{rel_root}/{f}" if rel_root else f
                z.write(Path(root) / f, f"repo/{rel}")
        if with_worktree:
            for rel in repo.walk_files():
                z.write(repo.root / rel, f"worktree/{rel}")
    return out


def list_snapshots(repo: "Repository", kind: str = "snapshot") -> list[SnapshotInfo]:
    folder = repo.extras_dir / ("snapshots" if kind == "snapshot" else "backups")
    out: list[SnapshotInfo] = []
    if not folder.exists():
        return out
    for p in sorted(folder.glob(f"*{EXT}")):
        try:
            with zipfile.ZipFile(p) as z:
                meta = json.loads(z.read("hitsnap.json"))
        except (zipfile.BadZipFile, KeyError):
            continue
        out.append(SnapshotInfo(meta["name"], p, meta["time"], p.stat().st_size, meta.get("branch"),
                                meta.get("head"), meta.get("message", ""), meta.get("commits", 0),
                                meta.get("kind", kind), meta.get("with_worktree", False)))
    out.sort(key=lambda s: s.time, reverse=True)
    return out


def find(repo: "Repository", name: str) -> Path:
    from .repo import HitError
    p = Path(name)
    if p.exists() and p.suffix == EXT:
        return p
    for kind in ("snapshot", "backup"):
        for s in list_snapshots(repo, kind):
            if s.name == name or s.path.name == name or s.path.stem == name:
                return s.path
    raise HitError(f"no snapshot named '{name}'", "see `hit snapshot list`")


def restore(repo: "Repository", name: str, with_worktree: bool | None = None) -> dict:
    """Replace the repository state with the snapshot's. Working tree is
    updated to match the restored HEAD (or the saved worktree if present)."""
    path = find(repo, name)
    with zipfile.ZipFile(path) as z:
        meta = json.loads(z.read("hitsnap.json"))
        # wipe current repo internals (keep snapshots/backups/journal)
        for root, dirs, files in os.walk(repo.hit_dir, topdown=False):
            rel_root = Path(root).relative_to(repo.hit_dir).as_posix()
            rel_root = "" if rel_root == "." else rel_root
            if any(rel_root == s or rel_root.startswith(s + "/") for s in SKIP_DIRS):
                continue
            if rel_root == "hit":
                continue
            for f in files:
                (Path(root) / f).unlink()
            for d in dirs:
                rd = f"{rel_root}/{d}" if rel_root else d
                if rd not in SKIP_DIRS and rd != "hit":
                    try:
                        (Path(root) / d).rmdir()
                    except OSError:
                        pass
        for info in z.infolist():
            if info.filename.startswith("repo/"):
                target = repo.hit_dir / info.filename[5:]
                if info.filename.endswith("/"):
                    continue
                # journal.json lives in hit/, keep the current one
                if info.filename[5:] == "hit/journal.json":
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(z.read(info))
        use_wt = meta.get("with_worktree") if with_worktree is None else (with_worktree and meta.get("with_worktree"))
        _reload(repo)
        if use_wt:
            restore_worktree_snapshot(repo, path.stem, path)
        else:
            repo.checkout_tree(repo.index.as_tree_files(), force=True)
    return meta


def restore_worktree_snapshot(repo: "Repository", name: str, path: Path | None = None) -> None:
    """Replace tracked working files with the `worktree/` part of a snapshot."""
    path = path or find(repo, name)
    with zipfile.ZipFile(path) as z:
        names = [n for n in z.namelist() if n.startswith("worktree/")]
        if not names:
            repo.checkout_tree(repo.index.as_tree_files(), force=True)
            return
        # remove currently tracked files first
        for rel in repo.index.paths():
            p = repo.root / rel
            if p.exists():
                p.unlink()
        for n in names:
            target = repo.root / n[len("worktree/"):]
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(z.read(n))


def _reload(repo: "Repository") -> None:
    from .index import Index
    repo.index = Index(repo.hit_dir / "index")


def delete(repo: "Repository", name: str) -> Path:
    p = find(repo, name)
    p.unlink()
    return p
