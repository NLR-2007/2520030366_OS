"""Plain-English command layer. Fully offline: pattern + fuzzy matching only."""
from .parser import parse, ParsedCommand, suggest_commands  # noqa: F401
