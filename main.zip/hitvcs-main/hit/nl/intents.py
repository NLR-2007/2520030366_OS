"""Intent table: what people say -> which HIT command(s) to run.

Each intent has:
  patterns  - regexes tried in order (case-insensitive, on the normalized sentence).
              Named groups become arguments: (?P<message>...), (?P<file>...), (?P<branch>...)
  keywords  - loose words that vote for this intent when no pattern matches exactly
  build     - function(args) -> list of argv lists to run (each is one hit command)
  danger    - True if the command needs confirmation even with --yes
  explain   - one-line, plain-English description shown before running
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Callable

Args = dict[str, str]
Build = Callable[[Args], list[list[str]]]


@dataclass
class Intent:
    name: str
    patterns: list[str]
    build: Build
    explain: str
    keywords: list[str] = field(default_factory=list)
    danger: bool = False
    examples: list[str] = field(default_factory=list)
    _compiled: list[re.Pattern] = field(default_factory=list, repr=False)

    def __post_init__(self):
        self._compiled = [re.compile(p, re.IGNORECASE) for p in self.patterns]


# Words that carry no meaning for matching
FILLER = {"please", "pls", "plz", "can", "you", "u", "could", "would", "i", "want", "to", "wanna",
          "just", "now", "the", "a", "an", "my", "me", "our", "this", "that", "hit", "hey", "hi",
          "yo", "kindly", "lets", "let's", "let", "us", "do", "it", "for", "of", "also", "then",
          "some", "all", "in", "on", "with", "and"}

MSG = r"(?P<message>.+?)"
FILE = r"(?P<file>[\w./\\*-]+(?:\s+[\w./\\*-]+)*?)"
BRANCH = r"(?P<branch>[\w./-]+)"
REV = r"(?P<rev>[\w./~^-]+)"
NUM = r"(?P<n>\d+)"


def _commit_all(a: Args) -> list[list[str]]:
    msg = a.get("message") or "update"
    return [["add", "."], ["commit", "-m", msg]]


def _commit_files(a: Args) -> list[list[str]]:
    files = a["file"].split()
    msg = a.get("message") or f"update {' '.join(files)}"
    return [["add", *files], ["commit", "-m", msg]]


INTENTS: list[Intent] = [
    # ---------------------------------------------------------------- init
    Intent("init",
           [r"^(start|init|initiali[sz]e|create|make|begin|setup|set up)( tracking| version control| versioning| (a |new )?(repo|repository|project))?( here| in this folder| in this directory)?$",
            r"^(start|begin) (tracking|versioning) (this|my|the) (project|folder|code)$"],
           lambda a: [["init"]],
           "Start tracking this folder with HIT",
           keywords=["start", "init", "initialize", "begin", "new repo", "setup", "track this"],
           examples=["start tracking this folder", "create a repo here"]),

    Intent("uninit",
           [r"^(delete|remove|uninit|deinit|destroy|reset|clear|wipe|drop)( this| the| my)?( hit| repo| repository| project| tracking| history| everything| version control| \.hit)?( from (this|the) (folder|project))?$",
            r"^(stop|quit) (tracking|using hit)( (this|the) (folder|project))?$",
            r"^(delete|remove)$"],
           lambda a: [["uninit"]],
           "Remove HIT tracking from this folder (your files stay; history is backed up first)",
           keywords=["uninit", "delete repo", "remove hit", "stop tracking"],
           danger=True,
           examples=["delete this repo", "remove hit from this folder"]),

    # ---------------------------------------------------------------- status
    Intent("status",
           [r"^(what('?s| is| has| did i)?( been)? (changed?|new|different|modified|going on|happening|the status)( here)?|status|show( me)? (the )?(status|changes)|(any|what) changes|where am i|what did i (change|do|edit))\??$"],
           lambda a: [["status"]],
           "Show what has changed since the last commit",
           keywords=["status", "changed", "changes", "modified", "what did i do", "where am i"],
           examples=["what changed", "status", "where am i"]),

    # ---------------------------------------------------------------- diff
    Intent("diff",
           [r"^(show|see|view|display)( me)?( the)? (diff|difference|differences|edits|exact changes)( in| for| of)? ?" + FILE + r"?$",
            r"^(diff|compare|what exactly changed)( ' + FILE + ')?$",
            r"^(show|see|view)( me)? (what|which lines) (i )?(changed|edited)( in " + FILE + r")?$"],
           lambda a: [["diff", *(a["file"].split() if a.get("file") else [])]],
           "Show the exact line-by-line changes",
           keywords=["diff", "difference", "compare", "lines changed"],
           examples=["show diff", "what exactly changed in app.py"]),

    # ---------------------------------------------------------------- add
    Intent("add",
           [r"^(stage|add|track|include|prepare)( the| these)?( files?| changes?| everything| all)?( for commit| to commit)?$",
            r"^(stage|add|track|include) " + FILE + r"( for commit| to commit)?$"],
           lambda a: [["add", *(a["file"].split() if a.get("file") else ["."])]],
           "Stage files so they are included in the next commit",
           keywords=["stage", "add", "track", "include"],
           examples=["add everything", "stage app.py"]),

    # ---------------------------------------------------------------- commit
    Intent("commit",
           [r"^(save|commit|checkpoint|record|snapshot|store|keep)( all| everything| my| the| this| these)?( work| changes?| code| progress| files?| stuff| project)?( (as|with message|with|called|named|saying|message|msg|-m|:) ['\"]?" + MSG + r"['\"]?)?$",
            r"^(save|commit|checkpoint|record) " + FILE + r"( (as|with message|with|called|saying|:) ['\"]?" + MSG + r"['\"]?)?$",
            r"^(save|commit) ['\"]" + MSG + r"['\"]$"],
           lambda a: _commit_files(a) if a.get("file") else _commit_all(a),
           "Save a checkpoint of your work (stage everything + commit)",
           keywords=["save", "commit", "checkpoint", "record", "keep"],
           examples=["save my changes as fixed login", "commit everything", "save app.py as bug fix"]),

    Intent("amend",
           [r"^(fix|change|edit|update|amend|rename)( the)? (last|previous|latest) (commit|save)( message)?( (to|as|:) ['\"]?" + MSG + r"['\"]?)?$"],
           lambda a: [["commit", "--amend", *(["-m", a["message"]] if a.get("message") else [])]],
           "Change the last commit (message or add staged changes to it)",
           keywords=["amend", "fix last commit", "change last commit message"],
           examples=["change last commit message to typo fix"]),

    # ---------------------------------------------------------------- log
    Intent("log",
           [r"^(show|see|view|list|display|print|get)( me)?( the| my| all)? (history|commits?|log|timeline|past|saves|checkpoints|versions)( (of|for) " + FILE + r")?$",
            r"^(history|log|commits|timeline|what happened|what did i do before)$",
            r"^(show|see|list)( me)?( the)? (last|latest|recent) " + NUM + r" (commits?|saves|changes)$"],
           lambda a: [["log", *(["-n", a["n"]] if a.get("n") else []), *(["--", a["file"]] if a.get("file") else [])]],
           "Show the history of commits",
           keywords=["history", "log", "commits", "timeline", "past", "versions"],
           examples=["show history", "list last 5 commits"]),

    # ---------------------------------------------------------------- files
    Intent("files",
           [r"^(show|see|list|view|display|what)( me)?( are)?( the| all)? (files?|folders?|contents?)( and folders)?( (in|of|from|inside) (the )?(last|latest|previous|" + REV + r")( commit| save)?)?$",
            r"^(what|which) (files?|things) (did i|are|were|got) (commit|committed|saved|in there)( in " + REV + r")?$",
            r"^(show|list) (tracked|committed|saved) files$"],
           lambda a: [["files", a["rev"]] if a.get("rev") and a["rev"] not in ("last", "latest", "previous") else ["files"]],
           "List every file inside a commit",
           keywords=["files", "folders", "contents", "what is in", "tracked", "committed files"],
           examples=["show files in last commit", "which files did i commit", "list files in a1b2c3"]),

    # ---------------------------------------------------------------- rm / purge
    Intent("rm",
           [r"^(stop tracking|untrack|remove|delete|drop|forget) " + FILE + r"( from (the )?(next|future|upcoming) (commit|save)| from (hit|tracking|the repo|version control))?$",
            r"^(remove|delete|drop) " + FILE + r"$"],
           lambda a: [["rm", *a["file"].split()]],
           "Stop tracking a file from the next commit onward (history stays intact)",
           keywords=["untrack", "stop tracking", "remove", "delete", "forget"],
           examples=["stop tracking debug.log", "remove notes.txt"]),

    Intent("wipe",
           [r"^(delete|remove|erase|wipe|clear|drop|destroy|reset|kill|purge|nuke)( out)?( all| every| the whole| the entire| entire| whole| complete| my| the)? ?(the )?(commits?|history|log|git commits|git history|hit history|saves|checkpoints)( at once| all at once| completely| entirely| from (git|hit|the repo))?$",
            r"^(start|begin) (over|again|fresh) (with|and keep|but keep) (my|the) files$",
            r"^(clear|wipe|reset) history$"],
           lambda a: [["wipe"]],
           "Delete ALL commits at once (your files stay on disk; backup + undo available)",
           keywords=["all commits", "wipe", "clear history", "delete history", "at once"],
           danger=True,
           examples=["delete all commits", "wipe history"]),

    Intent("purge",
           [r"^(remove|delete|erase|purge|wipe|scrub|nuke|get rid of|clean|strip) " + FILE + r" (from|out of|in) (all|the whole|the entire|every|complete|full)? ?(history|commits|the past|everywhere|all commits|the repo history)$",
            r"^(remove|delete|erase|purge) " + FILE + r" (completely|forever|permanently|everywhere)( from history)?$",
            r"^(purge|scrub) " + FILE + r"$"],
           lambda a: [["purge", *a["file"].split()]],
           "Remove a file from EVERY commit in history (for leaked secrets, huge files)",
           keywords=["purge", "history", "forever", "permanently", "everywhere", "scrub", "wipe"],
           danger=True,
           examples=["remove secrets.env from all history", "purge big.zip"]),

    # ---------------------------------------------------------------- undo
    Intent("undo",
           [r"^(undo|revert|reverse|roll ?back|take back|cancel|oops|go back|back)( that| it| this| my| the)?( last| previous| recent)?( (action|change|thing|command|step|operation|commit|save|mistake|merge|reset|purge))?$",
            r"^(undo|go back|roll ?back) " + NUM + r"( steps| times| actions| commands)?$",
            r"^i (made a mistake|messed up|broke (it|something))$"],
           lambda a: [["undo", *([a["n"]] if a.get("n") else [])]],
           "Reverse the last HIT action",
           keywords=["undo", "revert", "rollback", "oops", "mistake", "take back", "cancel"],
           examples=["undo", "oops", "undo 2 steps"]),

    Intent("redo",
           [r"^(redo|re-do|do it again|bring (it|that) back|undo (the|my) undo)$"],
           lambda a: [["redo"]],
           "Re-apply the last undone action",
           keywords=["redo"],
           examples=["redo"]),

    Intent("uncommit",
           [r"^(undo|remove|drop|cancel|take back|delete)( the| my)? (last|latest|previous|recent) (commit|save|checkpoint)( but keep( my| the)? (changes|files|work))?$",
            r"^(go|move) back (to (the |my )?)?(previous|last|earlier) (commit|version|save|checkpoint)$",
            r"^uncommit$"],
           lambda a: [["reset", "--soft", "HEAD~1"]],
           "Remove the last commit but keep all its changes in your files",
           keywords=["uncommit", "last commit", "previous commit", "back to previous"],
           examples=["undo my last commit", "go back to previous commit"]),

    Intent("discard",
           [r"^(discard|throw away|drop|trash|forget|scrap|delete|remove|get rid of|cancel)( all| my| the| these| any)?( local| current| uncommitted| unsaved)? (changes?|edits?|work|modifications)$",
            r"^(reset|restore|revert) (everything|all files|all) (to|back to) (the )?(last|latest|previous) (commit|save|version|checkpoint)$",
            r"^(start|go) (over|fresh|clean)$"],
           lambda a: [["reset", "--hard", "HEAD"]],
           "Throw away all uncommitted changes and go back to the last commit",
           keywords=["discard", "throw away", "start over", "fresh", "uncommitted"],
           danger=True,
           examples=["discard my changes", "start over"]),

    Intent("restore_file",
           [r"^(restore|revert|reset|undo( changes (to|in))?|get back|recover|fix|bring back) " + FILE + r"( (to|back to|from) (the )?(last|latest|previous|" + REV + r")( commit| save| version)?)?$",
            r"^(undo|discard|throw away)( my| the)? (changes|edits) (to|in|on) " + FILE + r"$"],
           lambda a: [["checkout", *([a["rev"]] if a.get("rev") and a["rev"] not in ("last", "latest", "previous") else []), "--", *a["file"].split()]],
           "Put a file back to how it was in the last commit (or a chosen commit)",
           keywords=["restore", "recover", "bring back", "get back", "revert file"],
           examples=["restore app.py", "undo changes to index.html", "get back config.json from a1b2c3"]),

    # ---------------------------------------------------------------- branches
    Intent("branch_create",
           [r"^(create|make|start|new|open|add|begin)( a| new| another)? (branch|feature|line|experiment)( (called|named|for|:) )?" + BRANCH + r"$",
            r"^(start|begin) (working|work) on " + BRANCH + r"$",
            r"^(branch|new branch) " + BRANCH + r"$"],
           lambda a: [["switch", "-c", a["branch"]]],
           "Create a new branch and switch to it",
           keywords=["new branch", "create branch", "feature", "start working on"],
           examples=["create a branch called dark-mode", "start working on login-page"]),

    Intent("branch_list",
           [r"^(show|list|see|view|display|what|which)( me)?( are)?( the| my| all)? (branches|branch list)( do i have| exist)?\??$",
            r"^branches$", r"^(what|which) branch( am i on)?\??$"],
           lambda a: [["branch"]],
           "List all branches",
           keywords=["branches", "branch list", "which branch"],
           examples=["show branches", "which branch am i on"]),

    Intent("switch",
           [r"^(switch|go|move|jump|change|checkout|hop|get)( over| back)?( to)?( the)?( branch)? " + BRANCH + r"( branch)?$",
            r"^(open|use|work on|continue on) (the )?" + BRANCH + r"( branch)?$"],
           lambda a: [["switch", a["branch"]]],
           "Switch to another branch",
           keywords=["switch", "go to", "move to", "checkout", "change branch"],
           examples=["switch to main", "go to dark-mode"]),

    Intent("branch_delete",
           [r"^(delete|remove|drop|kill|get rid of|close)( the)? (branch )?" + BRANCH + r" branch$",
            r"^(delete|remove|drop|kill|get rid of|close)( the)? branch " + BRANCH + r"$"],
           lambda a: [["branch", "-d", a["branch"]]],
           "Delete a branch",
           keywords=["delete branch", "remove branch"],
           danger=True,
           examples=["delete branch old-feature"]),

    Intent("branch_rename",
           [r"^rename( the)?( current)? branch( " + BRANCH + r")? (to|as) (?P<new>[\w./-]+)$"],
           lambda a: [["branch", "-m", *([a["branch"]] if a.get("branch") else []), a["new"]]],
           "Rename a branch",
           keywords=["rename branch"],
           examples=["rename branch to main"]),

    Intent("merge",
           [r"^(merge|combine|join|bring|integrate|apply|include)( in| the| branch)? " + BRANCH + r"( branch)?( (into|to|with|in|onto)( the| this| current| my)? ?(branch |" + REV + r")?)?$",
            r"^(merge|combine)( the)? (changes|work) (from|of|in) " + BRANCH + r"$"],
           lambda a: [["merge", a["branch"]]],
           "Merge another branch into the current one",
           keywords=["merge", "combine", "integrate", "join"],
           examples=["merge dark-mode into main", "merge the feature branch"]),

    Intent("merge_abort",
           [r"^(abort|cancel|stop|quit|give up( on)?)( the| this)? merge$"],
           lambda a: [["merge", "--abort"]],
           "Cancel a merge in progress",
           keywords=["abort merge", "cancel merge"],
           examples=["cancel the merge"]),

    Intent("merge_continue",
           [r"^(continue|finish|complete|resolve|done( with)?)( the| this)? merge$",
            r"^(i )?(fixed|resolved)( the)? conflicts?$"],
           lambda a: [["merge", "--continue"]],
           "Finish a merge after fixing conflicts",
           keywords=["continue merge", "finish merge", "resolved conflicts"],
           examples=["finish the merge", "i fixed the conflicts"]),

    # ---------------------------------------------------------------- tags
    Intent("tag",
           [r"^(tag|mark|label|name|release)( this| the current| the latest| the last| current)?( commit| version| state)?( as| with| called| version)? (?P<tag>v?[\w.-]+)$"],
           lambda a: [["tag", a["tag"]]],
           "Give the current commit a name (like v1.0)",
           keywords=["tag", "release", "label", "version"],
           examples=["tag this as v1.0", "release v2.0"]),

    # ---------------------------------------------------------------- stash
    Intent("stash",
           [r"^(stash|shelve|park|set aside|put aside|hide|hold|pause|save (for later|temporarily))( my| the| these| all)?( changes?| work| edits| stuff)?( for later| temporarily| for now)?$"],
           lambda a: [["stash"]],
           "Set your uncommitted changes aside temporarily (get them back with 'unstash')",
           keywords=["stash", "shelve", "set aside", "park", "for later"],
           examples=["stash my changes", "set aside my work for now"]),

    Intent("stash_pop",
           [r"^(unstash|unshelve|restore|bring back|get back|reapply|apply|pop|continue|resume)( my| the)?( stashed| shelved| parked| set aside| saved)?( changes| work| edits| stash| stuff)?$"],
           lambda a: [["stash", "pop"]],
           "Bring back the changes you set aside",
           keywords=["unstash", "bring back", "pop", "resume"],
           examples=["bring back my stashed changes", "unstash"]),

    # ---------------------------------------------------------------- snapshot
    Intent("snapshot",
           [r"^(backup|back up|snapshot|archive|export|save)( the| this| my| whole| entire| full| complete)?( whole| entire| full)? ?(repo|repository|project|history|everything)( (as|called|named|to) (?P<name>[\w.-]+))?$",
            r"^(take|make|create) a (backup|snapshot)( (as|called|named) (?P<name>[\w.-]+))?$"],
           lambda a: [["snapshot", *([a["name"]] if a.get("name") else [])]],
           "Save the whole repository history into one backup file",
           keywords=["backup", "snapshot", "archive", "export everything"],
           examples=["backup the whole project", "take a snapshot called before-refactor"]),

    Intent("snapshot_list",
           [r"^(show|list|see|view|what)( me)?( are)?( the| my| all)? (backups|snapshots)( do i have)?\??$"],
           lambda a: [["snapshot", "list"]],
           "List saved snapshots",
           keywords=["snapshots", "backups"],
           examples=["list backups"]),

    Intent("restore_snapshot",
           [r"^(restore|load|go back to|recover|rollback to|roll back to|bring back|use)( the| my)? (backup|snapshot) (?P<name>[\w.-]+)$",
            r"^(restore|load|recover) (?P<name>[\w.-]+) (backup|snapshot)$"],
           lambda a: [["restore", a["name"]]],
           "Bring the whole repository back to a saved snapshot",
           keywords=["restore snapshot", "load backup", "recover"],
           danger=True,
           examples=["restore snapshot before-refactor"]),

    # ---------------------------------------------------------------- remote
    Intent("push",
           [r"^(push|upload|send|sync|publish|share|put|deploy|ship|submit)( up)?( all| my| the| this| everything| our)?( code| changes?| commits?| work| project| repo| stuff| files)?( up)?( to| on| onto| into)?( github| the cloud| remote| origin| the server| online| gh)?( (at|to|url|repo)? ?(?P<url>(https?://|git@)\S+))?( (as|to|on|branch) (?P<branch>[\w./-]+)( branch)?)?$",
            r"^(push|upload|send|sync|publish|share|deploy).*?(?P<url>(https?://|git@)\S+)( (as|to|on|branch)? ?(?P<branch>[\w./-]+)( branch)?)?$",
            r"^(push|upload|send)( it)?$"],
           lambda a: [["push", *([a["url"]] if a.get("url") else []), *([a["branch"]] if a.get("branch") else [])]],
           "Upload your commits to GitHub",
           keywords=["push", "upload", "send", "github", "publish", "sync", "share"],
           examples=["push to github", "send my code to github", "push to https://github.com/you/repo.git main"]),

    Intent("pull",
           [r"^(pull|download|fetch|get|grab|sync|update|refresh|receive)( down)?( the| all| any| my| new)?( latest| newest| new| remote)?( code| changes?| commits?| updates?| work| version)?( down)?( from| off)?( github| remote| origin| the server| the cloud| gh| online| git)?$",
            r"^(pull|get|fetch|retrieve|download)( everything| all( the)? (files|folders|code))? (from |off )?(github|git)( to (here|this folder|my (pc|computer)))?$",
            r"^(what'?s|is there anything) new on github\??$", r"^(update|sync) (from|with) github$"],
           lambda a: [["pull"]],
           "Download new commits from GitHub and merge them in",
           keywords=["pull", "download", "fetch", "latest", "update from github"],
           examples=["pull from github", "get the latest changes"]),

    Intent("import",
           [r"^(?=.*\b(git|\.git)\b)(import|adopt|take over|convert|migrate|use|open|load|read|bring|get|show|see|list|retrieve|pull)( me)?( all| this| the| my| an?| existing| every)?( git| \.git| old)?( commits?| repo| repository| project| folder| history| logs?| files)?( (from|of|in|made by|saved by|committed by) git)?( (into|to|with|in) (hit|our ui|the ui|the dashboard))?$",
            r"^(show|see|get|retrieve)( me)?( all)?( the)? (files|folders|commits|history) (saved|tracked|made|committed) (by|in|with) git$",
            r"^(this|it) (is|was) a git (repo|project)$"],
           lambda a: [["import"]],
           "Bring an existing Git project (.git folder) into HIT so its commits and files show in the dashboard",
           keywords=["import", "git repo", "existing git", ".git", "saved by git"],
           examples=["import this git repo", "show files saved by git"]),

    Intent("clone",
           [r"^(clone|copy|download|get|grab)( the| a| this)?( repo| repository| project)? (?P<url>(https?://|git@)\S+|[\w.-]+/[\w.-]+)( (to|into|as) (?P<dir>\S+))?$"],
           lambda a: [["clone", a["url"], *([a["dir"]] if a.get("dir") else [])]],
           "Download a repository from GitHub",
           keywords=["clone", "copy repo"],
           examples=["clone https://github.com/user/repo", "clone user/repo"]),

    Intent("remote_add",
           [r"^(connect|link|attach|set|add|use|point)( this| my| the)?( repo| project)?( to| with)?( github| remote| origin| the url)?( at| to| as)? ?(?P<url>(https?://|git@)\S+|[\w.-]+/[\w.-]+)$",
            r"^(set|add|change|update)( the)? (remote|github url|origin)( to| as)? (?P<url>\S+)$"],
           lambda a: [["remote", "add", "origin", a["url"]]],
           "Connect this project to a GitHub repository",
           keywords=["connect", "link", "remote", "github url", "origin"],
           examples=["connect to https://github.com/me/repo", "set remote to me/repo"]),

    Intent("remote_list",
           [r"^(show|list|see|what|which|where)( me)?( is| are)?( the| my)? (remotes?|github( url| repo| link)?|origin|upstream)( is this connected to| am i connected to| url)?\??$"],
           lambda a: [["remote"]],
           "Show which GitHub repository this project is connected to",
           keywords=["remote", "github url", "where does this push"],
           examples=["where does this push to", "show remote"]),

    Intent("login",
           [r"^(login|log in|sign in|signin|authenticate|auth|connect account|set token|add token|save token)( to| with| for)?( github| gh)?$"],
           lambda a: [["login"]],
           "Save your GitHub token so push/pull can authenticate",
           keywords=["login", "sign in", "token", "authenticate"],
           examples=["login to github"]),

    # ---------------------------------------------------------------- misc
    Intent("ignore",
           [r"^(ignore|skip|exclude|don'?t track|do not track|never track|stop tracking|hide) " + FILE + r"( (files?|folders?|forever|always|from now on))?$"],
           lambda a: [["ignore", *a["file"].split()]],
           "Tell HIT to never track these files (adds to .hitignore)",
           keywords=["ignore", "exclude", "skip", "never track"],
           examples=["ignore node_modules", "don't track *.log"]),

    Intent("scan",
           [r"^(scan|find|search|discover|look for|locate|detect|collect|gather|pull|get|import|load)( for| all| every| me)?( all| every| the| my| each)?( local| existing| saved| old)?( git| hit| git and hit)?( projects?| repos?| repositories| commits| work| history)( (on|in|from|across) (this|my|the) (pc|computer|machine|laptop|system|disk|drive|drives|local|local machine))?( (and|then) (show|list|add)( them)?( (in|to) (the )?(ui|dashboard|list))?)?$",
            r"^(pull|get|import|load) (all|everything)( of (them|it))?$",
            r"^(where are|find) (all )?my (git )?(projects|repos)$"],
           lambda a: [["scan"]],
           "Search this computer for every Git/HIT project and add them all to the dashboard",
           keywords=["scan", "find projects", "all projects", "all repos", "git projects", "search"],
           examples=["find all my git projects", "pull all projects on this pc"]),

    Intent("self_update",
           [r"^(update|upgrade)( the)? (hit|this app|this tool|hit itself|to the latest( version)?)$",
            r"^(check|look|search)( for)?( an?| any| new)? (updates?|new versions?|latest version)$",
            r"^(is there|any) (an? )?(update|new version|newer version)( of hit)?( available)?\??$",
            r"^(install|get)( the)? (latest|newest) (hit|version)$"],
           lambda a: [["update", "--check"]] if a.get("_text", "").startswith(("check", "look", "search", "is there", "any")) else [["update"]],
           "Check for (and install) the newest version of HIT",
           keywords=["update hit", "new version", "latest version", "upgrade"],
           examples=["check for updates", "update hit"]),

    Intent("projects",
           [r"^(show|list|see|view|what|which)( me)?( are)?( all| the| my)? (projects|repos|repositories)( do i have| on this (pc|machine|computer))?\??$",
            r"^(projects|repos)$", r"^(where are|find) (all )?my (projects|repos)$"],
           lambda a: [["projects"]],
           "List all HIT projects on this computer",
           keywords=["projects", "repos", "all my projects"],
           examples=["show all my projects"]),

    Intent("ui",
           [r"^(open|show|start|launch|run|go to)( the| a| me)?( all| every)?( my)? ?(projects? )?(ui|dashboard|interface|screen|visual( mode)?|tui|gui|browser|explorer|window)( (with|for|of) (all|every)( my| the)? projects)?$",
            r"^(ui|dashboard|visual)$"],
           lambda a: [["ui", "all"] if "all" in a.get("_text", "") or "every" in a.get("_text", "") else ["ui"]],
           "Open the terminal dashboard",
           keywords=["ui", "dashboard", "visual", "screen"],
           examples=["open the dashboard"]),

    Intent("config_user",
           [r"^(set|change|update|configure)( my)? (name|username|author)( to| as| =)? ['\"]?(?P<name>[^'\"]+?)['\"]?$",
            r"^(i am|i'm|my name is|call me) ['\"]?(?P<name>[^'\"]+?)['\"]?$"],
           lambda a: [["config", "user.name", a["name"]]],
           "Set the name used on your commits",
           keywords=["my name is", "set name", "author"],
           examples=["my name is Ravi", "set my name to Ravi"]),

    Intent("config_email",
           [r"^(set|change|update|configure)( my)? (email|e-mail|mail)( to| as| =)? (?P<email>\S+@\S+)$",
            r"^my (email|e-mail|mail) is (?P<email>\S+@\S+)$"],
           lambda a: [["config", "user.email", a["email"]]],
           "Set the email used on your commits",
           keywords=["my email is", "set email"],
           examples=["my email is me@example.com"]),

    Intent("squash",
           [r"^(squash|combine|merge|collapse|flatten|join)( the| my| all)?( last| latest| recent)?( " + NUM + r")? (commits|saves|checkpoints)( into (one|1|a single( commit)?))?( (as|with message|called|:) ['\"]?" + MSG + r"['\"]?)?$",
            r"^(squash|flatten)( all)? history$"],
           lambda a: [["squash", *(["-n", a["n"]] if a.get("n") else []), *(["-m", a["message"]] if a.get("message") else [])]],
           "Combine several commits into one",
           keywords=["squash", "combine commits", "flatten", "into one"],
           danger=True,
           examples=["squash last 3 commits into one", "squash all commits as v1"]),

    Intent("help",
           [r"^(help|help me|what can (you|i) do|what can hit do|commands?|list commands|how do i use (this|hit)|i'?m (lost|confused|stuck)|what now|\?)$"],
           lambda a: [["help", "me"]],
           "Show an interactive helper",
           keywords=["help", "lost", "confused", "stuck", "commands"],
           examples=["help me", "i'm stuck"]),

    Intent("explain",
           [r"^(explain|what is|what does|what'?s|tell me about|describe|meaning of|how does|define)( the| a)? (?P<cmd>[\w -]+?)( command| do| mean| work)?\??$"],
           lambda a: [["explain", *a["cmd"].split()]],
           "Explain what a command does in plain English",
           keywords=["explain", "what is", "what does", "meaning"],
           examples=["explain merge", "what does reset --hard do"]),

    Intent("why",
           [r"^(why|why did (that|it) (fail|happen|break)|what went wrong|what happened|what was that error|explain (the|that|last) error|huh)\??$"],
           lambda a: [["why"]],
           "Explain the last error in plain English",
           keywords=["why", "went wrong", "error", "failed"],
           examples=["why", "what went wrong"]),
]

# Order matters: more specific intents must be tried before general ones.
_PRIORITY = ["self_update", "wipe", "ui", "purge", "uncommit", "uninit", "scan", "import", "stash_pop", "merge_abort", "merge_continue", "branch_delete",
             "branch_rename", "restore_snapshot", "snapshot_list", "remote_list", "remote_add",
             "branch_create", "branch_list", "squash", "amend", "discard", "config_email", "config_user"]
INTENTS.sort(key=lambda i: _PRIORITY.index(i.name) if i.name in _PRIORITY else len(_PRIORITY))

BY_NAME = {i.name: i for i in INTENTS}
