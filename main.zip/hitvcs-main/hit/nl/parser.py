"""Turn an English sentence into HIT commands.

Strategy (all offline):
  1. normalize the sentence (lowercase, strip filler words and punctuation)
  2. try every intent's regex patterns on the normalized AND the raw sentence
  3. if nothing matched, score intents by keyword overlap (with fuzzy word
     matching for typos) and return the best guess with lower confidence
"""
from __future__ import annotations

import difflib
import re
from dataclasses import dataclass, field

from .intents import BY_NAME, FILLER, INTENTS, Intent

# words that appear as the actual command name in the CLI
COMMAND_NAMES = ["init", "add", "status", "diff", "commit", "log", "branch", "switch", "checkout",
                 "merge", "tag", "reset", "stash", "ignore", "files", "rm", "purge", "snapshot",
                 "restore", "undo", "redo", "push", "pull", "fetch", "clone", "remote", "login",
                 "logout", "projects", "ui", "config", "squash", "explain", "why", "help", "drop",
                 "version", "unstage", "uninit", "import", "scan", "wipe", "update"]


@dataclass
class ParsedCommand:
    intent: Intent | None
    commands: list[list[str]]      # each is argv for one hit command
    confidence: float              # 1.0 = exact pattern; <0.8 = guess
    args: dict[str, str] = field(default_factory=dict)
    alternatives: list[Intent] = field(default_factory=list)

    @property
    def danger(self) -> bool:
        return bool(self.intent and self.intent.danger)

    def pretty(self) -> str:
        return "  &&  ".join("hit " + " ".join(_quote(a) for a in c) for c in self.commands)


def _quote(a: str) -> str:
    return f'"{a}"' if (" " in a or not a) else a


def normalize(text: str) -> str:
    t = text.strip()
    t = re.sub(r"[?!.]+$", "", t).strip()
    t = re.sub(r"\s+", " ", t)
    return t


def strip_filler(text: str, keep_quotes: bool = True) -> str:
    # keep quoted segments intact
    parts = re.split(r"(\"[^\"]*\"|'[^']*')", text)
    out = []
    for i, part in enumerate(parts):
        if i % 2 == 1:
            out.append(part)
            continue
        words = [w for w in part.split() if w.lower() not in FILLER]
        out.append(" ".join(words))
    return re.sub(r"\s+", " ", " ".join(out)).strip()


def _try_patterns(intent: Intent, candidates: list[str]) -> dict[str, str] | None:
    for pat in intent._compiled:
        for cand in candidates:
            m = pat.match(cand)
            if m:
                args = {k: v.strip().strip("'\"") for k, v in m.groupdict().items() if v}
                return args
    return None


def _keyword_score(intent: Intent, words: list[str]) -> float:
    score = 0.0
    text = " ".join(words)
    for kw in intent.keywords:
        if " " in kw:
            if kw in text:
                score += 2.0
            continue
        for w in words:
            if w == kw:
                score += 1.0
            elif len(w) > 3 and difflib.SequenceMatcher(None, w, kw).ratio() > 0.8:
                score += 0.7
    return score


def parse(text: str) -> ParsedCommand:
    raw = normalize(text)
    stripped = strip_filler(raw)
    # a version of the sentence with a possible trailing message extracted
    candidates = [stripped, raw]
    if stripped != raw:
        candidates.append(re.sub(r"^(hit|hey|please|pls) ", "", raw))

    # 1. exact patterns
    for intent in INTENTS:
        args = _try_patterns(intent, candidates)
        if args is not None:
            args["_text"] = raw.lower()
            cmds = intent.build(args)
            args.pop("_text", None)
            return ParsedCommand(intent, cmds, 1.0, args)

    # 2. keyword voting
    words = stripped.lower().split()
    scored = sorted(((_keyword_score(i, words), i) for i in INTENTS), key=lambda x: -x[0])
    best_score, best = scored[0]
    if best_score >= 0.7:
        args = _guess_args(best, raw, stripped)
        try:
            cmds = best.build(args)
        except KeyError:
            cmds = []
        alts = [i for s, i in scored[1:4] if s >= 1.0]
        conf = min(0.75, 0.4 + best_score * 0.1)
        return ParsedCommand(best, cmds, conf, args, alts)

    return ParsedCommand(None, [], 0.0, {}, [i for s, i in scored[:3] if s > 0])


def _guess_args(intent: Intent, raw: str, stripped: str) -> dict[str, str]:
    """Best-effort argument extraction when only keywords matched."""
    args: dict[str, str] = {}
    m = re.search(r"(?:as|called|named|message|msg|saying|:)\s+['\"]?(.+?)['\"]?$", raw, re.I)
    if m:
        args["message"] = m.group(1)
    q = re.search(r"[\"'](.+?)[\"']", raw)
    if q:
        args["message"] = q.group(1)
    files = re.findall(r"\b[\w-]+\.[a-z0-9]{1,5}\b|\b[\w-]+/[\w./-]*", raw)
    if files:
        args["file"] = " ".join(files)
    b = re.search(r"(?:branch|to|on|into)\s+([\w./-]+)$", stripped, re.I)
    if b and b.group(1) not in ("github", "remote", "origin", "one"):
        args["branch"] = b.group(1)
    n = re.search(r"\b(\d+)\b", raw)
    if n:
        args["n"] = n.group(1)
    u = re.search(r"((?:https?://|git@)\S+|\b[\w.-]+/[\w.-]+\b)", raw)
    if u and intent.name in ("clone", "remote_add"):
        args["url"] = u.group(1)
    if intent.name == "tag":
        t = re.search(r"\b(v?\d[\w.-]*)$", raw)
        if t:
            args["tag"] = t.group(1)
    if intent.name in ("snapshot", "restore_snapshot"):
        s = re.search(r"(?:as|called|named|snapshot|backup)\s+([\w.-]+)$", raw)
        if s:
            args["name"] = s.group(1)
    if intent.name == "explain":
        args["cmd"] = re.sub("explain", "", stripped, flags=re.I).strip() or "hit"
    return args


def suggest_commands(word: str, n: int = 3) -> list[str]:
    """Did-you-mean for a misspelled command name."""
    return difflib.get_close_matches(word.lower(), COMMAND_NAMES, n=n, cutoff=0.6)


def is_command_word(word: str) -> bool:
    return word.lower() in COMMAND_NAMES
