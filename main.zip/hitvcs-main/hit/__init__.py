"""HIT — a local-first, Git-compatible version control system that speaks English."""
__version__ = "0.4.0"
