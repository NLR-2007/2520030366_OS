"""Small modal dialogs used by the dashboard."""
from __future__ import annotations

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Input, Label, OptionList, Static
from textual.widgets.option_list import Option


class Confirm(ModalScreen[bool]):
    """Yes / No question."""

    BINDINGS = [Binding("y", "yes", "Yes"), Binding("n,escape", "no", "No")]

    def __init__(self, title: str, body: str = "", yes_label: str = "Yes", danger: bool = False):
        super().__init__()
        self.title_text = title
        self.body_text = body
        self.yes_label = yes_label
        self.danger = danger

    def compose(self) -> ComposeResult:
        with Vertical(id="dialog", classes="danger" if self.danger else ""):
            yield Label(self.title_text, id="dialog-title")
            if self.body_text:
                yield Static(self.body_text, id="dialog-body")
            with Horizontal(id="dialog-buttons"):
                yield Button(self.yes_label, variant="error" if self.danger else "primary", id="yes")
                yield Button("Cancel", id="no")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss(event.button.id == "yes")

    def action_yes(self) -> None:
        self.dismiss(True)

    def action_no(self) -> None:
        self.dismiss(False)


class Choice(ModalScreen[int | None]):
    """Pick one of several options (returns index, or None)."""

    BINDINGS = [Binding("escape", "cancel", "Cancel")]

    def __init__(self, title: str, options: list[str], body: str = ""):
        super().__init__()
        self.title_text = title
        self.body_text = body
        self.options = options

    def compose(self) -> ComposeResult:
        with Vertical(id="dialog"):
            yield Label(self.title_text, id="dialog-title")
            if self.body_text:
                yield Static(self.body_text, id="dialog-body")
            yield OptionList(*[Option(f"{i + 1}. {o}", id=str(i)) for i, o in enumerate(self.options)], id="choices")
            yield Static("[dim]Enter to choose · Esc to cancel[/]")

    def on_mount(self) -> None:
        self.query_one(OptionList).focus()

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        self.dismiss(int(event.option.id))

    def on_key(self, event) -> None:
        if event.key.isdigit():
            i = int(event.key) - 1
            if 0 <= i < len(self.options):
                self.dismiss(i)

    def action_cancel(self) -> None:
        self.dismiss(None)


class Prompt(ModalScreen[str | None]):
    """Ask for one line of text."""

    BINDINGS = [Binding("escape", "cancel", "Cancel")]

    def __init__(self, title: str, placeholder: str = "", default: str = "", password: bool = False):
        super().__init__()
        self.title_text = title
        self.placeholder = placeholder
        self.default = default
        self.password = password

    def compose(self) -> ComposeResult:
        with Vertical(id="dialog"):
            yield Label(self.title_text, id="dialog-title")
            yield Input(value=self.default, placeholder=self.placeholder, password=self.password, id="prompt-input")
            yield Static("[dim]Enter to confirm · Esc to cancel[/]")

    def on_mount(self) -> None:
        self.query_one(Input).focus()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        self.dismiss(event.value.strip() or None)

    def action_cancel(self) -> None:
        self.dismiss(None)


class TextView(ModalScreen[None]):
    """Scrollable read-only text (help, output, explain)."""

    BINDINGS = [Binding("escape,q,enter", "close", "Close")]

    def __init__(self, title: str, text: str):
        super().__init__()
        self.title_text = title
        self.text = text

    def compose(self) -> ComposeResult:
        from textual.containers import VerticalScroll
        with Vertical(id="dialog", classes="wide"):
            yield Label(self.title_text, id="dialog-title")
            with VerticalScroll(id="dialog-scroll"):
                yield Static(self.text, id="dialog-body", markup=False)
            yield Static("[dim]Esc to close[/]")

    def action_close(self) -> None:
        self.dismiss(None)
