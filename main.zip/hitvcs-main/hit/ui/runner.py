"""Run HIT CLI commands from inside the TUI, capturing their output."""
from __future__ import annotations

import contextlib
import io
import os
import re
from pathlib import Path

ANSI = re.compile(r"\x1b\[[0-9;]*m")


def run_command(argv: list[str], cwd: Path, assume_yes: bool = True) -> tuple[int, str]:
    """Run one exact `hit` command in-process. Returns (exit_code, plain_text_output).

    The TUI has already asked the user to confirm anything dangerous, so
    prompts are auto-answered here. cwd is switched for the duration because
    the CLI resolves paths relative to the current directory.
    """
    from .. import cli
    old_cwd = os.getcwd()
    old_env = os.environ.get("HIT_FORCE_YES")
    buf = io.StringIO()
    try:
        os.chdir(cwd)
        if assume_yes:
            os.environ["HIT_FORCE_YES"] = "1"
        cli.USE_COLOR = False
        with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
            try:
                code = cli._run_exact(argv)
            except cli.ArgError as e:
                print(f"error: {e}")
                code = 2
            except SystemExit as e:
                code = int(e.code or 0)
            except Exception as e:  # noqa: BLE001
                print(f"error: {e}")
                code = 1
    finally:
        os.chdir(old_cwd)
        if old_env is None:
            os.environ.pop("HIT_FORCE_YES", None)
        else:
            os.environ["HIT_FORCE_YES"] = old_env
    return code, ANSI.sub("", buf.getvalue()).replace("\r", "")
