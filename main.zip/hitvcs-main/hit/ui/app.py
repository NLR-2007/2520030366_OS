"""`hit ui` — the terminal dashboard.

Level 1  Projects   every HIT repo on this computer
Level 2  Repo       branches | commits | files-in-commit, with diff preview
                    and a command bar that takes exact commands OR English
"""
from __future__ import annotations

import os
from pathlib import Path

from rich.text import Text
from textual import work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import Screen
from textual.widgets import DataTable, Footer, Header, Input, RichLog, Static, Tree

from .. import registry
from ..logo import rich_header
from ..repo import HIT_DIR, HitError, Repository
from .modals import Choice, Confirm, Prompt, TextView
from .runner import run_command

CSS = """
Screen { layout: vertical; }
#body { height: 1fr; }
#left { width: 22%; min-width: 22; border: round $primary; }
#middle { width: 40%; border: round $primary; }
#right { width: 38%; border: round $primary; }
#preview { height: 32%; border: round $secondary; padding: 0 1; }
#cmdbar { dock: bottom; height: 3; }
#cmdbar Input { width: 1fr; }
#status { height: 1; padding: 0 1; background: $surface; color: $text-muted; }
DataTable { height: 1fr; }
Tree { height: 1fr; }
#projects { height: 1fr; border: round $primary; }
#dialog {
  width: 70; max-width: 90%; height: auto; max-height: 80%;
  border: thick $primary; background: $surface; padding: 1 2;
}
#dialog.wide { width: 100; }
#dialog.danger { border: thick $error; }
#dialog-title { text-style: bold; margin-bottom: 1; }
#dialog-body { margin-bottom: 1; }
#dialog-buttons { height: 3; align: center middle; }
#dialog-buttons Button { margin: 0 1; }
#dialog-scroll { height: auto; max-height: 30; }
#choices { height: auto; max-height: 20; }
.title { text-style: bold; color: $accent; padding: 0 1; }
#brand { height: auto; padding: 1 1 1 1; color: $text; }
"""


def rel_time(ts: int) -> str:
    from ..cli import relative_time
    return relative_time(ts) if ts else "-"


def hsize(n: int) -> str:
    from ..cli import human_size
    return human_size(n)


# ==========================================================================
# Level 1: projects
# ==========================================================================

class ProjectsScreen(Screen):
    BINDINGS = [
        Binding("enter", "open", "Open"),
        Binding("d", "delete", "Delete"),
        Binding("s", "snapshot", "Snapshot"),
        Binding("f", "scan", "Find all projects"),
        Binding("g", "get_github", "Get from GitHub"),
        Binding("a", "add", "Add folder", show=False),
        Binding("r", "refresh", "Refresh", show=False),
        Binding("slash", "search", "Search", show=False),
        Binding("question_mark", "help", "Help"),
        Binding("q", "quit", "Quit"),
    ]

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Static(rich_header(["", "[b]HIT[/b]  Version Control", "[dim]An NLR Product · Made with 💖 For Developers[/dim]"]), id="brand")
        yield Static("Your projects on this computer   [dim]· most recent first (last commit or last used)[/dim]", classes="title")
        yield DataTable(id="projects", cursor_type="row", zebra_stripes=True)
        yield Static("", id="status")
        with Horizontal(id="cmdbar"):
            yield Input(placeholder="> project name to open, or text to filter", id="cmd")
        yield Footer()

    def on_mount(self) -> None:
        t = self.query_one(DataTable)
        t.add_columns("", "Project", "Branch", "Last commit", "Last activity", "Commits", "GitHub", "Size", "Path")
        self.load()
        t.focus()

    def load(self) -> None:
        t = self.query_one(DataTable)
        t.clear()
        self.items = registry.projects(with_stats=False)   # instant: names, branch, last commit
        for p in self.items:
            if not p.exists:
                t.add_row(Text("✗", style="red"), p.name, "-", Text("(folder missing)", style="red"),
                          "-", "-", "-", "-", p.path, key=p.path)
                continue
            name = Text(p.name, style="bold")
            if p.kind == "git":
                name.append("  [git]", style="dim")
            wait = Text("…", style="dim")
            when = Text(rel_time(p.recency))
            if p.last_used > p.last_time:
                when.append("  (used)", style="dim")
            t.add_row(Text("●", style="dim"), name, p.branch or "-", p.last_message[:40],
                      when, wait, wait, wait, Text(p.path, style="dim"), key=p.path)
        if not self.items:
            self.query_one("#status", Static).update(
                "No projects yet. Run `hit init` in a folder, press `a` to add one, or `f` to find all Git projects.")
        else:
            self.query_one("#status", Static).update(f"{len(self.items)} project(s)   [dim]loading details…[/]")
            self.fill_stats()

    @work(thread=True, exclusive=True)
    def fill_stats(self) -> None:
        """Compute the slow columns one project at a time, off the UI thread."""
        from textual.worker import get_current_worker
        worker = get_current_worker()
        for p in self.items:
            if worker.is_cancelled:
                return
            if not p.exists:
                continue
            registry.full_stats(p)
            self.app.call_from_thread(self._update_row, p)
        self.app.call_from_thread(self._update_summary)

    def _update_row(self, p: registry.ProjectInfo) -> None:
        t = self.query_one(DataTable)
        try:
            cols = t.ordered_columns
            t.update_cell(p.path, cols[0].key, Text("●", style="yellow" if p.dirty else "green"))
            t.update_cell(p.path, cols[5].key, str(p.commits))
            if p.github in ("-", "?", ""):
                gh = Text(p.github or "?", style="dim")
            elif p.github == "pushed":
                gh = Text("✓ pushed", style="green")
            else:
                gh = Text("✗ " + p.github, style="yellow")
            t.update_cell(p.path, cols[6].key, gh)
            t.update_cell(p.path, cols[7].key, hsize(p.size))
        except Exception:
            pass   # row may have been removed by a reload

    def _update_summary(self) -> None:
        clean = sum(1 for p in self.items if p.exists and p.stats_done and not p.dirty)
        dirty = sum(1 for p in self.items if p.exists and p.dirty)
        self.query_one("#status", Static).update(
            f"{len(self.items)} project(s)   [green]●[/] {clean} clean   [yellow]●[/] {dirty} with uncommitted changes")

    def selected(self) -> registry.ProjectInfo | None:
        t = self.query_one(DataTable)
        if t.row_count == 0:
            return None
        key = t.coordinate_to_cell_key(t.cursor_coordinate).row_key.value
        for p in self.items:
            if p.path == key:
                return p
        return None

    # ---- actions --------------------------------------------------------

    def action_open(self) -> None:
        p = self.selected()
        if not p or not p.exists:
            return
        registry.touch(Path(p.path))
        self.app.push_screen(RepoScreen(Path(p.path)))

    def on_data_table_row_selected(self, _e) -> None:
        self.action_open()

    def action_refresh(self) -> None:
        self.load()

    def action_help(self) -> None:
        self.app.push_screen(TextView("Help — Projects", HELP_PROJECTS))

    def action_search(self) -> None:
        self.query_one("#cmd", Input).focus()

    @work
    async def action_add(self) -> None:
        path = await self.app.push_screen_wait(Prompt("Folder of a HIT (or Git) project to add", default=os.getcwd()))
        if not path:
            return
        p = Path(path)
        from ..repo import is_repo_dir
        if not is_repo_dir(p):
            self.notify(f"{p} has no .hit or .git repository", severity="error")
            return
        registry.add_path(p)
        self.load()

    @work
    async def action_scan(self) -> None:
        ok = await self.app.push_screen_wait(Confirm(
            "Find every Git / HIT project on this computer?",
            "HIT searches your home folder and all drives for .git / .hit folders and adds them here.\n"
            "Nothing is copied or changed. This can take a minute on large drives.", yes_label="Search"))
        if not ok:
            return
        self.notify("searching… (results appear when done)", timeout=15)
        code, out = run_command(["scan"], Path(os.getcwd()))
        self.load()
        self.app.push_screen(TextView("Projects found", out))

    @work
    async def action_get_github(self) -> None:
        url = await self.app.push_screen_wait(Prompt(
            "Get a project from GitHub — paste the repository URL (or user/repo)",
            placeholder="https://github.com/user/repo.git"))
        if not url:
            return
        name = url.rstrip("/").rsplit("/", 1)[-1]
        name = name[:-4] if name.endswith(".git") else name
        dest = await self.app.push_screen_wait(Prompt("Save it in which folder?", default=str(Path(os.getcwd()) / name)))
        if not dest:
            return
        self.notify(f"downloading {url} …", timeout=10)
        code, out = run_command(["clone", url, dest], Path(os.getcwd()))
        if code:
            self.app.push_screen(TextView("Download failed", out))
            return
        self.load()
        self.app.push_screen(RepoScreen(Path(dest).resolve()))

    @work
    async def action_snapshot(self) -> None:
        p = self.selected()
        if not p or not p.exists:
            return
        name = await self.app.push_screen_wait(Prompt(f"Snapshot name for {p.name}", placeholder="e.g. before-refactor"))
        if name is None:
            return
        code, out = run_command(["snapshot", name], Path(p.path))
        self.notify(out.strip().splitlines()[0] if out.strip() else "done", severity="error" if code else "information")
        self.load()

    @work
    async def action_delete(self) -> None:
        p = self.selected()
        if not p:
            return
        if not p.exists:
            registry.remove_path(Path(p.path))
            self.load()
            return
        choice = await self.app.push_screen_wait(Choice(
            f"Delete '{p.name}' — how much?",
            ["Remove from this list only (nothing on disk changes)",
             "Delete the HIT history (.hit folder) — your files stay",
             "Delete the WHOLE project folder from disk"],
            f"{p.path}"))
        if choice is None:
            return
        if choice == 0:
            registry.remove_path(Path(p.path))
            self.notify(f"removed {p.name} from the list")
        else:
            what = "the .hit history" if choice == 1 else "the ENTIRE folder"
            ok = await self.app.push_screen_wait(Confirm(
                f"Really delete {what} of '{p.name}'?",
                "A snapshot of the history is saved to ~/.hit/trash first, so it can be recovered.",
                yes_label="Delete", danger=True))
            if not ok:
                return
            self._delete_project(Path(p.path), whole=(choice == 2))
        self.load()

    def _delete_project(self, path: Path, whole: bool) -> None:
        import shutil
        import time
        from .. import snapshot
        from ..repo import global_hit_dir
        try:
            repo = Repository(path)
            trash = global_hit_dir() / "trash"
            trash.mkdir(exist_ok=True)
            snap = snapshot.create(repo, f"{path.name}-{time.strftime('%Y%m%d-%H%M%S')}", kind="snapshot",
                                   with_worktree=True)
            shutil.move(str(snap), str(trash / snap.name))
        except Exception as e:  # noqa: BLE001
            self.notify(f"backup failed, nothing deleted: {e}", severity="error")
            return
        target = path if whole else path / HIT_DIR
        shutil.rmtree(target, ignore_errors=True)
        registry.remove_path(path)
        self.notify(f"deleted {'project' if whole else 'history'}; backup in ~/.hit/trash")

    def on_input_submitted(self, event: Input.Submitted) -> None:
        text = event.value.strip()
        event.input.value = ""
        if not text:
            return
        if text in ("?", "help"):
            return self.action_help()
        if text in ("q", "quit", "exit"):
            return self.app.exit()
        # "open <name>" / plain name → open that project
        words = text.split()
        name = words[-1].lower() if words else ""
        for p in self.items:
            if p.exists and (p.name.lower() == name or name in p.name.lower()):
                self.app.push_screen(RepoScreen(Path(p.path)))
                return
        # otherwise filter the table
        t = self.query_one(DataTable)
        t.clear()
        for p in self.items:
            if text.lower() in p.name.lower() or text.lower() in p.path.lower():
                dot = Text("●", style="yellow" if p.dirty else "green")
                t.add_row(dot, p.name, p.branch or "-", p.last_message[:40], rel_time(p.last_time),
                          str(p.commits), "", hsize(p.size), p.path, key=p.path)
        t.focus()


# ==========================================================================
# Level 2: one repository
# ==========================================================================

class RepoScreen(Screen):
    BINDINGS = [
        Binding("escape", "back", "All projects"),
        Binding("enter", "open", "Open", show=False),
        Binding("c", "commit", "Commit"),
        Binding("d", "delete", "Delete"),
        Binding("u", "undo", "Undo"),
        Binding("p", "push", "Push"),
        Binding("b", "branch", "Branch"),
        Binding("s", "snapshot", "Snapshot"),
        Binding("l", "pull", "Pull"),
        Binding("o", "open_github", "GitHub"),
        Binding("D", "purge", "Purge from history", show=False),
        Binding("X", "wipe", "Delete ALL commits", show=False),
        Binding("r", "refresh", "Refresh"),
        Binding("tab", "focus_next", "Next pane", show=False),
        Binding("slash", "cmd", "Type", show=False),
        Binding("question_mark", "help", "Help"),
        Binding("q", "quit", "Quit", show=False),
    ]

    def __init__(self, root: Path):
        super().__init__()
        self.root = root
        self.repo = Repository(root)
        self.current_commit: str | None = None
        self.commits = []

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Static("", classes="title", id="repo-title")
        with Horizontal(id="body"):
            with Vertical(id="left"):
                yield Static("Branches", classes="title")
                yield DataTable(id="branches", cursor_type="row")
            with Vertical(id="middle"):
                yield Static("Commits", classes="title", id="commits-title")
                yield DataTable(id="commits", cursor_type="row", zebra_stripes=True)
            with Vertical(id="right"):
                yield Static("Files in commit", classes="title", id="files-title")
                yield Tree("/", id="files")
        yield RichLog(id="preview", highlight=False, markup=True, wrap=False)
        with Horizontal(id="cmdbar"):
            yield Input(placeholder="> type a command or plain English  (? for help)", id="cmd")
        yield Footer()

    # ---- loading --------------------------------------------------------

    def on_mount(self) -> None:
        self.query_one("#branches", DataTable).add_columns("", "Branch", "Last")
        self.query_one("#commits", DataTable).add_columns("Id", "Message", "When", "Files", "GitHub")
        self.reload()
        self.query_one("#commits", DataTable).focus()
        self._fingerprint = self._repo_fingerprint()
        self.set_interval(2.0, self._poll_repo_changes)

    def _repo_fingerprint(self) -> tuple:
        """Cheap change detector: mtimes of HEAD, refs, packed-refs, index."""
        out = []
        for rel in ("HEAD", "index", "packed-refs", "refs/heads", "ORIG_HEAD", "logs/HEAD"):
            p = self.repo.hit_dir / rel
            try:
                st = p.stat()
                out.append((rel, int(st.st_mtime_ns)))
            except OSError:
                out.append((rel, 0))
        try:
            for b in (self.repo.hit_dir / "refs" / "heads").rglob("*"):
                if b.is_file():
                    out.append((b.name, int(b.stat().st_mtime_ns)))
        except OSError:
            pass
        return tuple(out)

    def _poll_repo_changes(self) -> None:
        if self.app.screen is not self:
            return
        fp = self._repo_fingerprint()
        if fp != getattr(self, "_fingerprint", None):
            self._fingerprint = fp
            self.reload(keep_preview=True)
            self.notify("refreshed — repository changed on disk", timeout=2)

    def reload(self, keep_preview: bool = False) -> None:
        self._keep_preview = keep_preview
        self._tree_for = None
        self.repo = Repository(self.root)
        from ..remote import sync_state
        sync = sync_state(self.repo)
        self._remote_anc = set()
        if sync.remote_sha:
            try:
                self._remote_anc = self.repo.ancestors(sync.remote_sha)
            except Exception:
                pass
        if not sync.connected:
            gh = "[dim]GitHub: not connected (press p)[/]"
        elif sync.pushed:
            gh = f"[green]GitHub: ✓ pushed[/]  [dim]{sync.web or sync.url}[/]"
        else:
            gh = f"[yellow]GitHub: ✗ {sync.label}[/]  [dim]{sync.web or sync.url}[/]  [dim](press p)[/]"
        self._sync = sync
        link = sync.web or sync.url
        if not sync.connected:
            self.query_one("#commits-title", Static).update("Commits   [dim]· not on GitHub yet — press p to push[/]")
        elif sync.pushed:
            self.query_one("#commits-title", Static).update(f"Commits   [green]✓ pushed[/] → [u]{link}[/u]  [dim](o = open)[/]")
        else:
            self.query_one("#commits-title", Static).update(f"Commits   [yellow]✗ {sync.label}[/] → [u]{link}[/u]  [dim](p = push, o = open)[/]")
        self._gh_label = gh
        branch = self.repo.refs.current_branch() or "detached"
        self.query_one("#repo-title", Static).update(
            f"[b]{self.root.name}[/b]   on {branch}   [dim]checking for changes...[/]   {gh}")
        self.compute_status()
        # branches
        bt = self.query_one("#branches", DataTable)
        bt.clear()
        cur = self.repo.refs.current_branch()
        for name, sha in sorted(self.repo.refs.branches().items()):
            c = self.repo.store.read_commit(sha)
            bt.add_row(Text("*", style="green") if name == cur else "", Text(name, style="bold" if name == cur else ""),
                       Text(rel_time(c.commit_time), style="dim"), key=name)
        # commits
        ct = self.query_one("#commits", DataTable)
        ct.clear()
        self.commits = self.repo.log(limit=500, all_branches=True)
        head = self.repo.refs.head()
        on_current = self.repo.ancestors(head) if head else set()
        tags = {}
        for name, sha in self.repo.refs.tags().items():
            try:
                tags.setdefault(self.repo.store.read_commit(sha).sha, []).append(name)
            except Exception:
                pass
        tips: dict[str, list[str]] = {}
        for name, sha in self.repo.refs.branches().items():
            tips.setdefault(sha, []).append(name)
        for c in self.commits:
            label = c.summary
            if c.sha in tags:
                label = f"[{', '.join(tags[c.sha])}] " + label
            if c.sha in tips:
                label = f"({', '.join(tips[c.sha])}) " + label
            style = "bold" if c.sha == head else ("" if c.sha in on_current else "dim")
            pushed = Text("✓", style="green") if c.sha in self._remote_anc else Text("✗", style="yellow")
            ct.add_row(Text(c.short, style="yellow"), Text(label[:60], style=style),
                       Text(rel_time(c.commit_time), style="dim"), "", pushed, key=c.sha)
        if self.commits:
            self.show_commit(self.commits[0].sha, quiet=keep_preview)
        else:
            self.query_one("#files", Tree).clear()
            self.log_line("[dim]No commits yet. Press c to make the first one, or type: save my work as first commit[/]")
        self.set_status()

    @work(thread=True, exclusive=True, group="status")
    def compute_status(self) -> None:
        """Working-tree status can take seconds on big repos; do it off the UI thread."""
        try:
            st = Repository(self.root).status()
        except Exception as e:  # noqa: BLE001
            self.app.call_from_thread(self._show_status_error, str(e))
            return
        self.app.call_from_thread(self._show_status, st)

    def _show_status(self, st) -> None:
        changes = len(st.staged) + len(st.unstaged) + len(st.untracked)
        self.query_one("#repo-title", Static).update(
            f"[b]{self.root.name}[/b]   on {st.branch or 'detached'}   "
            + (f"[yellow]{changes} uncommitted change(s)[/]" if changes else "[green]clean[/]")
            + (f"   [red]{len(st.conflicts)} conflict(s)[/]" if st.conflicts else "")
            + f"   {getattr(self, '_gh_label', '')}")

    def _show_status_error(self, msg: str) -> None:
        self.query_one("#repo-title", Static).update(
            f"[b]{self.root.name}[/b]   [red]could not read changes: {msg}[/]")

    def set_status(self, msg: str | None = None) -> None:
        if msg:
            self.notify(msg, timeout=3)

    def log_line(self, text: str) -> None:
        self.query_one("#preview", RichLog).write(text)

    def show_output(self, out: str, code: int = 0) -> None:
        log = self.query_one("#preview", RichLog)
        log.clear()
        for line in out.rstrip().splitlines() or ["(no output)"]:
            if line.startswith("error") or (line.startswith("-") and not line.startswith("---")):
                style = "red"
            elif line.startswith("✓") or (line.startswith("+") and not line.startswith("+++")):
                style = "green"
            elif line.startswith("@@") or line.startswith("──"):
                style = "cyan"
            elif line.lstrip().startswith(("U ", "A ")):
                style = "green"
            elif line.lstrip().startswith("M "):
                style = "yellow"
            elif line.lstrip().startswith("D "):
                style = "red"
            else:
                style = ""
            log.write(Text(line, style=style))

    # Commits with more files than this get a lazy tree: folders start
    # collapsed and their contents are added when you open them.
    EAGER_TREE_LIMIT = 400

    def show_commit(self, sha: str, quiet: bool = False) -> None:
        from ..diff import tree_changes
        if sha == getattr(self, "current_commit", None) and getattr(self, "_tree_for", None) == sha:
            return  # already showing this commit (reload + row-highlight both ask)
        self.current_commit = sha
        c = self.repo.store.read_commit(sha)
        files = self.repo.commit_files(sha)
        parent = self.repo.commit_files(c.parents[0]) if c.parents else {}
        changes = {ch.path: ch.status for ch in tree_changes(parent, files)}
        tree = self.query_one("#files", Tree)
        tree.clear()
        tree.root.set_label(f"{c.short}  {c.summary[:40]}")
        tree.root.data = {"kind": "root", "path": ""}

        all_paths = sorted(set(files) | {p for p, s in changes.items() if s == "D"})
        self._tree_state = {"files": files, "changes": changes, "paths": all_paths, "sizes": None}
        self._tree_for = sha
        lazy = len(all_paths) > self.EAGER_TREE_LIMIT
        if not lazy:
            self._tree_state["sizes"] = self.repo.blob_sizes(b for _, b in files.values())
            self._fill_dir(tree.root, "", recursive=True)
        else:
            self._fill_dir(tree.root, "", recursive=False)
        tree.root.expand()
        self.query_one("#files-title", Static).update(
            f"Files in {c.short}  ({len(files)} files, {sum(1 for s in changes.values() if s != '·')} changed)")
        # update file-count column
        ct = self.query_one("#commits", DataTable)
        try:
            ct.update_cell(sha, ct.ordered_columns[3].key, str(len(files)))
        except Exception:
            pass
        if quiet:
            return
        log = self.query_one("#preview", RichLog)
        log.clear()
        log.write(Text(f"commit {c.sha}", style="yellow"))
        log.write(f"Author: {c.author} <{c.author_email}>   {rel_time(c.commit_time)}")
        log.write("")
        log.write("    " + c.message.strip())
        log.write("")
        log.write(Text("Select a file to see its diff.", style="dim"))

    def _fill_dir(self, node, prefix: str, recursive: bool) -> None:
        """Add the direct children of folder `prefix` under `node`.
        Folders with many files show a count and load when expanded."""
        state = self._tree_state
        files, changes, paths = state["files"], state["changes"], state["paths"]
        base = prefix + "/" if prefix else ""
        subdirs: dict[str, list[str]] = {}
        direct: list[str] = []
        for p in paths:
            if not p.startswith(base):
                continue
            rest = p[len(base):]
            if "/" in rest:
                subdirs.setdefault(rest.split("/", 1)[0], []).append(p)
            else:
                direct.append(p)

        for name in sorted(subdirs):
            key = base + name
            inside = subdirs[name]
            n_changed = sum(1 for p in inside if changes.get(p, "·") != "·")
            label = Text.assemble((name + "/", "cyan"),
                                  (f"  {len(inside)} files" + (f", {n_changed} changed" if n_changed else ""), "dim"))
            child = node.add(label, data={"kind": "dir", "path": key, "loaded": recursive},
                             expand=recursive or len(inside) <= 30)
            if recursive or len(inside) <= 30:
                self._fill_dir(child, key, recursive=True)
                child.data["loaded"] = True

        if direct:
            if state["sizes"] is None:
                state["sizes"] = {}
            need = [files[p][1] for p in direct if p in files and files[p][1] not in state["sizes"]]
            if need:
                state["sizes"].update(self.repo.blob_sizes(need))
            sizes = state["sizes"]
            for path in direct:
                status = changes.get(path, "·")
                size = "(deleted)" if status == "D" else hsize(sizes.get(files[path][1], 0))
                style = {"A": "green", "M": "yellow", "D": "red strike"}.get(status, "")
                label = Text.assemble((f"{status} ", style or "dim"), (path.rsplit("/", 1)[-1], style),
                                      (f"  {size}", "dim"))
                node.add_leaf(label, data={"kind": "file", "path": path, "status": status})

    def on_tree_node_expanded(self, event: Tree.NodeExpanded) -> None:
        data = event.node.data or {}
        if data.get("kind") == "dir" and not data.get("loaded"):
            data["loaded"] = True
            self._fill_dir(event.node, data["path"], recursive=False)

    # ---- events ---------------------------------------------------------

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        if event.data_table.id == "commits" and event.row_key is not None:
            quiet = getattr(self, "_keep_preview", False)
            self._keep_preview = False
            self.show_commit(event.row_key.value, quiet=quiet)

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        if event.data_table.id == "branches" and event.row_key is not None:
            self.switch_branch(event.row_key.value)
        elif event.data_table.id == "commits":
            self.query_one("#files", Tree).focus()

    def on_tree_node_highlighted(self, event: Tree.NodeHighlighted) -> None:
        data = event.node.data or {}
        if data.get("kind") == "file":
            self.show_file_diff(data["path"], data["status"])

    def on_tree_node_selected(self, event: Tree.NodeSelected) -> None:
        data = event.node.data or {}
        if data.get("kind") == "file":
            self.show_file_content(data["path"])

    def show_file_diff(self, path: str, status: str) -> None:
        from ..diff import unified
        c = self.repo.store.read_commit(self.current_commit)
        files = self.repo.commit_files(self.current_commit)
        parent = self.repo.commit_files(c.parents[0]) if c.parents else {}
        a = self.repo.store.read_blob(parent[path][1]) if path in parent else b""
        b = self.repo.store.read_blob(files[path][1]) if path in files else b""
        log = self.query_one("#preview", RichLog)
        log.clear()
        if status == "·":
            log.write(Text(f"{path} — unchanged in this commit ({hsize(len(b))}). Enter to view.", style="dim"))
            return
        text = unified(a, b, f"a/{path}", f"b/{path}")
        for line in text.splitlines()[:400]:
            style = "green" if line.startswith("+") and not line.startswith("+++") else \
                    "red" if line.startswith("-") and not line.startswith("---") else \
                    "cyan" if line.startswith("@@") else ""
            log.write(Text(line, style=style))

    def show_file_content(self, path: str) -> None:
        files = self.repo.commit_files(self.current_commit)
        if path not in files:
            return
        data = self.repo.store.read_blob(files[path][1])
        log = self.query_one("#preview", RichLog)
        log.clear()
        if b"\0" in data[:8000]:
            log.write(Text(f"{path}: binary file, {hsize(len(data))}", style="dim"))
            return
        for i, line in enumerate(data.decode("utf-8", "replace").splitlines()[:500], 1):
            log.write(Text(f"{i:4} ", style="dim") + Text(line))

    # ---- actions --------------------------------------------------------

    def action_back(self) -> None:
        if len(self.app.screen_stack) > 2:
            self.app.pop_screen()
        else:
            self.app.exit()

    def action_refresh(self) -> None:
        self.reload()
        self._fingerprint = self._repo_fingerprint()
        self.notify("refreshed")

    def action_cmd(self) -> None:
        self.query_one("#cmd", Input).focus()

    def action_help(self) -> None:
        self.app.push_screen(TextView("Help — Repository", HELP_REPO))

    @work
    async def action_pull(self) -> None:
        from ..remote import get_remote
        if not get_remote(self.repo):
            self.notify("not connected to GitHub yet — press p to connect and push first", severity="warning")
            return
        st = self.repo.status()
        if st.staged or st.unstaged:
            ok = await self.app.push_screen_wait(Confirm(
                "You have uncommitted changes.", "Pull merges GitHub's commits into yours; commit first to be safe. Pull anyway?"))
            if not ok:
                return
        self.notify("pulling latest from GitHub …", timeout=10)
        self.run(["pull"])

    def action_open_github(self) -> None:
        sync = getattr(self, "_sync", None)
        if not sync or not sync.connected:
            self.notify("not connected to GitHub yet — press p to push", severity="warning")
            return
        link = sync.web or sync.url
        if not link.startswith("http"):
            self.notify(f"remote is a local path: {link}")
            return
        import webbrowser
        webbrowser.open(link)
        self.notify(f"opening {link}")

    def action_open(self) -> None:
        focused = self.focused
        if isinstance(focused, DataTable) and focused.id == "commits":
            self.query_one("#files", Tree).focus()

    def run(self, argv: list[str], reload: bool = True) -> None:
        code, out = run_command(argv, self.root)
        self.show_output(out, code)
        first = out.strip().splitlines()[0] if out.strip() else ("done" if code == 0 else "failed")
        self.notify(first[:120], severity="error" if code else "information", timeout=4)
        if reload:
            self.reload(keep_preview=True)

    @work
    async def action_commit(self) -> None:
        st = self.repo.status()
        if st.clean:
            self.notify("nothing to commit — working tree is clean")
            return
        msg = await self.app.push_screen_wait(Prompt(
            f"Commit message  ({len(st.staged) + len(st.unstaged) + len(st.untracked)} changed file(s) will be staged)",
            placeholder="what did you change?"))
        if not msg:
            return
        self.run(["add", "."], reload=False)
        self.run(["commit", "-m", msg])

    @work
    async def action_branch(self) -> None:
        name = await self.app.push_screen_wait(Prompt("New branch name", placeholder="e.g. dark-mode"))
        if name:
            self.run(["switch", "-c", name])

    @work
    async def switch_branch(self, name: str) -> None:
        if name == self.repo.refs.current_branch():
            return
        st = self.repo.status()
        if st.staged or st.unstaged:
            ok = await self.app.push_screen_wait(Confirm(
                f"Switch to '{name}'?", "You have uncommitted changes. HIT will refuse if they'd be overwritten."))
            if not ok:
                return
        self.run(["switch", name])

    @work
    async def action_snapshot(self) -> None:
        name = await self.app.push_screen_wait(Prompt("Snapshot name", placeholder="e.g. before-refactor"))
        if name is not None:
            self.run(["snapshot", name] if name else ["snapshot"])

    @work
    async def action_undo(self) -> None:
        from ..journal import Journal
        last = Journal(self.repo).last()
        if not last:
            self.notify("nothing to undo")
            return
        ok = await self.app.push_screen_wait(Confirm("Undo the last action?", f"→ {last.description}", yes_label="Undo"))
        if ok:
            self.run(["undo"])

    @work
    async def action_push(self) -> None:
        from ..remote import get_remote
        url = get_remote(self.repo)
        if not url:
            url = await self.app.push_screen_wait(Prompt(
                "This project isn't connected to GitHub yet. Paste the repo URL (or user/repo):",
                placeholder="https://github.com/you/repo.git"))
            if not url:
                return
            self.run(["remote", "add", "origin", url], reload=False)
        from ..remote import get_credential, host_of
        url = get_remote(self.repo) or url
        if url.startswith("http") and not get_credential(host_of(url)):
            user = await self.app.push_screen_wait(Prompt(f"GitHub username for {host_of(url)}"))
            if not user:
                return
            token = await self.app.push_screen_wait(Prompt("Personal access token (scope: repo)", password=True))
            if not token:
                return
            self.run(["login", "--host", host_of(url), "-u", user, "-t", token], reload=False)
        self.set_status("pushing…")
        self.run(["push"])

    @work
    async def action_delete(self) -> None:
        focused = self.focused
        if isinstance(focused, Tree):
            node = focused.cursor_node
            data = (node.data or {}) if node else {}
            if data.get("kind") in ("file", "dir"):
                await self._delete_path(data["path"], data["kind"] == "dir")
        elif isinstance(focused, DataTable) and focused.id == "commits":
            await self._delete_commit()
        elif isinstance(focused, DataTable) and focused.id == "branches":
            await self._delete_branch()

    async def _delete_path(self, path: str, is_dir: bool) -> None:
        what = "folder" if is_dir else "file"
        choice = await self.app.push_screen_wait(Choice(
            f"Delete {what} '{path}' — how?",
            ["Stop tracking from the next commit (history keeps it; file stays on disk)",
             "Stop tracking AND delete from disk",
             "PURGE: erase from ALL history (for secrets / huge files)"]))
        if choice is None:
            return
        if choice == 0:
            self.run(["rm", "--keep", path])
        elif choice == 1:
            ok = await self.app.push_screen_wait(Confirm(f"Delete '{path}' from disk too?", yes_label="Delete", danger=True))
            if ok:
                self.run(["rm", path])
        else:
            await self._purge(path)

    async def _purge(self, path: str) -> None:
        ok = await self.app.push_screen_wait(Confirm(
            f"Purge '{path}' from ALL history?",
            "Every commit is rewritten to never contain it. A backup is taken first and `u` (undo) reverses it.\n"
            "If you've pushed to GitHub, you'll need `hit push --force` afterwards.",
            yes_label="Purge", danger=True))
        if ok:
            self.run(["purge", path])

    @work
    async def action_purge(self) -> None:
        focused = self.focused
        if isinstance(focused, Tree) and focused.cursor_node:
            data = focused.cursor_node.data or {}
            if data.get("kind") in ("file", "dir"):
                await self._purge(data["path"])

    async def _delete_commit(self) -> None:
        if not self.current_commit:
            return
        c = self.repo.store.read_commit(self.current_commit)
        head = self.repo.refs.head()
        options = ["Drop this commit from history (its changes vanish from later commits)"]
        if c.sha == head:
            options.insert(0, "Uncommit: remove it but keep its changes in my files")
        options.append(f"Delete ALL {len(self.commits)} commits at once (files stay on disk)")
        choice = await self.app.push_screen_wait(Choice(f"Delete commit {c.short} \"{c.summary[:40]}\"?", options))
        if choice is None:
            return
        if choice == len(options) - 1:
            await self._wipe()
            return
        if c.sha == head and choice == 0:
            self.run(["reset", "--soft", "HEAD~1"] if c.parents else ["reset", "--soft", "HEAD"])
            return
        ok = await self.app.push_screen_wait(Confirm(
            f"Drop commit {c.short} from history?", "A backup is taken first; `u` undoes it.", yes_label="Drop", danger=True))
        if ok:
            self.run(["drop", c.sha])

    async def _wipe(self) -> None:
        n = len(self.commits)
        ok = await self.app.push_screen_wait(Confirm(
            f"Delete ALL {n} commits?",
            "Every commit and branch is removed. Your files stay exactly as they are.\n"
            "A backup snapshot is taken first and `u` (undo) brings it all back.\n"
            "If it's on GitHub, use `hit push --force` afterwards to replace the history there.",
            yes_label=f"Delete all {n}", danger=True))
        if ok:
            self.run(["wipe"])

    @work
    async def action_wipe(self) -> None:
        if not self.commits:
            self.notify("no commits to delete")
            return
        await self._wipe()

    async def _delete_branch(self) -> None:
        t = self.query_one("#branches", DataTable)
        if t.row_count == 0:
            return
        name = t.coordinate_to_cell_key(t.cursor_coordinate).row_key.value
        if name == self.repo.refs.current_branch():
            self.notify("switch to another branch first", severity="warning")
            return
        ok = await self.app.push_screen_wait(Confirm(f"Delete branch '{name}'?", "`u` undoes it.", yes_label="Delete", danger=True))
        if ok:
            self.run(["branch", "-D", name])

    # ---- command bar ----------------------------------------------------

    @work
    async def on_input_submitted(self, event: Input.Submitted) -> None:
        text = event.value.strip()
        event.input.value = ""
        if not text:
            return
        if text in ("?", "help"):
            return self.action_help()
        if text in ("q", "quit", "exit"):
            return self.app.exit()
        if text in ("back", "projects", ".."):
            return self.action_back()
        words = text.split()
        from ..cli import known_commands
        from ..nl import parse
        if words[0].lower() in known_commands():
            # exact command; but "save my work as x" is also an English sentence
            if len(words) > 1 and words[0].lower() in ("save", "commit") and not words[1].startswith("-"):
                pass
            else:
                self.run(words)
                self.query_one("#commits", DataTable).focus()
                return
        p = parse(text)
        if not p.intent or not p.commands:
            alts = "\n".join(f"  • {a.explain}  (e.g. hit {a.examples[0] if a.examples else a.name})" for a in p.alternatives)
            self.show_output(f"I didn't understand: \"{text}\"\n\nMaybe you meant:\n{alts}\n\nPress ? for help.", 1)
            return
        body = f"{p.intent.explain}\n\n  {p.pretty()}"
        if p.confidence < 1.0:
            body += "\n\n(not 100% sure about this one)"
        ok = await self.app.push_screen_wait(Confirm("Run this?", body, yes_label="Run", danger=p.danger))
        if not ok:
            return
        for cmd in p.commands:
            code, out = run_command(cmd, self.root)
            self.show_output(out, code)
            if code != 0:
                break
        self.reload(keep_preview=True)
        self.query_one("#commits", DataTable).focus()


HELP_PROJECTS = """\
PROJECTS — every HIT repository on this computer

  Enter        open the selected project
  d            delete: remove from list / delete history / delete whole folder
               (a backup snapshot goes to ~/.hit/trash first)
  s            take a snapshot of the selected project's history
  f            find every Git/HIT project on this computer and list them all here
  g            get a project from GitHub (clone) and open it
  a            add an existing HIT — or Git — folder to this list (Git ones get imported)
  r            refresh
  /            jump to the command bar
  q            quit

Command bar: type a project name to open it, or text to filter the list.
"""

HELP_REPO = """\
REPOSITORY — branches · commits · files

Navigation
  Tab / Shift+Tab    move between panes         j/k or arrows   move
  Enter              commits → files pane; files → view file content
  Esc                back to the projects list

Actions
  c   commit everything (asks for a message)     u   undo the last HIT action
  s   snapshot the whole history                 p   push to GitHub (asks for URL/token first time)
  o   open the project on GitHub in your browser  l   pull the latest commits from GitHub
  b   create a new branch and switch to it       r   refresh
  d   delete — depends on what's focused:
        file/folder  → stop tracking, delete from disk, or purge from all history
        commit       → uncommit (keep changes) or drop it from history
        branch       → delete the branch
  D   purge the focused file/folder from ALL history (shortcut)
  X   delete ALL commits at once (files stay; backup + undo)   — also under d on a commit
  Enter on a branch  → switch to it

File markers:  A added   M modified   D deleted   · unchanged in this commit

Command bar (/) — exact commands or plain English, e.g.
  save my work as fixed login          show diff             push to github
  make a new branch called dark-mode   undo my last commit   remove big.zip from all history
  merge dark-mode                      discard my changes    tag this as v1.0
HIT shows the exact command it will run and asks before doing anything.
"""


class HitApp(App):
    TITLE = "HIT - Version Control System"
    SUB_TITLE = "An NLR Product · Made with 💖 For Developers"
    CSS = CSS

    def __init__(self, start: Path | None):
        super().__init__()
        self.start = start

    def on_mount(self) -> None:
        self.push_screen(ProjectsScreen())
        if self.start:
            self.push_screen(RepoScreen(self.start))


def run_ui(path: str | None = None) -> None:
    start: Path | None = None
    if path and path.lower() in ("all", "projects", "list", "home"):
        HitApp(None).run()
        return
    if path:
        start = Path(path).resolve()
        if not (start / HIT_DIR).is_dir():
            raise HitError(f"{start} is not a HIT repository")
    else:
        try:
            start = Repository.find().root
        except HitError:
            start = None
    if start:
        registry.add_path(start)
    HitApp(start).run()
