"""Consistent, professional terminal output for every HIT command.

House style
-----------
  ✔ Committed 4d9f1ac on main          <- one result line: verb, subject, context
    message   fixed the login bug      <- aligned fields, two-space indent
    files     3 changed · 1 added, 2 modified

    A  src/nav.py                      <- detail rows, one per line
    M  src/auth.py

    hint  undo this with `hit undo`    <- optional, always last, always dim

Rules: one result line per command, lower-case field labels, no exclamation
marks, colour only as an accent (never as the only signal), and every hint
prefixed with `hint`.
"""
from __future__ import annotations

import os
import sys

# --------------------------------------------------------------------------
# Terminal setup
# --------------------------------------------------------------------------

if os.name == "nt":
    try:
        os.system("")  # enable ANSI escapes on older Windows consoles
    except Exception:
        pass

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

USE_COLOR = sys.stdout.isatty() and os.environ.get("NO_COLOR") is None


def _supports_unicode() -> bool:
    if os.environ.get("HIT_ASCII"):
        return False
    enc = (getattr(sys.stdout, "encoding", "") or "").lower()
    return "utf" in enc


UNICODE = _supports_unicode()

TICK = "✔" if UNICODE else "+"
CROSS = "✖" if UNICODE else "x"
BULLET = "•" if UNICODE else "*"
ARROW = "→" if UNICODE else "->"
DOT = "·" if UNICODE else "-"

FIELD_WIDTH = 9  # width of the aligned label column


# --------------------------------------------------------------------------
# Colour
# --------------------------------------------------------------------------

def c(code: str, text: str) -> str:
    return f"\033[{code}m{text}\033[0m" if USE_COLOR else text


def green(t: str) -> str: return c("32", t)
def red(t: str) -> str: return c("31", t)
def yellow(t: str) -> str: return c("33", t)
def cyan(t: str) -> str: return c("36", t)
def blue(t: str) -> str: return c("34", t)
def dim(t: str) -> str: return c("2", t)
def bold(t: str) -> str: return c("1", t)


# --------------------------------------------------------------------------
# Primitives
# --------------------------------------------------------------------------

def say(*parts: str) -> None:
    print(*parts)


def blank() -> None:
    print()


def ok(msg: str) -> None:
    """The single success line of a command."""
    print(f"{green(TICK)} {msg}")


def fail(msg: str) -> None:
    print(f"{red(CROSS)} {msg}")


def warn(msg: str) -> None:
    print(f"{yellow('!')} {msg}")


def info(msg: str) -> None:
    print(f"{dim(DOT)} {msg}")


def field(label: str, value: str) -> None:
    """An aligned `label  value` line under a result line."""
    print(f"  {dim(label.ljust(FIELD_WIDTH))} {value}")


def detail(line: str) -> None:
    """An indented detail row (file lists, commits, ...)."""
    print(f"    {line}")


def hint(msg: str) -> None:
    print(dim(f"  hint  {msg}"))


def note(msg: str) -> None:
    """A quiet aside, indented like a field but without a label."""
    print(dim(f"  {msg}"))


def section(title: str) -> None:
    """A heading between blocks of output."""
    print()
    print(bold(title))


def status_glyph(status: str) -> str:
    """Colour the A/M/D/R/· marker used across files, diff and commit output."""
    return {
        "A": green("A"), "M": yellow("M"), "D": red("D"),
        "R": cyan("R"), "U": green("U"), "C": red("C"),
    }.get(status, dim(status))


def plural(n: int, one: str, many: str | None = None) -> str:
    return one if n == 1 else (many or one + "s")


def file_list(rows: list[tuple[str, str]], limit: int = 15) -> None:
    """rows = [(status, path)] printed as aligned detail lines."""
    for status, path in rows[:limit]:
        detail(f"{status_glyph(status)}  {path}")
    if len(rows) > limit:
        note(f"... and {len(rows) - limit} more")


def summary_counts(counts: dict[str, int]) -> str:
    """'1 added, 2 modified, 1 deleted' from {'A':1,'M':2,'D':1}."""
    labels = [("A", "added"), ("M", "modified"), ("D", "deleted"), ("R", "renamed")]
    parts = []
    for key, word in labels:
        n = counts.get(key, 0)
        if n:
            colour = {"A": green, "M": yellow, "D": red, "R": cyan}[key]
            parts.append(colour(f"{n} {word}"))
    return ", ".join(parts)


def human_size(n: float) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


def relative_time(ts: int) -> str:
    import time
    d = int(time.time()) - int(ts or 0)
    if not ts:
        return "-"
    if d < 60:
        return "just now"
    if d < 3600:
        return f"{d // 60}m ago"
    if d < 86400:
        return f"{d // 3600}h ago"
    if d < 86400 * 30:
        return f"{d // 86400}d ago"
    if d < 86400 * 365:
        return f"{d // (86400 * 30)}mo ago"
    return f"{d // (86400 * 365)}y ago"


def short_path(path: str, keep: int = 3, width: int = 46) -> str:
    """Shorten a long path for display: home becomes ~, middle becomes ...""" 
    import os
    from pathlib import Path
    try:
        p = Path(path)
        home = Path.home()
        if str(p).lower().startswith(str(home).lower()):
            p = Path("~") / p.relative_to(home)
    except Exception:
        p = Path(path)
    text = str(p)
    if len(text) <= width:
        return text
    parts = p.parts
    tail = os.sep.join(parts[-keep:])
    return f"...{os.sep}{tail}" if len(tail) < len(text) else text


def table(headers: list[str], rows: list[list[str]], indent: str = "  ") -> None:
    """Aligned plain-text table (no borders), used by list-style commands."""
    if not rows:
        return
    def visible(s: str) -> int:
        import re
        return len(re.sub(r"\033\[[0-9;]*m", "", s))
    cols = max(len(headers), max(len(r) for r in rows))
    headers = list(headers) + [""] * (cols - len(headers))
    rows = [list(r) + [""] * (cols - len(r)) for r in rows]
    widths = [max([visible(headers[i])] + [visible(r[i]) for r in rows]) for i in range(cols)]
    if headers and any(headers):
        line = indent + "  ".join(dim(h.ljust(widths[i] + len(h) - visible(h))) for i, h in enumerate(headers))
        print(line.rstrip())
    for r in rows:
        cells = []
        for i, cell in enumerate(r):
            pad = widths[i] - visible(cell)
            cells.append(cell + " " * max(0, pad))
        print((indent + "  ".join(cells)).rstrip())
