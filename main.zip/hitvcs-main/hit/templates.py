"""Built-in .hitignore templates for `hit init --template <name>`."""
from __future__ import annotations

from pathlib import Path

TEMPLATES: dict[str, str] = {
    "python": """# Python
__pycache__/
*.py[cod]
*.egg-info/
.venv/
venv/
env/
build/
dist/
.pytest_cache/
.mypy_cache/
.coverage
*.log
.env
""",
    "node": """# Node
node_modules/
dist/
build/
.next/
.nuxt/
coverage/
*.log
.env
.env.*
.DS_Store
""",
    "java": """# Java
*.class
target/
build/
out/
.gradle/
*.jar
*.war
.idea/
*.iml
""",
    "web": """# Web
node_modules/
dist/
build/
.cache/
*.log
.env
.DS_Store
Thumbs.db
""",
    "flutter": """# Flutter / Dart
.dart_tool/
.packages
build/
.flutter-plugins
.flutter-plugins-dependencies
*.iml
.idea/
ios/Pods/
""",
    "go": """# Go
bin/
*.exe
*.test
*.out
vendor/
""",
    "rust": """# Rust
target/
Cargo.lock
""",
    "unity": """# Unity
[Ll]ibrary/
[Tt]emp/
[Oo]bj/
[Bb]uild/
[Ll]ogs/
UserSettings/
*.csproj
*.sln
""",
    "general": """# General
.DS_Store
Thumbs.db
*.log
*.tmp
.env
.idea/
.vscode/
""",
}


# Files/folders whose presence tells us what kind of project this is
DETECT: list[tuple[str, tuple[str, ...]]] = [
    ("node",    ("package.json", "node_modules", "yarn.lock", "pnpm-lock.yaml")),
    ("python",  ("requirements.txt", "pyproject.toml", "setup.py", "Pipfile", "manage.py", "*.py")),
    ("java",    ("pom.xml", "build.gradle", "build.gradle.kts", "*.java")),
    ("flutter", ("pubspec.yaml",)),
    ("go",      ("go.mod",)),
    ("rust",    ("Cargo.toml",)),
    ("unity",   ("Assets", "ProjectSettings")),
    ("web",     ("index.html",)),
]


def detect_templates(root: Path) -> list[str]:
    """Guess which ignore templates fit this folder (may be several, e.g. node + python)."""
    found: list[str] = []
    try:
        names = {p.name for p in root.iterdir()}
    except OSError:
        return found
    for name, markers in DETECT:
        for m in markers:
            hit = any(root.glob(m)) if "*" in m else m in names
            if hit:
                found.append(name)
                break
    return found


def write_default_ignore(root: Path) -> tuple[Path, list[str]]:
    """Create .hitignore on `hit init`: general rules + whatever the project type needs.
    If a .gitignore already exists, its rules are reused too."""
    kinds = detect_templates(root)
    nl = chr(10)
    parts = ["# .hitignore — files HIT should never track (same syntax as .gitignore)" + nl]
    gi = root / ".gitignore"
    if gi.exists():
        parts.append("# --- copied from your existing .gitignore ---" + nl
                     + gi.read_text(errors="replace").rstrip() + nl + nl)
    parts.append(TEMPLATES["general"])
    for k in kinds:
        parts.append(nl + TEMPLATES[k])
    p = root / ".hitignore"
    if p.exists():
        return p, kinds
    p.write_text("".join(parts))
    return p, kinds


LICENSES = {
    "mit": """MIT License

Copyright (c) {year} {author}

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
""",
    "apache-2.0": """Copyright {year} {author}

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
""",
    "gpl-3.0": """{name}
Copyright (C) {year} {author}

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
""",
}


def write_readme(root: Path, name: str, kinds: list[str]) -> Path | None:
    """Create a starter README.md if the project has none."""
    for existing in ("README.md", "README", "readme.md", "README.txt"):
        if (root / existing).exists():
            return None
    nl = chr(10)
    stack = ", ".join(k.capitalize() for k in kinds) if kinds else "—"
    text = nl.join([
        f"# {name}",
        "",
        "> One line about what this project does.",
        "",
        "## Getting started",
        "",
        "```",
        "# how to install / run it",
        "```",
        "",
        "## Tech",
        "",
        f"- {stack}",
        "",
        "## Version control",
        "",
        "This project is tracked with [HIT](https://github.com/NLR-2007/hitvcs) — `hit status`, `hit save my work as ...`, `hit push`.",
        "",
    ])
    p = root / "README.md"
    p.write_text(text, encoding="utf-8")
    return p


def write_license(root: Path, kind: str, author: str, name: str) -> Path:
    import time
    key = kind.lower()
    if key not in LICENSES:
        from .repo import HitError
        raise HitError(f"unknown license '{kind}'", "available: " + ", ".join(LICENSES))
    p = root / "LICENSE"
    p.write_text(LICENSES[key].format(year=time.strftime("%Y"), author=author, name=name), encoding="utf-8")
    return p


def write_ignore_template(root: Path, name: str) -> Path:
    key = name.lower()
    if key not in TEMPLATES:
        from .repo import HitError
        raise HitError(f"unknown template '{name}'", "available: " + ", ".join(sorted(TEMPLATES)))
    p = root / ".hitignore"
    existing = p.read_text() if p.exists() else ""
    p.write_text(existing + ("\n" if existing and not existing.endswith("\n") else "") + TEMPLATES[key])
    return p
