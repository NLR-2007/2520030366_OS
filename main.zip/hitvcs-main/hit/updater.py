"""Updates: a daily "new version available" reminder and `hit update`.

The newest version is described by a small JSON file on the HIT website:

    https://hitvcs.vercel.app/latest.json
    {
      "version": "0.4.1",
      "url": "https://github.com/NLR-2007/hit-releases/releases/download/v0.4.1/hit.exe",
      "sha256": "…",
      "size": 33600000,
      "published": "2026-09-22",
      "notes": ["Faster push", "Fixed …"]
    }

Rules:
  * The reminder checks at most once a day, in a background thread, so a
    command is never slowed down; offline or failed checks are silent.
  * The reminder prints at most once a day, only in an interactive terminal,
    and never for script-style commands (rev-parse, status -s, …).
  * Turn it off with `hit config update.check false` or HIT_NO_UPDATE_CHECK=1.
  * `hit update` downloads the new hit.exe, verifies its SHA-256 checksum and
    swaps it in place. The running exe is renamed to hit.old.exe (Windows
    allows renaming a running program) and removed on the next start.
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
import threading
import time
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path

from . import __version__

LATEST_URL = "https://hitvcs.vercel.app/latest.json"
CHECK_EVERY = 24 * 3600          # seconds between background checks
NOTICE_EVERY = 24 * 3600         # seconds between reminders
QUIET_COMMANDS = {               # output is read by scripts; never add a reminder
    "rev-parse", "ls-files", "ls-tree", "describe", "count-objects", "config",
    "update", "version", "help", "setup", "ui", "dashboard",
}


@dataclass
class Release:
    version: str
    url: str
    sha256: str = ""
    size: int = 0
    published: str = ""
    notes: list[str] = field(default_factory=list)


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------

def parse_version(v: str) -> tuple[int, ...]:
    """'0.4.1' -> (0, 4, 1). Anything non-numeric sorts as 0."""
    parts = []
    for piece in str(v).strip().lstrip("v").split("."):
        digits = "".join(ch for ch in piece if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)


def is_newer(candidate: str, current: str = __version__) -> bool:
    return parse_version(candidate) > parse_version(current)


def latest_url() -> str:
    return os.environ.get("HIT_UPDATE_URL") or LATEST_URL


def _state_file() -> Path:
    from .repo import global_hit_dir
    return global_hit_dir() / "update.json"


def _load_state() -> dict:
    try:
        return json.loads(_state_file().read_text())
    except (OSError, ValueError):
        return {}


def _save_state(state: dict) -> None:
    try:
        _state_file().write_text(json.dumps(state, indent=1))
    except OSError:
        pass


def checks_enabled() -> bool:
    if os.environ.get("HIT_NO_UPDATE_CHECK"):
        return False
    try:
        from .repo import Config, global_config_path
        val = Config([global_config_path()]).get("update", "check")
    except Exception:
        return True
    return (val or "true").strip().lower() not in ("false", "0", "no", "off")


def _http_get(url: str, timeout: float) -> bytes:
    req = urllib.request.Request(url, headers={
        "User-Agent": f"hit/{__version__}",
        "Cache-Control": "no-cache",
    })
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


# --------------------------------------------------------------------------
# checking
# --------------------------------------------------------------------------

def fetch_latest(timeout: float = 8.0) -> Release:
    """Ask the website which version is newest. Raises on any failure."""
    data = json.loads(_http_get(latest_url() + f"?t={int(time.time())}", timeout).decode("utf-8"))
    rel = Release(
        version=str(data["version"]),
        url=str(data["url"]),
        sha256=str(data.get("sha256", "")).lower(),
        size=int(data.get("size") or 0),
        published=str(data.get("published", "")),
        notes=[str(n) for n in (data.get("notes") or [])],
    )
    state = _load_state()
    state.update({"last_check": int(time.time()), "latest": rel.version,
                  "notes": rel.notes[:5]})
    _save_state(state)
    return rel


_bg: threading.Thread | None = None


def start_background_check() -> None:
    """Refresh the cached 'latest version' at most once a day, without blocking."""
    global _bg
    if not checks_enabled():
        return
    if time.time() - _load_state().get("last_check", 0) < CHECK_EVERY:
        return

    def run():
        try:
            fetch_latest(timeout=4.0)
        except Exception:
            state = _load_state()               # offline: try again tomorrow, quietly
            state["last_check"] = int(time.time())
            _save_state(state)

    _bg = threading.Thread(target=run, name="hit-update-check", daemon=True)
    _bg.start()


def maybe_print_notice(command: str | None) -> None:
    """One quiet line after a command, at most once a day, if a newer version exists."""
    if _bg is not None:
        _bg.join(timeout=0.3)                   # finish if it's almost done; never wait long
    if not checks_enabled() or not sys.stdout.isatty():
        return
    if command in QUIET_COMMANDS:
        return
    state = _load_state()
    latest = state.get("latest")
    if not latest or not is_newer(latest):
        return
    if time.time() - state.get("last_notice", 0) < NOTICE_EVERY:
        return
    from .output import dim, yellow
    print()
    print(yellow(f"  HIT {latest} is available") + dim(f"  (you have {__version__})  -  run `hit update`"))
    state["last_notice"] = int(time.time())
    _save_state(state)


# --------------------------------------------------------------------------
# installing
# --------------------------------------------------------------------------

def running_exe() -> Path | None:
    """Path of hit.exe when running as the standalone program, else None."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve()
    return None


def cleanup_after_update() -> None:
    """Remove the hit.old.exe left behind by a previous `hit update`."""
    exe = running_exe()
    if exe is None:
        return
    old = exe.with_name(exe.stem + ".old" + exe.suffix)
    if old.exists():
        try:
            old.unlink()
        except OSError:
            pass                                # still locked; try next time


def download(rel: Release, progress=None, timeout: float = 60.0) -> bytes:
    req = urllib.request.Request(rel.url, headers={"User-Agent": f"hit/{__version__}"})
    chunks, got = [], 0
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        total = int(resp.headers.get("Content-Length") or rel.size or 0)
        while True:
            chunk = resp.read(256 * 1024)
            if not chunk:
                break
            chunks.append(chunk)
            got += len(chunk)
            if progress:
                progress(got, total)
    data = b"".join(chunks)
    if rel.sha256:
        actual = hashlib.sha256(data).hexdigest()
        if actual != rel.sha256:
            raise ValueError("checksum mismatch - the download was corrupted; nothing was changed")
    if len(data) < 1_000_000:
        raise ValueError("the downloaded file is too small; nothing was changed")
    return data


def replace_exe(target: Path, new_bytes: bytes) -> Path:
    """Swap `target` for new_bytes, even while `target` is the running program.
    Returns the path of the backup (target.old.exe). Rolls back on failure."""
    target = Path(target)
    new = target.with_name(target.stem + ".new" + target.suffix)
    old = target.with_name(target.stem + ".old" + target.suffix)
    new.write_bytes(new_bytes)
    if old.exists():
        try:
            old.unlink()
        except OSError:
            old = target.with_name(f"{target.stem}.old-{int(time.time())}{target.suffix}")
    os.replace(target, old)                     # renaming a running exe is allowed on Windows
    try:
        os.replace(new, target)
    except OSError:
        os.replace(old, target)                 # put the original back
        raise
    return old
