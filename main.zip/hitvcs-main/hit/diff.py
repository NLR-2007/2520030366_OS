"""Diffs between trees, index and working directory."""
from __future__ import annotations

import difflib
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .repo import Repository


def is_binary(data: bytes) -> bool:
    return b"\0" in data[:8000]


def unified(a: bytes, b: bytes, a_name: str, b_name: str) -> str:
    if is_binary(a) or is_binary(b):
        if a == b:
            return ""
        return f"Binary files {a_name} and {b_name} differ\n"
    a_lines = a.decode("utf-8", "replace").splitlines(keepends=True)
    b_lines = b.decode("utf-8", "replace").splitlines(keepends=True)
    out = difflib.unified_diff(a_lines, b_lines, fromfile=a_name, tofile=b_name, n=3)
    text = "".join(out)
    if text and not text.endswith("\n"):
        text += "\n\\ No newline at end of file\n"
    return text


@dataclass
class FileChange:
    path: str
    status: str          # A added, M modified, D deleted
    old_sha: str | None
    new_sha: str | None
    old_mode: int | None = None
    new_mode: int | None = None


def tree_changes(old: dict[str, tuple[int, str]], new: dict[str, tuple[int, str]]) -> list[FileChange]:
    changes: list[FileChange] = []
    for path in sorted(set(old) | set(new)):
        o = old.get(path)
        n = new.get(path)
        if o and not n:
            changes.append(FileChange(path, "D", o[1], None, o[0], None))
        elif n and not o:
            changes.append(FileChange(path, "A", None, n[1], None, n[0]))
        elif o != n:
            changes.append(FileChange(path, "M", o[1], n[1], o[0], n[0]))
    return changes


def diff_trees(repo: "Repository", old: dict, new: dict, paths: list[str] | None = None) -> str:
    out = []
    for ch in tree_changes(old, new):
        if paths and not any(ch.path == p or ch.path.startswith(p.rstrip("/") + "/") for p in paths):
            continue
        a = repo.store.read_blob(ch.old_sha) if ch.old_sha else b""
        b = repo.store.read_blob(ch.new_sha) if ch.new_sha else b""
        out.append(_header(ch) + unified(a, b, f"a/{ch.path}" if ch.old_sha else "/dev/null",
                                          f"b/{ch.path}" if ch.new_sha else "/dev/null"))
    return "".join(out)


def _header(ch: FileChange) -> str:
    h = f"diff --hit a/{ch.path} b/{ch.path}\n"
    if ch.status == "A":
        h += f"new file mode {ch.new_mode:o}\n"
    elif ch.status == "D":
        h += f"deleted file mode {ch.old_mode:o}\n"
    return h


def diff_worktree(repo: "Repository", paths: list[str] | None = None, staged: bool = False) -> str:
    """staged=False: working tree vs index.  staged=True: index vs HEAD."""
    if staged:
        return diff_trees(repo, repo.head_files(), repo.index.as_tree_files(), paths)
    idx = repo.index.as_tree_files()
    out = []
    for path in sorted(idx):
        if paths and not any(path == p or path.startswith(p.rstrip("/") + "/") for p in paths):
            continue
        mode, sha = idx[path]
        p = repo.root / path
        a = repo.store.read_blob(sha)
        if not p.exists():
            out.append(f"diff --hit a/{path} b/{path}\ndeleted file mode {mode:o}\n" +
                       unified(a, b"", f"a/{path}", "/dev/null"))
            continue
        b = p.read_bytes()
        if a != b:
            out.append(f"diff --hit a/{path} b/{path}\n" + unified(a, b, f"a/{path}", f"b/{path}"))
    return "".join(out)


def diff_stat(changes: list[FileChange], repo: "Repository") -> str:
    lines = []
    ins = dels = 0
    for ch in changes:
        a = repo.store.read_blob(ch.old_sha) if ch.old_sha else b""
        b = repo.store.read_blob(ch.new_sha) if ch.new_sha else b""
        if is_binary(a) or is_binary(b):
            lines.append(f" {ch.path} | Bin")
            continue
        al = a.decode("utf-8", "replace").splitlines()
        bl = b.decode("utf-8", "replace").splitlines()
        i = d = 0
        for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, al, bl).get_opcodes():
            if op in ("replace", "delete"):
                d += i2 - i1
            if op in ("replace", "insert"):
                i += j2 - j1
        ins += i
        dels += d
        lines.append(f" {ch.path} | {i + d} " + "+" * min(i, 40) + "-" * min(d, 40))
    lines.append(f" {len(changes)} file(s) changed, {ins} insertion(s)(+), {dels} deletion(s)(-)")
    return "\n".join(lines)
