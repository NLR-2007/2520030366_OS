"""Stash: shelve uncommitted changes and bring them back later."""
from __future__ import annotations

import json
import time
from typing import TYPE_CHECKING

from .objects import Commit, build_tree

if TYPE_CHECKING:
    from .repo import Repository


def _file(repo: "Repository"):
    return repo.extras_dir / "stash.json"


def _load(repo: "Repository") -> list[dict]:
    f = _file(repo)
    return json.loads(f.read_text()) if f.exists() else []


def _save(repo: "Repository", items: list[dict]) -> None:
    _file(repo).write_text(json.dumps(items, indent=1))


def push(repo: "Repository", message: str | None = None, include_untracked: bool = False) -> dict:
    from .repo import HitError
    st = repo.status()
    if not (st.staged or st.unstaged or (include_untracked and st.untracked)):
        raise HitError("nothing to stash")
    name, email = repo.identity()
    head = repo.refs.head()
    # index tree
    index_tree = repo.write_index_tree()
    # worktree tree = index + working file contents (+ untracked if asked)
    files = dict(repo.index.as_tree_files())
    for path in list(files):
        p = repo.root / path
        if not p.exists():
            del files[path]
        else:
            sha, mode = repo._hash_file(path)
            files[path] = (mode, sha)
    if include_untracked:
        for path in st.untracked:
            sha, mode = repo._hash_file(path)
            files[path] = (mode, sha)
    work_tree = build_tree(repo.store, files)
    msg = message or f"WIP on {st.branch or 'HEAD'}: {repo.head_commit().summary if head else '(no commits)'}"
    c = Commit.new(work_tree, [head] if head else [], name, email, msg)
    sha = repo.store.write_commit(c)
    entry = {"sha": sha, "index_tree": index_tree, "message": msg, "time": int(time.time()),
             "branch": st.branch, "untracked": st.untracked if include_untracked else []}
    items = _load(repo)
    items.insert(0, entry)
    _save(repo, items)
    # clean the working tree back to HEAD
    repo.checkout_tree(repo.head_files(), force=True)
    for path in entry["untracked"]:
        p = repo.root / path
        if p.exists():
            p.unlink()
    return entry


def list_stashes(repo: "Repository") -> list[dict]:
    return _load(repo)


def pop(repo: "Repository", idx: int = 0, keep: bool = False) -> dict:
    from .repo import HitError
    from .objects import flatten_tree
    from .merge import merge_blobs
    items = _load(repo)
    if not items:
        raise HitError("no stashes saved")
    if idx >= len(items):
        raise HitError(f"stash@{{{idx}}} does not exist")
    entry = items[idx]
    stashed = flatten_tree(repo.store, repo.store.read_commit(entry["sha"]).tree)
    base = repo.commit_files(entry["sha"] and repo.store.read_commit(entry["sha"]).parents[0]) \
        if repo.store.read_commit(entry["sha"]).parents else {}
    current = repo.index.as_tree_files()
    conflicts = []
    for path, (mode, sha) in stashed.items():
        b = base.get(path)
        cur = current.get(path)
        if b == (mode, sha):
            continue  # unchanged in stash
        p = repo.root / path
        data = repo.store.read_blob(sha)
        if cur and cur != b and p.exists():
            merged, conflict = merge_blobs(repo.store.read_blob(b[1]) if b else b"", p.read_bytes(), data,
                                           "current", "stash")
            data = merged
            if conflict:
                conflicts.append(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
    for path in base:
        if path not in stashed and (repo.root / path).exists():
            (repo.root / path).unlink()
    if not keep:
        items.pop(idx)
        _save(repo, items)
    entry["conflicts"] = conflicts
    return entry


def drop(repo: "Repository", idx: int = 0) -> dict:
    from .repo import HitError
    items = _load(repo)
    if idx >= len(items):
        raise HitError(f"stash@{{{idx}}} does not exist")
    e = items.pop(idx)
    _save(repo, items)
    return e
