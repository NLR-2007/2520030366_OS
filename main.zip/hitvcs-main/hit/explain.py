"""Plain-English explanations for `hit explain <command>` and `hit help me`."""
from __future__ import annotations

EXPLAIN: dict[str, str] = {
    "init": "Creates a hidden .hit folder here. From now on HIT can track every change you make in this folder.",
    "add": "Marks files as 'ready to be saved'. Nothing is saved yet — that happens with `hit commit`. "
           "`hit add .` marks everything.",
    "status": "Shows three lists: files ready to be saved (staged), files you edited but haven't marked yet, "
              "and brand-new files HIT doesn't track. It also tells you what to do next.",
    "diff": "Shows the exact lines you added (+) and removed (-) since the last save. "
            "`hit diff --staged` shows what will go into the next commit.",
    "commit": "Saves a permanent checkpoint of all staged files, with a message describing the change. "
              "You can always come back to it later. `-a` stages tracked files automatically. "
              "`--amend` fixes the last commit instead of making a new one.",
    "log": "Lists your checkpoints, newest first, with who made them and when. "
           "`--graph` draws the branch structure, `-n 5` shows only five.",
    "branch": "A branch is a separate line of work. `hit branch` lists them, `hit branch name` creates one, "
              "`-d name` deletes one, `-m new` renames the current one.",
    "switch": "Moves you to another branch: your files change to match that branch's latest commit. "
              "`-c name` creates the branch and switches to it in one go.",
    "checkout": "Restores files from a commit: `hit checkout -- file.py` throws away your edits to that file. "
                "`hit checkout a1b2c3` moves you to an old commit (HIT creates a branch there so nothing is lost).",
    "merge": "Combines another branch into yours. If both branches changed the same lines, HIT marks the "
             "spots with <<<<<<< and >>>>>>> so you can pick. Then `hit add` the file and `hit merge --continue`.",
    "tag": "Gives a commit a memorable name, like v1.0. Tags never move.",
    "reset": "Moves your branch back to an older commit. `--soft` keeps all changes ready to commit, "
             "(default) keeps them in your files but un-stages them, `--hard` throws them away. "
             "All three are reversible with `hit undo`.",
    "reset --hard": "Moves your branch back to a commit AND makes your files match it exactly. Any uncommitted "
                    "edits are lost — but `hit undo` can still bring them back.",
    "stash": "Puts your uncommitted edits in a drawer so your files go back to the last commit. "
             "`hit stash pop` takes them back out.",
    "ignore": "Adds patterns to .hitignore so HIT never tracks those files (e.g. node_modules, *.log).",
    "files": "Lists every file inside a commit, with A/M/D markers showing what that commit added, "
             "modified or deleted compared to the one before it.",
    "rm": "Stops tracking a file from the next commit onward. Old commits still have it. "
          "`--keep` leaves the file on disk.",
    "purge": "Deletes a file from EVERY commit, as if it never existed. Use it for leaked passwords or huge "
             "files. HIT takes a backup first and `hit undo` reverses it. After purging, `hit push --force`.",
    "snapshot": "Zips your entire history (all commits, branches, tags) into one file in .hit/hit/snapshots. "
                "A time machine for the whole project. `--files` also includes your current working files.",
    "restore": "Replaces your history with a snapshot's. Your current state is backed up first.",
    "undo": "Reverses the last HIT action — commit, reset, merge, switch, purge, restore, anything. "
            "`hit undo 3` goes back three actions. `hit redo` re-applies.",
    "redo": "Re-applies the last thing you undid.",
    "push": "Uploads your commits to GitHub so others (or your other computer) can get them. "
            "First time, HIT asks for the repo URL. Needs `hit login` once.",
    "pull": "Downloads new commits from GitHub and merges them into your branch.",
    "fetch": "Downloads new commits from GitHub but doesn't merge them; you can look first.",
    "clone": "Downloads a whole repository from GitHub into a new folder.",
    "remote": "The GitHub address this project talks to. `hit remote add origin <url>` sets it.",
    "login": "Saves a GitHub personal access token on this computer so push/pull can authenticate. "
             "It's stored locally and only ever sent to github.com.",
    "projects": "Lists every HIT project on this computer, with branch, last commit and size.",
    "ui": "Opens the full-screen dashboard: browse projects → commits → files, delete, snapshot, push, "
          "and type English commands in the bar at the bottom.",
    "squash": "Merges several commits into one. `-n 3` squashes the last three; without -n, all of them.",
    "update": "Checks the HIT website for a newer version, shows what's new, downloads the new hit.exe, "
              "verifies its checksum and replaces the old one. `hit update --check` only checks. HIT also "
              "checks once a day on its own and reminds you; turn that off with `hit config update.check false`.",
    "wipe": "Deletes every commit and branch at once — the whole history — while leaving all your files exactly "
            "as they are. A backup is taken first and `hit undo` restores everything. If the project is on GitHub, "
            "`hit push --force` afterwards replaces the history there too.",
    "drop": "Removes one specific commit from history (its changes vanish from later commits too).",
    "config": "Sets your name and email (`hit config user.name \"Your Name\"`), stored globally in ~/.hitconfig.",
    "scan": "Searches your home folder and all drives for projects that have a .git or .hit folder — i.e. every "
            "project you ever committed on this computer — and adds them to `hit projects` / the dashboard. "
            "Git projects are opened directly; nothing is copied.",
    "import": "Adopts a project that already uses Git: copies its .git history into .hit so HIT can show every "
              "commit and file in the dashboard. Git keeps working in that folder too.",
    "uninit": "Removes the .hit folder so HIT stops tracking this project. Your files are untouched; the history is "
              "backed up to ~/.hit/trash first. Use it to start over with `hit init`.",
    "explain": "This. Ask about any command.",
    "why": "Explains the last error you hit and what to do about it.",
    "help": "`hit help` lists commands; `hit help me` walks you through it interactively.",
    "hit": "HIT is a version control system: it remembers every version of your files so you can go back, "
           "work on ideas in parallel (branches), and share via GitHub. Type what you want in plain English.",
}

ALIASES = {
    "save": "commit", "checkpoint": "commit", "history": "log", "branches": "branch",
    "go back": "undo", "backup": "snapshot", "upload": "push", "download": "pull",
    "conflict": "merge", "conflicts": "merge", "staging": "add", "stage": "add",
    "detached head": "checkout", "revert": "undo", "delete file": "rm", "remove file": "rm",
}


def explain(words: list[str]) -> str:
    key = " ".join(words).strip().lower().replace("hit ", "")
    key = ALIASES.get(key, key)
    if key in EXPLAIN:
        return EXPLAIN[key]
    first = key.split()[0] if key else ""
    first = ALIASES.get(first, first)
    if first in EXPLAIN:
        return EXPLAIN[first]
    import difflib
    close = difflib.get_close_matches(key, list(EXPLAIN), n=3, cutoff=0.5)
    if close:
        return f"I don't know '{key}'. Did you mean: " + ", ".join(close) + "?"
    return f"I don't know '{key}'. Try `hit help` for the command list."


# Error message -> friendly explanation for `hit why`
WHY: list[tuple[str, str]] = [
    ("not a HIT repository", "You're in a folder HIT isn't tracking. Either `cd` into your project, or run `hit init` here to start tracking."),
    ("nothing to commit", "There are no changes staged. Edit some files, then `hit add .` (or just say `hit save my changes as ...`)."),
    ("uncommitted changes that would be overwritten", "Switching would overwrite edits you haven't saved. Either commit them (`hit save`), put them aside (`hit stash`), or discard them (`hit switch --force <branch>`)."),
    ("unresolved conflicts", "A merge left conflict markers (<<<<<<<) in some files. Open each one, keep the lines you want, delete the markers, `hit add <file>`, then `hit merge --continue`."),
    ("remote has commits you don't have", "Someone (maybe you, on another computer) pushed to GitHub since your last pull. Run `hit pull` to merge their work, then `hit push` again."),
    ("rejected your credentials", "GitHub didn't accept your login. Run `hit login` and paste a fresh personal access token with the 'repo' scope."),
    ("repository not found", "The GitHub URL is wrong or the repo doesn't exist yet. Create it on github.com first, then `hit remote add origin <url>`."),
    ("cannot reach the server", "No internet, or GitHub is blocked. Everything else in HIT works offline — only push/pull need a connection."),
    ("no remote named", "This project isn't connected to GitHub yet. Run `hit remote add origin https://github.com/you/repo.git`."),
    ("already exists", "Something with that name already exists. Pick a different name, or delete the old one first."),
    ("unknown revision", "HIT can't find a commit or branch by that name. `hit log` shows commit ids, `hit branch` shows branches."),
    ("is not tracked", "That file was never added to HIT. Use `hit add <file>` first."),
    ("is ignored", "That file matches a pattern in .hitignore, so HIT skips it. Remove the pattern, or `hit add -f <file>` to force it."),
    ("nothing to stash", "You have no uncommitted changes to put aside."),
    ("no stashes", "The stash drawer is empty — nothing to bring back."),
    ("nothing to undo", "The journal is empty; no HIT action has been recorded yet in this repo."),
    ("no commits yet", "This repo has no commits. Make one: `hit add .` then `hit commit -m \"first\"`."),
    ("commit message is empty", "Every commit needs a short description. Use `hit commit -m \"what you did\"`."),
    ("not on a branch", "HEAD isn't on a branch. Run `hit switch main` (or another branch) first."),
    ("commit or stash your changes before merging", "Merging with unsaved edits is risky. `hit save` them or `hit stash` them, then merge."),
]


def why(last_error: str | None) -> str:
    if not last_error:
        return "No error recorded yet. When a command fails, run `hit why` right after."
    for needle, answer in WHY:
        if needle in last_error:
            return f"Last error: {last_error}\n\n{answer}"
    return f"Last error: {last_error}\n\nI don't have a specific tip for this one. `hit explain <command>` may help."
