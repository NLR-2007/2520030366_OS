"""Branches, tags and HEAD."""
from __future__ import annotations

import os
import re
from pathlib import Path

VALID_REF = re.compile(r"^(?!/)(?!.*(\.\.|//|@\{|[\s~^:?*\[\\]))[^\x00-\x1f\x7f]+(?<!\.lock)(?<!/)(?<!\.)$")


class RefError(Exception):
    pass


def write_lf(path: Path, text: str) -> None:
    """Git's metadata files use LF. Path.write_text() would turn \n into \r\n
    on Windows, which Git then reports as 'trailing garbage'."""
    path.write_bytes(text.encode("utf-8"))


class Refs:
    def __init__(self, hit_dir: Path):
        self.dir = Path(hit_dir)

    # ---- low level --------------------------------------------------------

    def _p(self, ref: str) -> Path:
        return self.dir / ref

    def read(self, ref: str) -> str | None:
        """Return the sha a ref points to (following symbolic refs), or None."""
        seen = 0
        while seen < 10:
            p = self._p(ref)
            if not p.exists():
                packed = self._read_packed().get(ref)
                return packed
            val = p.read_text().strip()
            if val.startswith("ref: "):
                ref = val[5:]
                seen += 1
                continue
            return val or None
        raise RefError("symbolic ref loop")

    def read_symbolic(self, ref: str) -> str | None:
        """If ref is symbolic, return its target ref name; else None."""
        p = self._p(ref)
        if p.exists():
            val = p.read_text().strip()
            if val.startswith("ref: "):
                return val[5:]
        return None

    def write(self, ref: str, sha: str) -> None:
        p = self._p(ref)
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_name(p.name + ".lock")
        write_lf(tmp, sha + "\n")
        os.replace(tmp, p)

    def write_symbolic(self, ref: str, target: str) -> None:
        p = self._p(ref)
        p.parent.mkdir(parents=True, exist_ok=True)
        write_lf(p, f"ref: {target}\n")

    def delete(self, ref: str) -> bool:
        p = self._p(ref)
        existed = False
        if p.exists():
            p.unlink()
            existed = True
        packed = self._read_packed()
        if ref in packed:
            del packed[ref]
            self._write_packed(packed)
            existed = True
        return existed

    def exists(self, ref: str) -> bool:
        return self._p(ref).exists() or ref in self._read_packed()

    def _read_packed(self) -> dict[str, str]:
        p = self.dir / "packed-refs"
        out: dict[str, str] = {}
        if p.exists():
            for line in p.read_text().splitlines():
                if not line or line.startswith("#") or line.startswith("^"):
                    continue
                sha, _, name = line.partition(" ")
                out[name] = sha
        return out

    def _write_packed(self, refs: dict[str, str]) -> None:
        p = self.dir / "packed-refs"
        lines = ["# pack-refs with: peeled fully-peeled sorted"]
        for name in sorted(refs):
            lines.append(f"{refs[name]} {name}")
        write_lf(p, "\n".join(lines) + "\n")

    def list(self, prefix: str) -> dict[str, str]:
        """All refs under a prefix like 'refs/heads/' -> {short_name: sha}."""
        out: dict[str, str] = {}
        base = self._p(prefix)
        if base.exists():
            for root, _dirs, files in os.walk(base):
                for f in files:
                    if f.endswith(".lock"):
                        continue
                    full = Path(root) / f
                    rel = full.relative_to(base).as_posix()
                    sha = self.read(prefix + rel)
                    if sha:
                        out[rel] = sha
        for name, sha in self._read_packed().items():
            if name.startswith(prefix):
                out.setdefault(name[len(prefix):], sha)
        return out

    # ---- HEAD / branches --------------------------------------------------

    def head(self) -> str | None:
        return self.read("HEAD")

    def current_branch(self) -> str | None:
        target = self.read_symbolic("HEAD")
        if target and target.startswith("refs/heads/"):
            return target[len("refs/heads/"):]
        return None

    def set_head_branch(self, branch: str) -> None:
        self.write_symbolic("HEAD", f"refs/heads/{branch}")

    def set_head_detached(self, sha: str) -> None:
        self.write("HEAD", sha)

    def branches(self) -> dict[str, str]:
        return self.list("refs/heads/")

    def tags(self) -> dict[str, str]:
        return self.list("refs/tags/")

    def branch_exists(self, name: str) -> bool:
        return self.exists(f"refs/heads/{name}")

    def create_branch(self, name: str, sha: str) -> None:
        if not VALID_REF.match(name):
            raise RefError(f"'{name}' is not a valid branch name")
        if self.branch_exists(name):
            raise RefError(f"branch '{name}' already exists")
        self.write(f"refs/heads/{name}", sha)

    def update_branch(self, name: str, sha: str) -> None:
        self.write(f"refs/heads/{name}", sha)

    def delete_branch(self, name: str) -> None:
        if not self.delete(f"refs/heads/{name}"):
            raise RefError(f"branch '{name}' does not exist")

    def update_head(self, sha: str) -> None:
        """Move whatever HEAD points at (branch or detached) to sha."""
        branch = self.current_branch()
        if branch:
            self.update_branch(branch, sha)
        else:
            self.set_head_detached(sha)
