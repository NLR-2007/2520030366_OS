"""Three-way merge of branches, with conflict markers."""
from __future__ import annotations

import difflib
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from .index import IndexEntry
from .objects import MODE_FILE

if TYPE_CHECKING:
    from .repo import Repository


@dataclass
class MergeResult:
    kind: str                       # "up-to-date" | "fast-forward" | "merged" | "conflict"
    sha: str | None = None
    conflicts: list[str] = field(default_factory=list)


def _base_matches(base: list[str], side: list[str]) -> list[tuple[int, int, int]]:
    """Matching blocks (base_i, side_j, size) between base and side."""
    sm = difflib.SequenceMatcher(None, base, side, autojunk=False)
    return [(m.a, m.b, m.size) for m in sm.get_matching_blocks() if m.size]


def merge_lines(base: list[str], ours: list[str], theirs: list[str],
                ours_label: str, theirs_label: str) -> tuple[list[str], bool]:
    """diff3-style merge. Returns (lines, had_conflict).

    Find regions of base that are unchanged in BOTH sides; everything between
    two such regions is a "hunk" where we compare what each side did.
    """
    mo = _base_matches(base, ours)
    mt = _base_matches(base, theirs)

    # base line index -> position in ours / theirs, for lines unchanged on that side
    o_map: dict[int, int] = {}
    for a, b, size in mo:
        for k in range(size):
            o_map[a + k] = b + k
    t_map: dict[int, int] = {}
    for a, b, size in mt:
        for k in range(size):
            t_map[a + k] = b + k

    # stable = base lines unchanged in both, grouped into contiguous runs that
    # are also contiguous in ours and theirs
    stable: list[tuple[int, int, int, int]] = []  # (b_start, b_end, o_start, t_start)
    i = 0
    n = len(base)
    while i < n:
        if i in o_map and i in t_map:
            j = i
            while (j + 1 < n and (j + 1) in o_map and (j + 1) in t_map
                   and o_map[j + 1] == o_map[j] + 1 and t_map[j + 1] == t_map[j] + 1):
                j += 1
            stable.append((i, j + 1, o_map[i], t_map[i]))
            i = j + 1
        else:
            i += 1

    result: list[str] = []
    conflict = False
    b_pos = o_pos = t_pos = 0
    for b_start, b_end, o_start, t_start in stable + [(n, n, len(ours), len(theirs))]:
        b_chunk = base[b_pos:b_start]
        o_chunk = ours[o_pos:o_start]
        t_chunk = theirs[t_pos:t_start]
        if o_chunk == t_chunk:
            result.extend(o_chunk)
        elif o_chunk == b_chunk:
            result.extend(t_chunk)
        elif t_chunk == b_chunk:
            result.extend(o_chunk)
        else:
            conflict = True
            result.append(f"<<<<<<< {ours_label}\n")
            result.extend(o_chunk)
            result.append("=======\n")
            result.extend(t_chunk)
            result.append(f">>>>>>> {theirs_label}\n")
        result.extend(base[b_start:b_end])
        b_pos, o_pos, t_pos = b_end, o_start + (b_end - b_start), t_start + (b_end - b_start)
    return result, conflict


def merge_blobs(base: bytes, ours: bytes, theirs: bytes, ours_label: str, theirs_label: str) -> tuple[bytes, bool]:
    if ours == theirs:
        return ours, False
    if base == ours:
        return theirs, False
    if base == theirs:
        return ours, False
    if b"\0" in base[:8000] or b"\0" in ours[:8000] or b"\0" in theirs[:8000]:
        return ours, True
    bl = base.decode("utf-8", "replace").splitlines(keepends=True)
    ol = ours.decode("utf-8", "replace").splitlines(keepends=True)
    tl = theirs.decode("utf-8", "replace").splitlines(keepends=True)
    lines, conflict = merge_lines(bl, ol, tl, ours_label, theirs_label)
    return "".join(lines).encode(), conflict


def merge(repo: "Repository", theirs_rev: str, message: str | None = None,
          no_ff: bool = False) -> MergeResult:
    st = repo.status()
    if st.staged or st.unstaged:
        from .repo import HitError
        raise HitError("commit or stash your changes before merging")
    ours_sha = repo.refs.head()
    theirs_sha = repo.resolve(theirs_rev)
    if not ours_sha:
        repo.checkout_tree(repo.commit_files(theirs_sha), force=True)
        repo.refs.update_head(theirs_sha)
        return MergeResult("fast-forward", theirs_sha)
    if theirs_sha == ours_sha or theirs_sha in repo.ancestors(ours_sha):
        return MergeResult("up-to-date", ours_sha)
    base = repo.merge_base(ours_sha, theirs_sha)
    if base == ours_sha and not no_ff:
        repo.checkout_tree(repo.commit_files(theirs_sha))
        repo.refs.update_head(theirs_sha)
        return MergeResult("fast-forward", theirs_sha)
    if base == ours_sha and no_ff:
        repo.checkout_tree(repo.commit_files(theirs_sha), force=True)
        label = repo.refs.current_branch() or "HEAD"
        c = repo.commit(message or f"Merge {theirs_rev} into {label}",
                        allow_empty=True, parents=[ours_sha, theirs_sha])
        return MergeResult("merged", c.sha)

    base_files = repo.commit_files(base) if base else {}
    ours_files = repo.commit_files(ours_sha)
    theirs_files = repo.commit_files(theirs_sha)
    ours_label = repo.refs.current_branch() or "HEAD"
    theirs_label = theirs_rev

    merged: dict[str, tuple[int, str]] = {}
    conflicts: list[str] = []
    conflict_entries: list[IndexEntry] = []
    for path in sorted(set(base_files) | set(ours_files) | set(theirs_files)):
        b = base_files.get(path)
        o = ours_files.get(path)
        t = theirs_files.get(path)
        if o == t:
            if o:
                merged[path] = o
            continue
        if b == o:            # only theirs changed
            if t:
                merged[path] = t
            continue
        if b == t:            # only ours changed
            if o:
                merged[path] = o
            continue
        # both changed
        if o and t:
            bb = repo.store.read_blob(b[1]) if b else b""
            data, conflict = merge_blobs(bb, repo.store.read_blob(o[1]), repo.store.read_blob(t[1]),
                                         ours_label, theirs_label)
            sha = repo.store.write_blob(data)
            merged[path] = (o[0], sha)
            if conflict:
                conflicts.append(path)
                if b:
                    conflict_entries.append(IndexEntry(path, b[1], b[0], 0, stage=1))
                conflict_entries.append(IndexEntry(path, o[1], o[0], 0, stage=2))
                conflict_entries.append(IndexEntry(path, t[1], t[0], 0, stage=3))
        else:
            # modified on one side, deleted on the other -> keep the modified version, flag it
            keep = o or t
            merged[path] = keep
            conflicts.append(path)
            if b:
                conflict_entries.append(IndexEntry(path, b[1], b[0], 0, stage=1))
            if o:
                conflict_entries.append(IndexEntry(path, o[1], o[0], 0, stage=2))
            if t:
                conflict_entries.append(IndexEntry(path, t[1], t[0], 0, stage=3))

    repo.checkout_tree(merged, force=True)
    if conflicts:
        for path in conflicts:
            repo.index.remove(path)
        for e in conflict_entries:
            repo.index.entries[(e.path, e.stage)] = e
        repo.index.save()
        from .refs import write_lf
        write_lf(repo.state_file("MERGE_HEAD"), theirs_sha + "\n")
        write_lf(repo.state_file("MERGE_MSG"), message or f"Merge {theirs_rev} into {ours_label}\n")
        return MergeResult("conflict", None, conflicts)

    msg = message or f"Merge {theirs_rev} into {ours_label}"
    c = repo.commit(msg, allow_empty=True, parents=[ours_sha, theirs_sha])
    return MergeResult("merged", c.sha)


def continue_merge(repo: "Repository", message: str | None = None) -> str:
    from .repo import HitError
    mh = repo.state_file("MERGE_HEAD")
    if not mh.exists():
        raise HitError("no merge in progress")
    if repo.index.conflicts():
        raise HitError("conflicts still unresolved: " + ", ".join(repo.index.conflicts()),
                       "edit the files, then `hit add <file>` each one")
    theirs = mh.read_text().strip()
    msg = message or repo.state_file("MERGE_MSG").read_text()
    c = repo.commit(msg, allow_empty=True, parents=[repo.refs.head(), theirs])
    abort_merge(repo, keep_tree=True)
    return c.sha


def abort_merge(repo: "Repository", keep_tree: bool = False) -> None:
    from .repo import HitError
    mh = repo.state_file("MERGE_HEAD")
    if not mh.exists():
        raise HitError("no merge in progress")
    mh.unlink()
    mm = repo.state_file("MERGE_MSG")
    if mm.exists():
        mm.unlink()
    if not keep_tree:
        repo.checkout_tree(repo.head_files(), force=True)
