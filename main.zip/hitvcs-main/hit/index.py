"""Staging area, stored in Git's index v2 binary format."""
from __future__ import annotations

import hashlib
import os
import struct
from dataclasses import dataclass
from pathlib import Path

SIGNATURE = b"DIRC"
VERSION = 2


@dataclass
class IndexEntry:
    path: str
    sha: str
    mode: int
    size: int
    mtime: int = 0
    ctime: int = 0
    stage: int = 0  # 0 normal, 1 base, 2 ours, 3 theirs (during a conflict)
    mtime_ns: int = 0   # nanosecond part of mtime (Git index keeps both)
    ctime_ns: int = 0

    @classmethod
    def from_stat(cls, rel: str, sha: str, mode: int, st: os.stat_result) -> "IndexEntry":
        return cls(rel, sha, mode, st.st_size,
                   st.st_mtime_ns // 1_000_000_000, st.st_ctime_ns // 1_000_000_000, 0,
                   st.st_mtime_ns % 1_000_000_000, st.st_ctime_ns % 1_000_000_000)

    @classmethod
    def from_file(cls, root: Path, rel: str, sha: str, mode: int) -> "IndexEntry":
        return cls.from_stat(rel, sha, mode, (root / rel).lstat())

    @property
    def mtime_total_ns(self) -> int:
        return self.mtime * 1_000_000_000 + self.mtime_ns


class Index:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.entries: dict[tuple[str, int], IndexEntry] = {}
        self.unsupported = False
        # timestamp of the index file when we read it; used for the racy-clean rule
        try:
            self.loaded_mtime_ns = self.path.stat().st_mtime_ns
        except OSError:
            self.loaded_mtime_ns = 0
        if self.path.exists():
            try:
                self._load()
            except (struct.error, ValueError, IndexError):
                self.entries.clear()
                self.unsupported = True

    # ---- persistence ------------------------------------------------------

    def _load(self) -> None:
        data = self.path.read_bytes()
        if len(data) < 12 or data[:4] != SIGNATURE:
            return
        version, count = struct.unpack(">II", data[4:12])
        if version not in (2, 3, 4):
            self.unsupported = True   # Repository rebuilds it from HEAD
            return
        pos = 12
        prev_name = b""
        for _ in range(count):
            fields = struct.unpack(">IIIIIIIIII20sH", data[pos:pos + 62])
            ctime, ctime_ns, mtime, mtime_ns, _dev, _ino, mode, _uid, _gid, size, sha_b, flags = fields
            pos += 62
            entry_start = pos - 62
            name_len = flags & 0x0FFF
            stage = (flags >> 12) & 0x3
            if version >= 3 and flags & 0x4000:   # extended flags word
                pos += 2
            if version == 4:
                # prefix-compressed names: varint "strip N from previous", then NUL-terminated suffix
                strip = 0
                shift = 0
                while True:
                    b = data[pos]
                    pos += 1
                    strip = (strip << 7) | (b & 0x7F)
                    if not b & 0x80:
                        break
                end = data.index(b"\0", pos)
                name = prev_name[:len(prev_name) - strip] + data[pos:end]
                pos = end + 1
            else:
                if name_len < 0x0FFF:
                    name = data[pos:pos + name_len]
                    pos += name_len
                else:
                    end = data.index(b"\0", pos)
                    name = data[pos:end]
                    pos = end
                # entries are padded with NULs to a multiple of 8 bytes (from entry start)
                entry_len = pos - entry_start
                pad = (8 - (entry_len % 8)) or 8
                pos += pad
            prev_name = name
            path = name.decode("utf-8", "surrogateescape")
            e = IndexEntry(path, sha_b.hex(), mode, size, mtime, ctime, stage, mtime_ns, ctime_ns)
            self.entries[(path, stage)] = e

    def save(self) -> None:
        parts = [struct.pack(">4sII", SIGNATURE, VERSION, len(self.entries))]
        pack = struct.Struct(">IIIIIIIIII20sH").pack
        for key in sorted(self.entries, key=lambda k: (k[0].encode("utf-8", "surrogateescape"), k[1])):
            e = self.entries[key]
            name = e.path.encode("utf-8", "surrogateescape")
            flags = (min(len(name), 0x0FFF)) | (e.stage << 12)
            # index fields are 32-bit; clamp so huge/odd values can never crash a save
            rec = pack(e.ctime & 0xFFFFFFFF, e.ctime_ns & 0xFFFFFFFF,
                       e.mtime & 0xFFFFFFFF, e.mtime_ns & 0xFFFFFFFF, 0, 0, e.mode, 0, 0,
                       e.size & 0xFFFFFFFF, bytes.fromhex(e.sha), flags) + name
            parts.append(rec)
            parts.append(b"\0" * ((8 - (len(rec) % 8)) or 8))
        body = b"".join(parts)
        body += hashlib.sha1(body).digest()
        tmp = self.path.with_suffix(".lock")
        tmp.write_bytes(body)
        os.replace(tmp, self.path)

    # ---- stat cache -------------------------------------------------------

    def stat_unchanged(self, e: "IndexEntry | None", st: os.stat_result) -> bool:
        """True only when the file on disk is certainly the version in the index,
        judged from size + nanosecond mtime. Entries written in the same instant
        as (or after) the index file are "racily clean" and never trusted — the
        caller must hash the file instead (Git uses the same rule)."""
        if e is None or e.stage != 0 or not e.mtime:
            return False
        if e.size != (st.st_size & 0xFFFFFFFF):
            return False
        if e.mtime != (st.st_mtime_ns // 1_000_000_000) & 0xFFFFFFFF:
            return False
        if e.mtime_ns and e.mtime_ns != st.st_mtime_ns % 1_000_000_000:
            return False
        return e.mtime_total_ns < self.loaded_mtime_ns

    # ---- queries ----------------------------------------------------------

    def get(self, path: str) -> IndexEntry | None:
        return self.entries.get((path, 0))

    def paths(self) -> list[str]:
        return sorted({p for (p, s) in self.entries if s == 0})

    def as_tree_files(self) -> dict[str, tuple[int, str]]:
        return {e.path: (e.mode, e.sha) for (p, s), e in self.entries.items() if s == 0}

    def add(self, entry: IndexEntry) -> None:
        # adding a stage-0 entry resolves any conflict stages for that path
        for s in (1, 2, 3):
            self.entries.pop((entry.path, s), None)
        self.entries[(entry.path, entry.stage)] = entry

    def remove(self, path: str) -> bool:
        removed = False
        for s in (0, 1, 2, 3):
            if self.entries.pop((path, s), None) is not None:
                removed = True
        return removed

    def conflicts(self) -> list[str]:
        return sorted({p for (p, s) in self.entries if s > 0})

    def clear(self) -> None:
        self.entries.clear()
