"""The `hit` command line: exact commands, plain-English commands, confirm prompts."""
from __future__ import annotations

import argparse
import getpass
import os
import sys
import time
from datetime import datetime
from pathlib import Path

from . import __version__
from .repo import HitError, NotARepo, Repository, global_config_path, global_hit_dir

# --------------------------------------------------------------------------
# Output helpers
# --------------------------------------------------------------------------

from .output import (ARROW, DOT, TICK, USE_COLOR, blank, blue, bold, c, cyan, short_path,
                     detail, dim, fail, field, file_list, green, hint,
                     human_size, info, note, ok, plural, red, relative_time,
                     say, section, status_glyph, summary_counts, table, warn,
                     yellow)


YES = False  # --yes flag


def confirm(question: str, default: bool = False, force_ask: bool = False) -> bool:
    if os.environ.get("HIT_FORCE_YES"):   # for scripts/CI: answer yes to everything
        return True
    if YES and not force_ask:
        return True
    if not sys.stdin.isatty():
        return default
    suffix = " [Y/n] " if default else " [y/N] "
    try:
        ans = input(question + suffix).strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()
        return False
    if not ans:
        return default
    return ans in ("y", "yes")


def last_error_file() -> Path:
    return global_hit_dir() / "last_error"


def record_error(msg: str) -> None:
    try:
        last_error_file().write_text(msg)
    except OSError:
        pass


# --------------------------------------------------------------------------
# Journal wrapper
# --------------------------------------------------------------------------

class journaled:
    """with journaled(repo, "commit") as j: ...; j.done("description")"""

    def __init__(self, repo: Repository, command: str):
        from .journal import Journal
        self.j = Journal(repo)
        self.command = command
        self.token = None
        self.desc = None
        self.snapshot = None

    def __enter__(self):
        self.token = self.j.begin(self.command)
        return self

    def done(self, desc: str, worktree_snapshot: str | None = None):
        self.desc = desc
        self.snapshot = worktree_snapshot

    def __exit__(self, exc_type, exc, tb):
        if exc_type is None and self.desc:
            self.j.end(self.token, self.desc, self.snapshot)
        return False


# --------------------------------------------------------------------------
# Commands
# --------------------------------------------------------------------------

def cmd_init(args) -> None:
    from .templates import detect_templates, write_license, write_readme
    path = Path(args.path or ".").resolve()
    path.mkdir(parents=True, exist_ok=True)
    repo = Repository.init(path, template=args.template)
    name, _ = repo.identity()

    ok(f"Repository ready in {bold(str(repo.root))}")
    kinds = detect_templates(repo.root)
    field("created", ".hitignore" + (f"  ({', '.join(kinds)} rules)" if kinds else ""))
    if not args.no_readme:
        if write_readme(repo.root, repo.root.name, kinds):
            field("", "README.md")
    lic = args.license
    if not lic and not args.no_license and sys.stdin.isatty():
        note("a LICENSE tells other people how they may use your code")
        ans = _ask("  license?  [m]it  [a]pache-2.0  [g]pl-3.0  [n]one  (n): ", "n").lower()
        lic = {"m": "mit", "a": "apache-2.0", "g": "gpl-3.0"}.get(ans[:1])
    if lic:
        write_license(repo.root, lic, name, repo.root.name)
        field("", f"LICENSE ({lic.upper()})")
    field("author", f"{name}" + ("" if repo.config.get("user", "name") else dim("  (set yours: hit config user.name \"Your Name\")")))

    files = repo.walk_files()
    if files:
        blank()
        say(f"  {len(files)} {plural(len(files), 'file')} not tracked yet:")
        file_list([("U", f) for f in files], limit=25)
    blank()
    hint('stage and commit with `hit add .` then `hit commit -m "first commit"`')
    hint('or simply: hit save everything as first commit')


def cmd_uninit(args) -> None:
    """Remove HIT tracking from this folder (your files stay)."""
    import shutil
    import time
    from . import registry, snapshot
    repo = Repository.find()
    n = len(repo.log()) if repo.refs.head() else 0
    say(f"This removes HIT tracking from {bold(str(repo.root))}")
    say(dim(f"  {n} commit(s) of history will be deleted. Your project files are NOT touched."))
    say(dim("  A backup of the history goes to ~/.hit/trash first."))
    if not confirm("Remove HIT from this folder?", force_ask=True):
        say("cancelled")
        return
    if n:
        trash = global_hit_dir() / "trash"
        trash.mkdir(exist_ok=True)
        snap = snapshot.create(repo, f"{repo.root.name}-{time.strftime('%Y%m%d-%H%M%S')}", with_worktree=False)
        shutil.move(str(snap), str(trash / snap.name))
        say(dim(f"  backup: {trash / snap.name}"))
    shutil.rmtree(repo.hit_dir, ignore_errors=True)
    registry.remove_path(repo.root)
    ok("HIT tracking removed. Run `hit init` to start fresh.")


def _rmtree_force(target: Path) -> None:
    """rmtree that also removes read-only files (Git marks objects read-only)."""
    import shutil
    import stat

    def onerror(func, p, _exc):
        try:
            os.chmod(p, stat.S_IWRITE)
            func(p)
        except OSError:
            pass

    if target.exists():
        shutil.rmtree(target, onerror=onerror)


def _copy_git_dir(src: Path, dst: Path) -> None:
    """Copy .git -> .hit. Objects are content-addressed, so identical files are skipped."""
    import shutil
    import stat
    skip_dirs = {"hooks", "logs"}
    for root, dirs, files in os.walk(src):
        rel = Path(root).relative_to(src)
        dirs[:] = [d for d in dirs if not (rel == Path(".") and d in skip_dirs)]
        out_dir = dst / rel
        out_dir.mkdir(parents=True, exist_ok=True)
        for f in files:
            if f.endswith(".lock"):
                continue
            s_p = Path(root) / f
            d_p = out_dir / f
            if d_p.exists():
                if rel.parts and rel.parts[0] == "objects":
                    continue  # same content-addressed object already there
                os.chmod(d_p, stat.S_IWRITE)
            shutil.copy2(s_p, d_p)
            os.chmod(d_p, stat.S_IWRITE | stat.S_IREAD)


def cmd_import(args) -> None:
    """Adopt an existing Git repository (.git) so HIT can show and manage it."""
    import shutil
    from . import registry
    from .index import IndexEntry
    path = Path(args.path or ".").resolve()
    git_dir = path / ".git"
    if not git_dir.is_dir():
        # maybe the Git repo root is a parent folder
        for parent in path.parents:
            if (parent / ".git").is_dir():
                say(yellow(f"No .git here, but the parent folder is a Git project: {parent}"))
                if confirm(f"Import {parent.name} instead?", default=True):
                    path, git_dir = parent, parent / ".git"
                break
    if not git_dir.is_dir():
        say(red("This folder has no Git history (no .git folder)."))
        say("  That's normal if it came from a ZIP download — ZIPs don't include the hidden .git folder.")
        say("")
        say("  What you can do:")
        say(f"    • project is on GitHub?   hit clone https://github.com/<user>/<repo>.git   (gets it WITH all commits)")
        say(f"    • just start tracking it: hit init   then   hit save everything as first version")
        raise HitError("nothing to import")
    if (path / ".hit").is_dir():
        # both exist: the user made commits with Git earlier and started HIT later
        old = Repository(path)
        n_hit = len(old.log()) if old.refs.head() else 0
        say(f"This folder already has HIT history ({n_hit} commit(s)) AND Git history.")
        say(dim("  Importing replaces HIT's history with Git's. HIT's current history is backed up to ~/.hit/trash first."))
        if not confirm("Replace HIT history with the Git history?", force_ask=True):
            say("cancelled")
            return
        import time
        from . import snapshot
        trash = global_hit_dir() / "trash"
        trash.mkdir(exist_ok=True)
        if n_hit:
            snap = snapshot.create(old, f"{path.name}-before-import-{time.strftime('%Y%m%d-%H%M%S')}", with_worktree=False)
            shutil.move(str(snap), str(trash / snap.name))
            say(dim(f"  backup: {trash / snap.name}"))
        old.store._packs = None
        import gc
        del old
        gc.collect()
        _rmtree_force(path / ".hit")
    say(f"Importing Git repository {bold(str(path))} into HIT…")
    # .git and .hit share the same on-disk format, so a copy is a faithful import
    _copy_git_dir(git_dir, path / ".hit")
    for d in ("objects/pack", "objects/info", "hit/snapshots", "hit/backups"):
        (path / ".hit" / d).mkdir(parents=True, exist_ok=True)
    repo = Repository(path)
    # rebuild the staging area from HEAD (Git's index may use a newer version than we write)
    repo.index.clear()
    for rel, (mode, sha) in repo.head_files().items():
        if (path / rel).exists():
            repo.index.add(IndexEntry.from_file(path, rel, sha, mode))
        else:
            repo.index.add(IndexEntry(rel, sha, mode, 0))
    repo.index.save()
    registry.register(repo)
    n = len(repo.log()) if repo.refs.head() else 0
    branches = ", ".join(sorted(repo.refs.branches())) or "-"
    from .remote import get_remote
    ok(f"imported {n} commit(s), branches: {branches}")
    if get_remote(repo):
        say(dim(f"  GitHub remote kept: {get_remote(repo)}"))
    say("")
    for cm in repo.log(limit=10):
        say(f"  {yellow(cm.short)} {cm.summary[:60]}  {dim(relative_time(cm.commit_time))}")
    if n > 10:
        say(dim(f"  … and {n - 10} more   (hit log)"))
    say("")
    say(dim("  .git is untouched — Git still works here too. See everything in the dashboard: hit ui"))
    if not args.keep_git and confirm("Remove the old .git folder now? (HIT has a full copy)", default=False):
        shutil.rmtree(git_dir, ignore_errors=True)
        ok("removed .git")


def cmd_add(args) -> None:
    repo = Repository.find()
    paths = list(args.paths or [])
    if getattr(args, "all", False) or (not paths and not getattr(args, "update", False)):
        paths = paths or [str(repo.root)]
    if getattr(args, "update", False):
        paths = [str(repo.root / p) for p in repo.index.paths()] or []
        if not paths:
            info("no tracked files to update")
            return

    before = repo.head_files()
    if args.force:
        from .index import IndexEntry
        staged = []
        for p in paths:
            rel = repo.rel(p)
            sha, mode = repo._hash_file(rel)
            repo.index.add(IndexEntry.from_file(repo.root, rel, sha, mode))
            staged.append(rel)
        repo.index.save()
    else:
        staged = repo.add(paths)
    if not staged:
        ok("Nothing new to stage")
        note("every file is already staged, unchanged, or ignored")
        return

    idx = repo.index.as_tree_files()
    rows, counts = [], {}
    for rel in sorted(staged):
        if rel not in idx:
            st = "D"
        elif rel not in before:
            st = "A"
        elif before[rel] != idx[rel]:
            st = "M"
        else:
            st = "\u00b7"
        counts[st] = counts.get(st, 0) + 1
        rows.append((st, rel))

    ok(f"Staged {len(staged)} {plural(len(staged), 'file')}")
    summary = summary_counts(counts)
    if summary:
        field("changes", summary)
    file_list(rows, limit=len(rows) if args.verbose else 20)
    hint('commit them with `hit commit -m "what you changed"`')


def cmd_unstage(args) -> None:
    repo = Repository.find()
    repo.unstage(args.paths or None)
    ok("unstaged " + (", ".join(args.paths) if args.paths else "everything"))


def cmd_status(args) -> None:
    from .remote import sync_state
    repo = Repository.find()
    st = repo.status()

    if getattr(args, "short", False):
        for p, code in sorted(st.staged.items()):
            say(f"{green(code)}  {p}")
        for p, code in sorted(st.unstaged.items()):
            say(f" {yellow(code)} {p}")
        for p in st.conflicts:
            say(f"{red('UU')} {p}")
        for p in st.untracked:
            say(f"{dim('??')} {p}")
        return

    branch = st.branch or f"detached at {st.head[:7] if st.head else 'nothing'}"
    changed = len(st.staged) + len(st.unstaged) + len(st.untracked)
    if st.clean:
        ok(f"Clean working tree on {bold(branch)}")
    else:
        info(f"On {bold(branch)} — {changed} {plural(changed, 'file')} to review")

    sync = sync_state(repo)
    if not sync.connected:
        field("github", dim("not connected") + dim("   (hit push to github)"))
    elif sync.pushed:
        field("github", green("up to date") + dim(f"   {sync.web or sync.url}"))
    else:
        field("github", yellow(sync.label) + dim(f"   {sync.web or sync.url}"))

    if repo.in_merge():
        blank()
        warn("a merge is in progress")
        hint("fix the conflicts, `hit add` each file, then `hit merge --continue`")
    if not st.head:
        field("commits", dim("none yet"))

    if st.conflicts:
        section("Conflicts — fix these, then stage them")
        file_list([("C", p) for p in st.conflicts], limit=50)
    if st.staged:
        section("Staged for the next commit")
        file_list(sorted(st.staged.items(), key=lambda kv: kv[0])[:50] and
                  [(c, p) for p, c in sorted(st.staged.items())], limit=50)
    if st.unstaged:
        section("Changed but not staged")
        file_list([(c, p) for p, c in sorted(st.unstaged.items())], limit=50)
    if st.untracked:
        section("Not tracked by HIT")
        file_list([("U", p) for p in st.untracked], limit=50)

    blank()
    if st.clean:
        note("nothing to commit")
    elif st.conflicts:
        pass
    elif st.staged and not (st.unstaged or st.untracked):
        hint('commit with `hit commit -m "what you changed"`')
    else:
        hint('stage with `hit add .`, then `hit commit -m "..."`  (or: hit save my changes as ...)')


def cmd_diff(args) -> None:
    from .diff import diff_trees, diff_worktree
    repo = Repository.find()
    paths = [repo.rel(p) for p in args.paths] if args.paths else None
    if args.revs:
        if len(args.revs) == 1:
            old = repo.commit_files(repo.resolve(args.revs[0]))
            new = repo.index.as_tree_files()
        else:
            old = repo.commit_files(repo.resolve(args.revs[0]))
            new = repo.commit_files(repo.resolve(args.revs[1]))
        text = diff_trees(repo, old, new, paths)
    else:
        text = diff_worktree(repo, paths, staged=args.staged)
    if not text:
        info("no differences")
        return
    if getattr(args, "name_only", False) or getattr(args, "stat", False):
        import re as _re
        names = [l.split(" b/", 1)[-1] for l in text.splitlines() if l.startswith("diff ")]
        if getattr(args, "name_only", False):
            for n in names:
                say(n)
            return
        ok(f"{len(names)} {plural(len(names), 'file')} changed")
        adds = sum(1 for l in text.splitlines() if l.startswith("+") and not l.startswith("+++"))
        dels = sum(1 for l in text.splitlines() if l.startswith("-") and not l.startswith("---"))
        field("lines", f"{green('+' + str(adds))}  {red('-' + str(dels))}")
        file_list([("M", n) for n in names], limit=100)
        return
    if args.staged:
        what = "last commit  →  staged (what the next commit will contain)"
    elif args.revs and len(args.revs) == 2:
        what = f"{args.revs[0]}  →  {args.revs[1]}"
    elif args.revs:
        what = f"{args.revs[0]}  →  staged"
    else:
        what = "last commit  →  your files now"
    say(dim(f"Comparing: {what}"))
    say(f"  {red('- red   = BEFORE (removed lines)')}    {green('+ green = AFTER (added lines)')}")
    say("")
    for line in text.splitlines():
        if line.startswith("diff "):
            fname = line.split(" b/", 1)[-1] if " b/" in line else line
            say(bold(f"── {fname} " + "─" * max(0, 60 - len(fname))))
        elif line.startswith("--- ") or line.startswith("+++ "):
            continue  # file labels are already in the header line
        elif line.startswith("new file mode"):
            say(green("  (new file)"))
        elif line.startswith("deleted file mode"):
            say(red("  (file deleted)"))
        elif line.startswith("+"):
            say(green(line))
        elif line.startswith("-"):
            say(red(line))
        elif line.startswith("@@"):
            say(cyan(line))
        else:
            say(line)


def cmd_commit(args) -> None:
    repo = Repository.find()
    if repo.in_merge():
        from .merge import continue_merge
        with journaled(repo, "merge --continue") as j:
            sha = continue_merge(repo, args.message)
            j.done("finished merge")
        ok(f"merge committed as {sha[:7]}")
        return
    if args.all:
        for p in repo.index.paths():
            if (repo.root / p).exists():
                repo.add([str(repo.root / p)])
            else:
                repo.index.remove(p)
        repo.index.save()
    msg = args.message
    if not msg and not args.amend:
        if sys.stdin.isatty():
            try:
                msg = input("Describe what you changed: ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                raise HitError("commit cancelled")
        if not msg:
            raise HitError("commit message is empty", "use: hit commit -m \"what you changed\"")
    with journaled(repo, "commit") as j:
        commit = repo.commit(msg or "", allow_empty=args.allow_empty, amend=args.amend)
        j.done(f"{'amended' if args.amend else 'commit'} {commit.short}: {commit.summary}")
    from .diff import tree_changes
    parent_files = repo.commit_files(commit.parents[0]) if commit.parents else {}
    changes = tree_changes(parent_files, repo.commit_files(commit.sha))
    counts: dict[str, int] = {}
    for ch in changes:
        counts[ch.status] = counts.get(ch.status, 0) + 1

    branch = repo.refs.current_branch() or "detached HEAD"
    verb = "Amended" if args.amend else "Committed"
    ok(f"{verb} {yellow(commit.short)} on {bold(branch)}")
    field("message", commit.summary)
    field("changes", f"{len(changes)} {plural(len(changes), 'file')}"
                     + (f"  {DOT}  " + summary_counts(counts) if counts else ""))
    field("tracked", f"{len(repo.index.paths())} files in total")
    if changes:
        blank()
        file_list([(ch.status, ch.path) for ch in changes], limit=15)
    blank()
    hint("undo this with `hit undo`")


def cmd_log(args) -> None:
    repo = Repository.find()
    if getattr(args, "cmd", "") == "whatchanged":
        args.stat = True
    commits = repo.log(args.rev, limit=args.n, all_branches=args.all)
    if not commits:
        say(dim("no commits yet"))
        return
    branches: dict[str, list[str]] = {}
    for name, sha in repo.refs.branches().items():
        branches.setdefault(sha, []).append(name)
    for name, sha in repo.refs.tags().items():
        try:
            sha = repo.store.read_commit(sha).sha
        except Exception:
            pass
        branches.setdefault(sha, []).append("tag: " + name)
    head = repo.refs.head()
    cur = repo.refs.current_branch()
    path_filter = repo.rel(args.path) if args.path else None
    shown = 0
    for cm in commits:
        if path_filter:
            files = repo.commit_files(cm.sha)
            parent_files = repo.commit_files(cm.parents[0]) if cm.parents else {}
            in_c = {p: v for p, v in files.items() if p == path_filter or p.startswith(path_filter + "/")}
            in_p = {p: v for p, v in parent_files.items() if p == path_filter or p.startswith(path_filter + "/")}
            if in_c == in_p:
                continue
        labels = list(branches.get(cm.sha, []))
        if cm.sha == head:
            if cur in labels:
                labels.remove(cur)
            labels.insert(0, "HEAD -> " + cur if cur else "HEAD")
        deco = f" ({', '.join(labels)})" if labels else ""
        if args.oneline:
            say(f"{yellow(cm.short)}{cyan(deco)} {cm.summary}  {dim(relative_time(cm.commit_time))}")
        else:
            prefix = ("* " if args.graph else "")
            say(prefix + yellow(f"commit {cm.sha}") + cyan(deco))
            if len(cm.parents) > 1:
                say(f"Merge: {' '.join(p[:7] for p in cm.parents)}")
            say(f"Author: {cm.author} <{cm.author_email}>")
            say(f"Date:   {datetime.fromtimestamp(cm.author_time).strftime('%a %b %d %H:%M:%S %Y')}  {dim(relative_time(cm.author_time))}")
            say("")
            for line in cm.message.rstrip("\n").split("\n"):
                say("    " + line)
            if args.stat:
                from .diff import diff_stat, tree_changes
                parent_files = repo.commit_files(cm.parents[0]) if cm.parents else {}
                say("")
                say(diff_stat(tree_changes(parent_files, repo.commit_files(cm.sha)), repo))
            say("")
        shown += 1
    if path_filter and shown == 0:
        say(dim(f"no commits touched {path_filter}"))


def cmd_files(args) -> None:
    from .diff import tree_changes
    repo = Repository.find()
    sha = repo.resolve(args.rev or "HEAD")
    cm = repo.store.read_commit(sha)
    files = repo.commit_files(sha)
    parent_files = repo.commit_files(cm.parents[0]) if cm.parents else {}
    changes = {ch.path: ch.status for ch in tree_changes(parent_files, files)}
    ok(f"{len(files)} {plural(len(files), 'file')} in {yellow(cm.short)}")
    field("message", cm.summary)
    field("when", relative_time(cm.commit_time))
    blank()
    sizes = repo.blob_sizes(b for _, b in files.values())
    rows = []
    for path in sorted(set(files) | {p for p, s in changes.items() if s == "D"}):
        status = changes.get(path, "·")
        if status == "D":
            size = "(deleted)"
        else:
            size = human_size(sizes.get(files[path][1], 0))
        if args.changed and status == "·":
            continue
        rows.append((status, path, size, files.get(path, (0, ""))[1][:7]))
    if args.tree:
        _print_tree(rows)
    else:
        for status, path, size, blob in rows:
            colour = {"A": green, "M": yellow, "D": red}.get(status, dim)
            say(f"  {colour(status)}  {path:50} {dim(size):>10}  {dim(blob)}")
    total = sum(sizes.get(b, 0) for _, b in files.values())
    blank()
    field("total", human_size(total))
    note(f"{green('A')} added   {yellow('M')} modified   {red('D')} deleted   {dim(DOT)} unchanged in this commit")


def _print_tree(rows) -> None:
    tree: dict = {}
    for status, path, size, blob in rows:
        parts = path.split("/")
        node = tree
        for part in parts[:-1]:
            node = node.setdefault(part + "/", {})
        node[parts[-1]] = (status, size)

    def walk(node: dict, indent: str) -> None:
        for name in sorted(node, key=lambda n: (not n.endswith("/"), n.lower())):
            val = node[name]
            if isinstance(val, dict):
                say(f"{indent}{cyan(name)}")
                walk(val, indent + "    ")
            else:
                status, size = val
                colour = {"A": green, "M": yellow, "D": red}.get(status, dim)
                say(f"{indent}{colour(status)} {name}  {dim(size)}")

    walk(tree, "  ")


def cmd_rm(args) -> None:
    repo = Repository.find()
    with journaled(repo, "rm") as j:
        removed = repo.rm(args.paths, keep_file=args.keep)
        j.done(f"stopped tracking {', '.join(removed)}")
    ok(f"Stopped tracking {len(removed)} {plural(len(removed), 'file')}")
    field("on disk", "kept" if args.keep else red("deleted"))
    file_list([("D", p) for p in removed], limit=20)
    note("older commits still contain these files")
    hint("to erase them from every commit instead: `hit purge <file>`")


def cmd_purge(args) -> None:
    from . import snapshot
    from .history import purge_paths
    repo = Repository.find()
    rels = [repo.rel(p) if (repo.root / p).exists() or Path(p).is_absolute() else p.replace("\\", "/").strip("/")
            for p in args.paths]
    say(red(bold("This rewrites ALL history.")) + " Every commit will be changed to never contain:")
    for r in rels:
        say(f"    {r}")
    say(dim("  A backup is taken first and `hit undo` reverses it. After purging, use `hit push --force`."))
    if not confirm("Continue?", force_ask=True):
        say("cancelled")
        return
    backup = snapshot.create(repo, "before-purge", kind="backup", with_worktree=True)
    with journaled(repo, "purge") as j:
        mapping, touched = purge_paths(repo, rels)
        j.done(f"purged {', '.join(rels)} from {touched} commit(s)", worktree_snapshot=backup.stem)
    repo.checkout_tree(repo.index.as_tree_files(), force=True)
    ok(f"removed {', '.join(rels)} from {touched} commit(s); {sum(1 for a, b in mapping.items() if a != b)} commit(s) rewritten")
    say(dim(f"  backup: {backup.name}   undo with: hit undo"))


def cmd_wipe(args) -> None:
    """Delete ALL commits (history) but keep every file on disk."""
    from . import snapshot
    repo = Repository.find()
    n = len(repo.log()) if repo.refs.head() else 0
    if n == 0:
        raise HitError("there are no commits to delete")
    branches = sorted(repo.refs.branches())
    say(red(bold(f"This deletes ALL {n} commit(s) and {len(branches)} branch(es) from history.")))
    say("  Your files stay exactly as they are on disk. Only the history goes.")
    say(dim("  A backup snapshot is taken first, and `hit undo` brings everything back."))
    if repo.refs.list("refs/remotes/"):
        say(dim("  GitHub still has the old history; after this, `hit push --force` overwrites it."))
    if not confirm("Delete all commits?", force_ask=True):
        say("cancelled")
        return
    backup = snapshot.create(repo, "before-wipe", kind="backup", with_worktree=False)
    keep_branch = repo.refs.current_branch() or "main"
    with journaled(repo, "wipe") as j:
        for b in branches:
            repo.refs.delete_branch(b)
        for t in list(repo.refs.tags()):
            repo.refs.delete(f"refs/tags/{t}")
        repo.refs.set_head_branch(keep_branch)
        # index keeps the current files staged, so the next commit is a fresh "first commit"
        j.done(f"deleted all {n} commits")
    say("")
    ok(bold(f"Deleted {n} commit(s).") + f" Files untouched. You're on an empty branch '{keep_branch}'.")
    say(dim(f"  backup: {backup.name}   undo with: hit undo"))
    say(dim("  start fresh: hit save everything as first commit"))


def cmd_drop(args) -> None:
    from . import snapshot
    from .history import drop_commit
    repo = Repository.find()
    sha = repo.resolve(args.rev)
    cm = repo.store.read_commit(sha)
    say(f"Drop commit {yellow(cm.short)} \"{cm.summary}\" from history? Its changes will disappear from later commits.")
    if not confirm("Continue?", force_ask=True):
        say("cancelled")
        return
    backup = snapshot.create(repo, "before-drop", kind="backup", with_worktree=True)
    with journaled(repo, "drop") as j:
        drop_commit(repo, sha)
        j.done(f"dropped commit {cm.short}: {cm.summary}", worktree_snapshot=backup.stem)
    ok(f"dropped {cm.short}   (undo with: hit undo)")


def cmd_squash(args) -> None:
    from .history import squash
    repo = Repository.find()
    n = args.n
    chain = repo.log(limit=n) if n else repo.log()
    if len(chain) < 2:
        raise HitError("need at least 2 commits to squash")
    say(f"Squash these {len(chain)} commits into one?")
    for cm in chain:
        say(f"    {yellow(cm.short)} {cm.summary}")
    if not confirm("Continue?", force_ask=True):
        say("cancelled")
        return
    msg = args.message
    if not msg:
        msg = "\n\n".join(cm.message.strip() for cm in reversed(chain))
    with journaled(repo, "squash") as j:
        sha = squash(repo, n, msg)
        j.done(f"squashed {len(chain)} commits into {sha[:7]}")
    ok(f"squashed into {sha[:7]}   (undo with: hit undo)")


def cmd_branch(args) -> None:
    repo = Repository.find()
    if args.delete:
        name = args.delete
        cur = repo.refs.current_branch()
        if name == cur:
            raise HitError(f"you are on '{name}' — switch to another branch first")
        sha = repo.refs.read(f"refs/heads/{name}")
        if not sha:
            raise HitError(f"no branch named '{name}'")
        head = repo.refs.head()
        if head and not args.force and sha not in repo.ancestors(head):
            if not confirm(f"'{name}' has commits not merged into {cur}. Delete anyway?", force_ask=True):
                say("cancelled")
                return
        with journaled(repo, "branch -d") as j:
            repo.refs.delete_branch(name)
            j.done(f"deleted branch {name}")
        ok(f"deleted branch {name}   (undo with: hit undo)")
        return
    if args.move:
        old = args.move[0] if len(args.move) == 2 else repo.refs.current_branch()
        new = args.move[-1]
        if not old:
            raise HitError("not on a branch")
        sha = repo.refs.read(f"refs/heads/{old}")
        if not sha:
            raise HitError(f"no branch named '{old}'")
        with journaled(repo, "branch -m") as j:
            repo.refs.create_branch(new, sha)
            repo.refs.delete_branch(old)
            if repo.refs.current_branch() is None or old == repo.refs.current_branch():
                repo.refs.set_head_branch(new)
            j.done(f"renamed branch {old} -> {new}")
        ok(f"renamed {old} -> {new}")
        return
    if args.name:
        sha = repo.resolve(args.start) if args.start else repo.refs.head()
        if not sha:
            raise HitError("no commits yet — make one first, then create branches")
        with journaled(repo, "branch") as j:
            repo.refs.create_branch(args.name, sha)
            j.done(f"created branch {args.name}")
        ok(f"created branch {args.name}   (switch with: hit switch {args.name})")
        return
    cur = repo.refs.current_branch()
    branches = repo.refs.branches()
    if not branches:
        info("no branches yet")
        hint('make your first commit with `hit commit -m "first commit"`')
        return
    rows = []
    for name in sorted(branches):
        cm = repo.store.read_commit(branches[name])
        here = name == cur
        rows.append([green("*") if here else " ",
                     bold(name) if here else name,
                     yellow(cm.short),
                     cm.summary[:46],
                     dim(relative_time(cm.commit_time))])
    if args.all:
        for name, sha in sorted(repo.refs.list("refs/remotes/").items()):
            rows.append([" ", dim("remotes/" + name), yellow(sha[:7]), dim("(on the remote)"), ""])
    ok(f"{len(branches)} {plural(len(branches), 'branch', 'branches')}" +
       (f"  {DOT}  on {bold(cur)}" if cur else ""))
    table(["", "branch", "commit", "message", "when"], rows)


def cmd_switch(args) -> None:
    repo = Repository.find()
    with journaled(repo, "switch") as j:
        name = repo.switch(args.target, create=args.create, force=args.force)
        j.done(f"switched to {name}")
    if args.create:
        ok(f"Created and switched to {bold(name)}")
        hint(f"switch back with `hit switch -`")
    elif name != args.target:
        ok(f"Now at {yellow(args.target)} on a new branch {bold(name)}")
        note("HIT made a branch here so none of your work can be lost")
    else:
        ok(f"Switched to {bold(name)}")
        cm = repo.head_commit()
        if cm:
            field("commit", f"{yellow(cm.short)}  {cm.summary[:50]}")


def cmd_checkout(args) -> None:
    repo = Repository.find()
    if args.paths:
        rev = args.target
        with journaled(repo, "checkout") as j:
            for p in args.paths:
                repo.checkout_file(repo.rel(p), rev)
            j.done(f"restored {', '.join(args.paths)}" + (f" from {rev}" if rev else ""))
        ok(f"restored {len(args.paths)} file(s)" + (f" from {rev}" if rev else " from the index"))
        return
    if getattr(args, "create", False) or getattr(args, "create_force", False):
        if not args.target:
            raise HitError("name the branch to create", "hit checkout -b <branch>")
        if getattr(args, "create_force", False) and repo.refs.branch_exists(args.target):
            repo.refs.delete_branch(args.target)
        args.create = True
        return cmd_switch(args)
    if not args.target:
        raise HitError("what do you want to check out?", "hit checkout <branch|commit>  or  hit checkout -- <file>")
    # if target is a tracked file, treat as file restore
    try:
        rel = repo.rel(args.target)
        if repo.index.get(rel):
            with journaled(repo, "checkout") as j:
                repo.checkout_file(rel)
                j.done(f"restored {rel}")
            ok(f"restored {rel}")
            return
    except HitError:
        pass
    args.create = False
    cmd_switch(args)


def cmd_merge(args) -> None:
    from .merge import abort_merge, continue_merge, merge
    repo = Repository.find()
    if args.abort:
        with journaled(repo, "merge --abort") as j:
            abort_merge(repo)
            j.done("aborted merge")
        ok("merge aborted, back to how things were")
        return
    if args.cont:
        with journaled(repo, "merge --continue") as j:
            sha = continue_merge(repo, args.message)
            j.done("finished merge")
        ok(f"merge committed as {sha[:7]}")
        return
    if not args.branch:
        raise HitError("which branch do you want to merge?", "hit merge <branch>")
    with journaled(repo, "merge") as j:
        res = merge(repo, args.branch, args.message, no_ff=getattr(args, "no_ff", False))
        j.done(f"merged {args.branch} ({res.kind})")
    if getattr(args, "ff_only", False) and res.kind == "merged":
        raise HitError("a merge commit was needed but --ff-only was given",
                       "run it again without --ff-only, or rebase your work")
    if res.kind == "up-to-date":
        ok("Already up to date")
        field("branch", args.branch)
    elif res.kind == "fast-forward":
        ok(f"Fast-forwarded to {yellow(res.sha[:7])}")
        field("branch", f"{args.branch} {ARROW} {repo.refs.current_branch()}")
        hint("undo this with `hit undo`")
    elif res.kind == "merged":
        ok(f"Merged {bold(args.branch)} into {bold(repo.refs.current_branch() or 'HEAD')}")
        field("commit", yellow(res.sha[:7]))
        hint("undo this with `hit undo`")
    else:
        warn(f"Merge paused - {len(res.conflicts)} {plural(len(res.conflicts), 'file')} with conflicts")
        file_list([("C", p) for p in res.conflicts], limit=50)
        blank()
        note("open each file and look for <<<<<<< and >>>>>>>, keep the lines you want, delete the markers")
        hint("then `hit add <file>` for each, and `hit merge --continue`   (or `hit merge --abort`)")


def cmd_tag(args) -> None:
    repo = Repository.find()
    if args.delete:
        if not repo.refs.delete(f"refs/tags/{args.delete}"):
            raise HitError(f"no tag named '{args.delete}'")
        ok(f"Deleted tag {bold(args.delete)}")
        return
    if not args.name or getattr(args, "list", False):
        tags = repo.refs.tags()
        if not tags:
            info("no tags yet")
            hint("create one with `hit tag v1.0`")
            return
        rows = []
        for name in sorted(tags):
            cm = repo.store.read_commit(tags[name])
            rows.append([bold(name), yellow(cm.short), cm.summary[:50], dim(relative_time(cm.commit_time))])
        o_rows = rows
        table(["tag", "commit", "message", "when"], o_rows)
        return
    if getattr(args, "annotate", False) and not args.message:
        args.message = _ask("  tag message: ", "")
    if getattr(args, "force", False) and repo.refs.exists(f"refs/tags/{args.name}"):
        repo.refs.delete(f"refs/tags/{args.name}")
    with journaled(repo, "tag") as j:
        repo.tag(args.name, args.rev or "HEAD", args.message)
        j.done(f"tagged {args.name}")
    sha = repo.resolve(args.rev or "HEAD")
    ok(f"Tagged {yellow(sha[:7])} as {bold(args.name)}")
    if args.message:
        field("message", args.message)


def cmd_reset(args) -> None:
    repo = Repository.find()
    rev = args.rev or "HEAD"
    mode = "hard" if args.hard else "soft" if args.soft else "mixed"
    if mode == "hard":
        st = repo.status()
        if (st.unstaged or st.staged) and not confirm(
                f"This throws away {len(st.unstaged) + len(st.staged)} uncommitted change(s). Continue?", force_ask=True):
            say("cancelled")
            return
    from . import snapshot
    backup = None
    if mode == "hard":
        backup = snapshot.create(repo, "before-reset", kind="backup", with_worktree=True)
    with journaled(repo, f"reset --{mode}") as j:
        sha = repo.reset(rev, mode)
        j.done(f"reset --{mode} to {sha[:7]}", worktree_snapshot=backup.stem if backup else None)
    cm = repo.store.read_commit(sha)
    ok(f"now at {cm.short} \"{cm.summary}\"   (undo with: hit undo)")
    if mode == "soft":
        say(dim("  your changes are still staged — commit them again when ready"))
    elif mode == "mixed":
        say(dim("  your changes are still in your files, just not staged"))


def cmd_stash(args) -> None:
    from . import stash
    repo = Repository.find()
    sub = args.sub or "push"
    if sub in ("push", "save"):
        with journaled(repo, "stash") as j:
            e = stash.push(repo, args.message, include_untracked=args.untracked)
            j.done("stashed changes")
        ok("Changes set aside")
        field("stash", e["message"])
        hint("bring them back with `hit stash pop`")
    elif sub in ("pop", "apply"):
        with journaled(repo, "stash pop") as j:
            e = stash.pop(repo, args.index or 0, keep=(sub == "apply"))
            j.done("restored stash")
        if e.get("conflicts"):
            warn(f"Restored with conflicts in {len(e['conflicts'])} {plural(len(e['conflicts']), 'file')}")
            file_list([("C", p) for p in e["conflicts"]], limit=20)
            hint("edit the files, then `hit add` them")
        else:
            ok("Changes restored")
            field("stash", e["message"])
    elif sub == "list":
        items = stash.list_stashes(repo)
        if not items:
            info("nothing is stashed")
            hint("set changes aside with `hit stash`")
            return
        ok(f"{len(items)} {plural(len(items), 'stash', 'stashes')}")
        table(["ref", "message", "branch", "when"],
              [[dim(f"stash@{{{i}}}"), e["message"][:50], e.get("branch") or "-",
                dim(relative_time(e["time"]))] for i, e in enumerate(items)])
        hint("restore the newest with `hit stash pop`")
    elif sub == "drop":
        e = stash.drop(repo, args.index or 0)
        ok("Stash dropped")
        field("stash", e["message"])
    else:
        raise HitError(f"unknown stash command '{sub}'", "use: hit stash | pop | apply | list | drop")


def cmd_ignore(args) -> None:
    repo = Repository.find()
    p = repo.root / ".hitignore"
    existing = p.read_text() if p.exists() else ""
    if not args.patterns:
        lines = [l for l in existing.splitlines() if l.strip() and not l.startswith("#")]
        if not lines:
            info(".hitignore has no rules yet")
            hint("add one with `hit ignore node_modules`")
            return
        ok(f"{len(lines)} ignore {plural(len(lines), 'rule')}")
        for l in lines[:60]:
            detail(l)
        return
    new = [l for l in args.patterns if l not in existing.splitlines()]
    with open(p, "a") as f:
        if existing and not existing.endswith("\n"):
            f.write("\n")
        for l in new:
            f.write(l + "\n")
    ok(f"Added {len(new)} {plural(len(new), 'rule')} to .hitignore")
    for l in new:
        detail(l)
    rules = repo.ignore()
    now_ignored = [rel for rel in repo.index.paths() if rules.is_ignored(rel, False)]
    if now_ignored and confirm(
            f"{len(now_ignored)} tracked {plural(len(now_ignored), 'file')} now match. Stop tracking them?",
            default=True):
        repo.rm([str(repo.root / r) for r in now_ignored], keep_file=True)
        ok(f"Stopped tracking {len(now_ignored)} {plural(len(now_ignored), 'file')}")
        note("the files stay on disk")


def cmd_snapshot(args) -> None:
    from . import snapshot
    repo = Repository.find()
    sub = args.sub
    if sub == "list" or (sub is None and args.name is None and args.list):
        items = snapshot.list_snapshots(repo) + (snapshot.list_snapshots(repo, "backup") if args.all else [])
        if not items:
            info("no snapshots yet")
            hint("save one with `hit snapshot before-refactor`")
            return
        ok(f"{len(items)} {plural(len(items), 'snapshot')}")
        table(["name", "when", "commits", "size", "branch", ""],
              [[bold(sn.name), dim(relative_time(sn.time)), str(sn.commits),
                human_size(sn.size), sn.branch or "-",
                dim("auto-backup" if sn.kind == "backup" else ("+files" if sn.with_worktree else ""))]
               for sn in items])
        hint("bring one back with `hit restore <name>`")
        return
    if sub == "delete":
        p = snapshot.delete(repo, args.name)
        ok(f"Deleted snapshot {bold(p.stem)}")
        return
    name = args.name
    if sub not in (None, "create", "save"):
        name = sub  # `hit snapshot before-refactor`
    p = snapshot.create(repo, name, with_worktree=args.files)
    ok(f"Snapshot {bold(p.stem)} saved")
    field("size", human_size(p.stat().st_size))
    field("commits", str(len(repo.log()) if repo.refs.head() else 0))
    field("file", short_path(str(p)))
    hint(f"restore it any time with `hit restore {p.stem}`")


def cmd_restore(args) -> None:
    from . import snapshot
    repo = Repository.find()
    names = [n for n in ([args.name] if args.name else []) + list(getattr(args, "paths", []) or []) if n]
    if not names:
        raise HitError("what should I restore?",
                       "a file: `hit restore app.py`   ·   a snapshot: `hit restore my-backup`")

    # `hit restore --staged <paths>` == unstage them (Git semantics)
    if getattr(args, "staged", False):
        repo.unstage(names)
        ok(f"Unstaged {len(names)} {plural(len(names), 'file')}")
        file_list([("M", repo.rel(n)) for n in names], limit=20)
        hint("your files on disk were not changed")
        return

    # Decide: are these tracked paths, or the name of a snapshot?
    def is_path(n: str) -> bool:
        try:
            rel = repo.rel(n)
        except HitError:
            return False
        return (repo.root / rel).exists() or repo.index.get(rel) is not None or rel in repo.head_files()

    wants_snapshot = getattr(args, "snapshot", False)
    if not wants_snapshot and all(is_path(n) for n in names):
        rev = getattr(args, "source", None)
        restored = []
        with journaled(repo, "restore") as j:
            for n in names:
                rel = repo.rel(n)
                head = repo.commit_files(repo.resolve(rev)) if rev else repo.head_files()
                targets = [rel] if rel in head or repo.index.get(rel) else \
                          [p for p in head if p.startswith(rel.rstrip("/") + "/")]
                if not targets:
                    raise HitError(f"'{rel}' is not tracked" + (f" in {rev}" if rev else ""),
                                   "check the path, or use `hit restore --snapshot <name>` for a snapshot")
                for t in targets:
                    repo.checkout_file(t, rev)
                    restored.append(t)
            j.done(f"restored {', '.join(restored[:5])}")
        ok(f"Restored {len(restored)} {plural(len(restored), 'file')}"
           + (f" from {yellow(rev)}" if rev else " from the last commit"))
        file_list([("M", p) for p in restored], limit=20)
        hint("undo this with `hit undo`")
        return

    # Otherwise: restore the whole repository from a snapshot
    name = names[0]
    target = snapshot.find(repo, name)
    say(f"Restore the whole repository from snapshot {bold(target.stem)}?")
    note("your current state is backed up first, and `hit undo` reverses this")
    if not confirm("Continue?", force_ask=True):
        say("cancelled")
        return
    backup = snapshot.create(repo, "before-restore", kind="backup", with_worktree=True)
    with journaled(repo, "restore") as j:
        meta = snapshot.restore(repo, name)
        j.done(f"restored snapshot {meta['name']}", worktree_snapshot=backup.stem)
    ok(f"Restored snapshot {bold(meta['name'])}")
    field("commits", str(meta.get("commits", "?")))
    field("branch", str(meta.get("branch")))
    hint("undo this with `hit undo`")


def cmd_undo(args) -> None:
    from .journal import Journal
    repo = Repository.find()
    j = Journal(repo)
    last = j.last()
    if not last:
        raise HitError("nothing to undo", "HIT has not recorded any action in this repository yet")
    n = args.n or 1
    if n == 1:
        say(f"Undo {bold(last.description)}?  {dim(relative_time(last.time))}")
        if not confirm("Continue?", default=True):
            say("cancelled")
            return
    done = j.undo(n)
    ok(f"Undid {len(done)} {plural(len(done), 'action')}")
    for e in done:
        detail(f"{dim(ARROW)} {e.description}")
    hint("put it back with `hit redo`")


def cmd_redo(args) -> None:
    from .journal import Journal
    repo = Repository.find()
    done = Journal(repo).redo(args.n or 1)
    if not done:
        raise HitError("nothing to redo", "`hit undo` something first")
    ok(f"Redid {len(done)} {plural(len(done), 'action')}")
    for e in done:
        detail(f"{dim(ARROW)} {e.description}")


def cmd_history(args) -> None:
    """`hit undo --list`: show the action journal."""
    from .journal import Journal
    repo = Repository.find()
    entries = Journal(repo).entries()
    if not entries:
        info("no actions recorded yet")
        return
    ok(f"{len(entries)} recorded {plural(len(entries), 'action')}" + dim("   (newest first)"))
    rows = []
    for e in reversed(entries[-30:]):
        rows.append([dim(str(e.id)), dim(relative_time(e.time)),
                     dim("undone") if e.undone else "", e.description[:70]])
    table(["#", "when", "", "action"], rows)
    hint("reverse the newest one with `hit undo`")


# ---- remote ---------------------------------------------------------------

def _progress(msg: bytes) -> None:
    try:
        text = msg.decode(errors="replace").strip().replace("\n", " ")
    except Exception:
        return
    if text and sys.stdout.isatty():
        print("\r" + dim("  " + text[:100].ljust(100)), end="", flush=True)


def _clear_progress() -> None:
    if sys.stdout.isatty():
        print("\r" + " " * 104 + "\r", end="")


def _ensure_remote(repo: Repository) -> None:
    from .remote import get_remote, set_remote
    if get_remote(repo):
        return
    if not sys.stdin.isatty():
        raise HitError("no remote configured", "hit remote add origin https://github.com/you/repo.git")
    say("This project isn't connected to GitHub yet.")
    say(dim("  Paste the repository URL from github.com (or just user/repo):"))
    url = _ask("  URL: ")
    if not url:
        raise HitError("no URL given")
    set_remote(repo, "origin", url)
    ok(f"connected to {get_remote(repo)}")


def _ensure_login(repo: Repository) -> None:
    from .remote import get_credential, get_remote, host_of
    url = get_remote(repo) or ""
    if not url.startswith("http"):
        return
    if get_credential(host_of(url)):
        return
    if not sys.stdin.isatty():
        raise HitError(f"no saved login for {host_of(url)}", "run `hit login`")
    say(f"You need to log in to {host_of(url)} once.")
    cmd_login(argparse.Namespace(host=host_of(url), username=None, token=None))


def _looks_like_url(s: str) -> bool:
    import re
    from .remote import is_local_path
    return bool(re.match(r"^(https?://|git@|ssh://)", s)) or is_local_path(s) or bool(re.match(r"^[\w.-]+/[\w.-]+$", s))


def _ask(prompt: str, default: str = "") -> str:
    if not sys.stdin.isatty():
        return default
    try:
        val = input(prompt).strip()
    except EOFError:
        print()
        return default
    except KeyboardInterrupt:
        print()
        raise HitError("cancelled")
    return val or default


def cmd_push(args) -> None:
    from .remote import get_remote, push, set_remote
    repo = Repository.find()
    remote = args.remote
    branch = args.branch

    # `hit push https://github.com/you/repo.git [branch]` — connect (or reconnect) and push
    if _looks_like_url(remote):
        set_remote(repo, "origin", remote)
        ok(f"connected to {get_remote(repo)}")
        remote = "origin"
    from .remote import list_remotes
    if remote in ("github", "gh", "remote", "cloud", "online"):
        remote = "origin"
    if remote != "origin" and remote not in list_remotes(repo):
        if repo.refs.branch_exists(remote) and not branch:
            branch, remote = remote, "origin"          # `hit push main`
        elif not branch:
            branch, remote = remote, "origin"          # `hit push newbranch` -> push current as that name
        else:
            raise HitError(f"no remote named '{remote}'", "hit remote add origin https://github.com/you/repo.git")

    first_time = not get_remote(repo)
    _ensure_remote(repo)
    _ensure_login(repo)

    current = repo.refs.current_branch()
    if not current:
        raise HitError("not on a branch", "run `hit switch main` first")

    # Push sends commits only. If there's uncommitted work, offer to commit it first.
    st = repo.status()
    pending = len(st.staged) + len(st.unstaged) + len(st.untracked)
    if not repo.refs.head():
        if not pending:
            raise HitError("nothing to push yet — this project has no files",
                           "add some files, then `hit save my work as first version`")
        say(yellow(f"Nothing has been committed yet.") + f" {pending} file(s) are waiting.")
        if not confirm("Commit them now and then push?", default=True):
            raise HitError("nothing to push yet", "make a commit first: hit commit -m \"first commit\"")
        msg = _ask("  Commit message [first commit]: ", "first commit")
        repo.add(["."])
        with journaled(repo, "commit") as j:
            cm = repo.commit(msg)
            j.done(f"commit {cm.short}: {cm.summary}")
        ok(f"committed {cm.short} \"{cm.summary}\"")
    elif pending and sys.stdin.isatty():
        say(yellow(f"{pending} file(s) changed since your last commit") + dim(" — push only sends commits."))
        if confirm("Commit them first?", default=True):
            msg = _ask("  Commit message [update]: ", "update")
            repo.add(["."])
            with journaled(repo, "commit") as j:
                cm = repo.commit(msg)
                j.done(f"commit {cm.short}: {cm.summary}")
            ok(f"committed {cm.short} \"{cm.summary}\"")

    if not branch and first_time:
        branches = sorted(repo.refs.branches())
        say(dim("  your branches: " + ", ".join(branches)))
        branch = _ask(f"  Push which branch? [{current}]: ", current)
    branch = branch or current
    if branch != current and not repo.refs.branch_exists(branch):
        if confirm(f"You have no branch '{branch}'. Push your current branch '{current}' as '{branch}' on GitHub?", default=True):
            _push_as(repo, remote, current, branch, args.force)
            return
        raise HitError(f"no branch named '{branch}'")

    say(dim(f"pushing {branch} → {remote}..."))
    try:
        res = push(repo, remote, branch, force=args.force, progress=_progress)
    except HitError as e:
        _clear_progress()
        if "commits you don't have" in str(e) and sys.stdin.isatty():
            say(yellow("GitHub already has commits on this branch that you don't have locally") +
                dim(" (e.g. a README created on github.com)."))
            choice = _ask("  [m] merge them into mine and push   [f] force-overwrite GitHub   [c] cancel  : ", "c").lower()
            if choice.startswith("m"):
                cmd_pull(argparse.Namespace(remote=remote))
                res = push(repo, remote, branch, force=False, progress=_progress)
            elif choice.startswith("f"):
                res = push(repo, remote, branch, force=True, progress=_progress)
            else:
                raise HitError("cancelled")
        else:
            raise
    _clear_progress()
    _report_push(res)


def _push_as(repo: Repository, remote: str, local: str, remote_branch: str, force: bool) -> None:
    """Push local branch under a different name on the remote (e.g. master -> main)."""
    from .remote import push
    sha = repo.refs.read(f"refs/heads/{local}")
    repo.refs.create_branch(remote_branch, sha)
    try:
        res = push(repo, remote, remote_branch, force=force, progress=_progress)
    finally:
        _clear_progress()
    _report_push(res)
    say(dim(f"  (also created local branch '{remote_branch}' at the same commit; `hit switch {remote_branch}` to use it)"))


def _report_push(res) -> None:
    from .remote import get_remote
    if res.status == "up-to-date":
        ok("Already up to date on GitHub")
        field("branch", res.branch)
    elif res.status == "rejected":
        raise HitError(f"push rejected: {res.reason}")
    else:
        from .remote import web_url
        ok(f"Push successful - {bold(res.branch)} is on GitHub")
        field("range", f"{res.old[:7]}..{res.new[:7]}" if res.old else f"new branch at {res.new[:7]}")
        field("remote", f"{res.remote}/{res.branch}")
        try:
            web = web_url(get_remote(Repository.find(), res.remote) or "")
            if web:
                field("view", web)
        except HitError:
            pass


def cmd_fetch(args) -> None:
    from .remote import fetch
    repo = Repository.find()
    args.remote = _remote_alias(args.remote)
    _ensure_remote(repo)
    _ensure_login(repo)
    res = fetch(repo, args.remote, progress=_progress)
    _clear_progress()
    if not res.updated:
        say(dim("nothing new on the remote"))
    for b, (old, new) in res.updated.items():
        ok(f"{args.remote}/{b}: {old[:7] if old else 'new'} → {new[:7]}")


def _remote_alias(name: str) -> str:
    return "origin" if name in ("github", "gh", "git", "remote", "cloud", "online") else name


def cmd_pull(args) -> None:
    from .merge import merge
    from .remote import fetch
    repo = Repository.find()
    args.remote = _remote_alias(args.remote)
    _ensure_remote(repo)
    _ensure_login(repo)
    branch = repo.refs.current_branch()
    if not branch:
        raise HitError("not on a branch")
    res = fetch(repo, args.remote, progress=_progress)
    _clear_progress()
    before_sha = repo.refs.head()
    remote_ref = f"refs/remotes/{args.remote}/{branch}"
    sha = repo.refs.read(remote_ref)
    if not sha:
        raise HitError(f"the remote has no branch called '{branch}'", "push it first with `hit push`")
    with journaled(repo, "pull") as j:
        r = merge(repo, f"{args.remote}/{branch}", f"Merge {args.remote}/{branch} into {branch}")
        j.done(f"pulled {args.remote}/{branch} ({r.kind})")
    if r.kind == "up-to-date":
        ok("Already up to date - nothing new on GitHub")
    elif r.kind in ("fast-forward", "merged"):
        from .diff import tree_changes
        before_files = repo.commit_files(before_sha) if before_sha else {}
        changes = tree_changes(before_files, repo.commit_files(r.sha))
        counts: dict[str, int] = {}
        for ch in changes:
            counts[ch.status] = counts.get(ch.status, 0) + 1
        ok(f"Pull successful - {'updated to' if r.kind == 'fast-forward' else 'merged into'} {yellow(r.sha[:7])}")
        field("received", f"{len(changes)} {plural(len(changes), 'file')}"
                          + (f"  {DOT}  " + summary_counts(counts) if counts else ""))
        blank()
        file_list([(ch.status, ch.path) for ch in changes], limit=25)
        hint("see everything with `hit files`   ·   browse with `hit ui`")
    else:
        warn(f"Pull paused - {len(r.conflicts)} {plural(len(r.conflicts), 'file')} with conflicts")
        file_list([("C", p) for p in r.conflicts], limit=25)
        hint("fix them, `hit add` each file, then `hit merge --continue`")


def cmd_clone(args) -> None:
    from .remote import clone
    say(dim(f"cloning {args.url}..."))
    repo = clone(args.url, Path(args.dir) if args.dir else None, progress=_progress)
    _clear_progress()
    files = repo.head_files() if repo.refs.head() else {}
    n = len(repo.log()) if repo.refs.head() else 0
    ok(f"Cloned into {bold(repo.root.name)}")
    field("commits", str(n))
    field("files", str(len(files)))
    field("folder", short_path(str(repo.root)))
    blank()
    file_list([("A", rel) for rel in sorted(files)], limit=20)
    hint(f"open it with `cd {repo.root.name}` then `hit ui`")


def cmd_remote(args) -> None:
    from .remote import (get_remote, list_remotes, remove_remote, set_remote,
                         sync_state, web_url)
    repo = Repository.find()
    sub = args.sub
    rest = list(args.args or [])

    if sub in (None, "list", "-v", "--verbose", "show", "-vv"):
        remotes = list_remotes(repo)
        if sub == "show" and rest:
            name = rest[0]
            url = get_remote(repo, name)
            if not url:
                raise HitError(f"no remote named '{name}'")
            ok(f"Remote {bold(name)}")
            field("url", url)
            web = web_url(url)
            if web:
                field("web", web)
            sy = sync_state(repo, name)
            field("branch", f"{sy.branch or '-'}  {DOT}  {sy.label}")
            return
        if not remotes:
            info("no remotes configured")
            hint("connect one with `hit remote add origin https://github.com/you/repo.git`")
            return
        ok(f"{len(remotes)} {plural(len(remotes), 'remote')}")
        table(["name", "url"], [[bold(n), u] for n, u in remotes.items()])
        return

    if sub in ("add", "set", "set-url"):
        if not rest:
            raise HitError("usage: hit remote add <name> <url>", "or just: hit remote add <url>")
        name, url = ("origin", rest[0]) if len(rest) == 1 else (rest[0], rest[1])
        set_remote(repo, name, url)
        ok(f"Remote {bold(name)} {'updated' if sub == 'set-url' else 'connected'}")
        field("url", get_remote(repo, name) or url)
        hint("upload your commits with `hit push`")
        return

    if sub in ("get-url", "geturl"):
        name = rest[0] if rest else "origin"
        url = get_remote(repo, name)
        if not url:
            raise HitError(f"no remote named '{name}'")
        say(url)
        return

    if sub in ("rename", "mv"):
        if len(rest) < 2:
            raise HitError("usage: hit remote rename <old> <new>")
        old, new = rest[0], rest[1]
        url = get_remote(repo, old)
        if not url:
            raise HitError(f"no remote named '{old}'")
        set_remote(repo, new, url)
        remove_remote(repo, old)
        ok(f"Renamed remote {bold(old)} {ARROW} {bold(new)}")
        return

    if sub in ("remove", "rm", "delete"):
        name = rest[0] if rest else "origin"
        if not remove_remote(repo, name):
            raise HitError(f"no remote named '{name}'")
        ok(f"Removed remote {bold(name)}")
        return

    raise HitError(f"unknown remote command '{sub}'",
                   "use: hit remote [-v] | add | set-url | get-url | rename | remove | show")


def cmd_login(args) -> None:
    from .remote import save_credential
    host = args.host or "github.com"
    say(f"Log in to {bold(host)}")
    say(dim("  HIT needs a Personal Access Token (not your password)."))
    say(dim("  GitHub → Settings → Developer settings → Personal access tokens → Generate new token"))
    say(dim("  Scope needed: repo.  The token is stored only on this computer."))
    username = args.username
    token = args.token
    try:
        if not username:
            username = input("  GitHub username: ").strip()
        if not token:
            token = getpass.getpass("  Token (hidden): ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        raise HitError("cancelled")
    if not username or not token:
        raise HitError("username and token are both required")
    save_credential(host, username, token)
    ok(f"Signed in to {bold(host)}")
    field("user", username)
    note("the token is stored on this computer only, and sent only to " + host)


def cmd_logout(args) -> None:
    from .remote import delete_credential
    host = args.host or "github.com"
    if delete_credential(host):
        ok(f"Signed out of {bold(host)}")
    else:
        info(f"no saved login for {host}")


# ---- projects / misc --------------------------------------------------------

def cmd_projects(args) -> None:
    from . import registry
    sub = args.sub
    if sub == "add":
        p = Path(args.args[0] if args.args else ".").resolve()
        if not (p / ".hit").is_dir():
            raise HitError(f"{p} is not a HIT repository")
        ok("added" if registry.add_path(p) else "already listed")
        return
    if sub in ("remove", "rm"):
        p = Path(args.args[0] if args.args else ".").resolve()
        ok("removed from list" if registry.remove_path(p) else "wasn't listed")
        return
    if sub == "clean":
        gone = registry.clean()
        ok(f"removed {len(gone)} missing project(s)")
        return
    full = getattr(args, "stats", False) and not args.fast
    items = registry.projects(with_stats=full)
    if not items:
        info("no projects yet")
        hint("start one with `hit init`, or find your existing ones with `hit scan`")
        return

    ok(f"{len(items)} {plural(len(items), 'project')}" + dim("   (most recent first)"))
    rows = []
    for p in items:
        if not p.exists:
            rows.append([red("!"), red(p.name), dim("(folder missing)"), "", dim(short_path(p.path))])
            continue
        mark = (yellow("*") if p.dirty else green("*")) if full else dim("-")
        name = bold(p.name) + (dim("  [git]") if p.kind == "git" else "")
        when = relative_time(p.recency) + (dim(" used") if p.last_used > p.last_time else "")
        row = [mark, name, dim(p.last_message[:38]), when]
        if full:
            row += [f"{p.commits} {plural(p.commits, 'commit')}", human_size(p.size)]
        row.append(dim(short_path(p.path)))
        rows.append(row)
    headers = ["", "project", "last commit", "activity"] + (["commits", "size"] if full else []) + ["path"]
    table(headers, rows)
    blank()
    if full:
        note(f"{green('*')} clean   {yellow('*')} uncommitted changes   [git] = a plain Git project")
    else:
        hint("add `--stats` for commit counts, sizes and GitHub status")
    hint("find more with `hit scan`   ·   browse them with `hit ui`")


def cmd_scan(args) -> None:
    """Find every Git/HIT project on this computer and add it to the list."""
    from . import registry
    roots = [Path(r) for r in args.paths] if args.paths else None
    where = ", ".join(str(r) for r in (roots or registry.default_scan_roots()))
    say(f"Searching for Git and HIT projects in: {dim(where)}")
    say(dim("  (this can take a minute on big drives — Ctrl+C to stop; results so far are kept)"))
    last = [0.0]

    def progress(p: Path):
        now = time.time()
        if sys.stdout.isatty() and now - last[0] > 0.2:
            last[0] = now
            print("\r" + dim("  " + str(p)[:90].ljust(92)), end="", flush=True)

    try:
        found = registry.scan(roots, max_depth=args.depth, progress=progress)
    except KeyboardInterrupt:
        found = []
        print()
    _clear_progress()
    if not found:
        info("no Git or HIT projects found here")
        hint("try a specific folder, e.g. `hit scan D:\\Projects`")
        return
    rows, added = [], 0
    for p in found:
        kind = "hit" if (p / ".hit" / "HEAD").is_file() else "git"
        new = registry.add_path(p)
        added += new
        rows.append([green("+") if new else dim(DOT), bold(p.name), dim(f"[{kind}]"), dim(short_path(str(p)))])
    ok(f"Found {len(found)} {plural(len(found), 'project')}" + (f", {added} new" if added else ", none new"))
    table(["", "project", "kind", "path"], rows)
    hint("browse them all with `hit ui`")



# ---- Git commands implemented in hit/gitcmds.py ---------------------------

def cmd_show(args) -> None:
    from . import gitcmds
    repo = Repository.find()
    gitcmds.show(repo, args.rev or "HEAD", stat_only=args.stat, name_only=args.name_only)


def cmd_ls_files(args) -> None:
    from . import gitcmds
    gitcmds.ls_files(Repository.find(), show_status=args.stage)


def cmd_ls_tree(args) -> None:
    from . import gitcmds
    gitcmds.ls_tree(Repository.find(), args.rev or "HEAD")


def cmd_rev_parse(args) -> None:
    from . import gitcmds
    gitcmds.rev_parse(Repository.find(), args.revs)


def cmd_describe(args) -> None:
    from . import gitcmds
    gitcmds.describe(Repository.find(), args.rev or "HEAD")


def cmd_shortlog(args) -> None:
    from . import gitcmds
    gitcmds.shortlog(Repository.find())


def cmd_count_objects(args) -> None:
    from . import gitcmds
    gitcmds.count_objects(Repository.find())


def cmd_blame(args) -> None:
    from . import gitcmds
    gitcmds.blame(Repository.find(), args.path)


def cmd_revert(args) -> None:
    from . import gitcmds
    repo = Repository.find()
    sha = repo.resolve(args.rev)
    cm = repo.store.read_commit(sha)
    if not confirm(f"Undo the changes of {cm.short} \"{cm.summary[:50]}\" with a new commit?", default=True):
        say("cancelled")
        return
    with journaled(repo, "revert") as j:
        new = gitcmds.revert(repo, args.rev, args.message)
        j.done(f"reverted {cm.short}")
    ok(f"Reverted {yellow(cm.short)} in a new commit {yellow(new.short)}")
    field("message", new.summary)
    hint("undo this with `hit undo`")


def cmd_cherry_pick(args) -> None:
    from . import gitcmds
    repo = Repository.find()
    sha = repo.resolve(args.rev)
    cm = repo.store.read_commit(sha)
    with journaled(repo, "cherry-pick") as j:
        new = gitcmds.cherry_pick(repo, args.rev, args.message)
        j.done(f"cherry-picked {cm.short}")
    ok(f"Applied {yellow(cm.short)} here as {yellow(new.short)}")
    field("message", new.summary)
    hint("undo this with `hit undo`")


def cmd_mv(args) -> None:
    from . import gitcmds
    repo = Repository.find()
    with journaled(repo, "mv") as j:
        moved = gitcmds.move(repo, args.paths[:-1], args.paths[-1])
        j.done("moved " + ", ".join(f"{a} -> {b}" for a, b in moved))
    ok(f"Moved {len(moved)} {plural(len(moved), 'file')}")
    for src, dst in moved[:15]:
        detail(f"{status_glyph('R')}  {src} {ARROW} {dst}")
    hint("commit the move with `hit commit -m \"move files\"`")


def cmd_clean(args) -> None:
    from . import gitcmds
    repo = Repository.find()
    targets = gitcmds.clean(repo, dry_run=True)
    if not targets:
        ok("Nothing to clean — no untracked files")
        return
    if args.dry_run or not args.force:
        ok(f"{len(targets)} untracked {plural(len(targets), 'file')} would be deleted")
        file_list([("D", p) for p in targets], limit=40)
        hint("delete them for real with `hit clean -f`")
        return
    if not confirm(f"Permanently delete {len(targets)} untracked file(s)?", force_ask=True):
        say("cancelled")
        return
    gitcmds.clean(repo, dry_run=False)
    ok(f"Deleted {len(targets)} untracked {plural(len(targets), 'file')}")
    file_list([("D", p) for p in targets], limit=40)


def cmd_gc(args) -> None:
    from . import gitcmds
    repo = Repository.find()
    before, after = gitcmds.gc(repo)
    ok("Repository packed")
    field("objects", f"{before} {ARROW} {after} loose")
    field("size", human_size(sum(f.stat().st_size for f in (repo.hit_dir / "objects").rglob("*") if f.is_file())))


def cmd_fsck(args) -> None:
    from . import gitcmds
    repo = Repository.find()
    fixed = gitcmds.repair_line_endings(repo)
    checked, problems = gitcmds.fsck(repo)
    if fixed:
        info(f"repaired {fixed} ref {plural(fixed, 'file')} saved with Windows line endings by an older HIT")
    if not problems:
        ok(f"Repository is healthy — {checked} {plural(checked, 'object')} verified")
        return
    fail(f"{len(problems)} {plural(len(problems), 'problem')} found in {checked} objects")
    for p in problems[:20]:
        detail(red(p))
    hint("restore a snapshot with `hit snapshot list` then `hit restore <name>`")


def cmd_config(args) -> None:
    from .repo import Config
    want_list = getattr(args, "list", False)

    if want_list or not args.key:
        shown = 0
        g = global_config_path()
        if g.exists():
            section("Global settings")
            note(str(g))
            for line in g.read_text().splitlines():
                if line.strip():
                    say("  " + line)
                    shown += 1
        try:
            repo = Repository.find()
            cfg_path = repo.hit_dir / "config"
            if cfg_path.exists():
                section("This repository")
                note(str(cfg_path))
                for line in cfg_path.read_text().splitlines():
                    if line.strip():
                        say("  " + line)
                        shown += 1
        except NotARepo:
            pass
        if not shown:
            info("nothing configured yet")
            hint('set your name with `hit config user.name "Your Name"`')
        return

    sect, _, key = args.key.partition(".")
    if not key:
        raise HitError("config keys look like section.key", 'for example: hit config user.name "Your Name"')

    if getattr(args, "unset", False):
        import configparser
        target = (Repository.find().hit_dir / "config") if args.local else global_config_path()
        cp = configparser.ConfigParser()
        cp.read(str(target))
        if cp.has_section(sect) and cp.has_option(sect, key):
            cp.remove_option(sect, key)
            with open(target, "w", newline="\n") as f:
                cp.write(f)
            ok(f"Removed {bold(args.key)}")
        else:
            info(f"{args.key} was not set")
        return

    if args.value is None:
        try:
            cfg = Repository.find().config
        except NotARepo:
            cfg = Config([global_config_path()])
        val = cfg.get(sect, key)
        if val is None:
            info(f"{args.key} is not set")
            return
        say(val)
        return

    if args.local:
        repo = Repository.find()
        repo.config.set(sect, key, args.value, repo.hit_dir / "config")
        where = "this repository"
    else:
        Config([global_config_path()]).set(sect, key, args.value)
        where = "all your repositories"
    ok(f"Set {bold(args.key)}")
    field("value", args.value)
    field("applies to", where)


def cmd_explain(args) -> None:
    from .explain import explain
    say(explain(args.words or ["hit"]))


def cmd_why(args) -> None:
    from .explain import why
    f = last_error_file()
    say(why(f.read_text() if f.exists() else None))


def _frozen_exe() -> Path | None:
    """Path of hit.exe when running as a PyInstaller bundle, else None."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve()
    return None


def _install_dir() -> Path:
    if os.name == "nt":
        return Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local")) / "HIT" / "bin"
    return Path.home() / ".local" / "bin"


def _on_path(folder: Path) -> bool:
    parts = [Path(p.strip('"')).resolve() for p in os.environ.get("PATH", "").split(os.pathsep) if p.strip()]
    try:
        return folder.resolve() in parts
    except OSError:
        return False


def _add_to_user_path_windows(folder: Path) -> bool:
    """Append folder to the *user* PATH in the registry (persistent, no admin needed)."""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment", 0, winreg.KEY_READ | winreg.KEY_WRITE) as k:
            try:
                cur, kind = winreg.QueryValueEx(k, "Path")
            except FileNotFoundError:
                cur, kind = "", winreg.REG_EXPAND_SZ
            entries = [e for e in cur.split(";") if e]
            if any(Path(e).resolve() == folder.resolve() for e in entries if e and Path(e).exists()):
                return True
            entries.append(str(folder))
            winreg.SetValueEx(k, "Path", 0, kind, ";".join(entries))
        # tell running Explorer/shells that the environment changed
        try:
            import ctypes
            ctypes.windll.user32.SendMessageTimeoutW(0xFFFF, 0x001A, 0, "Environment", 0x0002, 5000, None)
        except Exception:
            pass
        return True
    except OSError:
        return False


def cmd_setup(args) -> None:
    """Install HIT so the `hit` command works from any folder (for the standalone exe)."""
    import shutil
    src = _frozen_exe()
    dest_dir = _install_dir()
    if src is None:
        # pip install: the `hit` script is already on PATH via Python's Scripts dir
        scripts = Path(sys.executable).parent / ("Scripts" if os.name == "nt" else "")
        ok("HIT is installed through Python — nothing to set up.")
        if not _on_path(scripts):
            warn(f"but Python's script folder isn't on your PATH: {scripts}")
            say(dim("  add it to PATH, or run:  python -m hit <command>"))
        return
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / ("hit.exe" if os.name == "nt" else "hit")
    if src != dest:
        try:
            shutil.copy2(src, dest)
            ok(f"copied hit.exe to {dest_dir}")
        except OSError as e:
            raise HitError(f"could not copy to {dest_dir}: {e}")
    else:
        ok(f"hit.exe is already in {dest_dir}")
    if os.name == "nt":
        if _on_path(dest_dir):
            ok("that folder is already on your PATH")
        elif _add_to_user_path_windows(dest_dir):
            ok("added it to your PATH")
            say("")
            say(bold("  Close this terminal and open a new one — then `hit` works from anywhere."))
        else:
            warn("could not change PATH automatically")
            say(f"  add this folder to PATH manually: {dest_dir}")
    else:
        if not _on_path(dest_dir):
            say(f"  add to your shell profile:  export PATH=\"$HOME/.local/bin:$PATH\"")
        else:
            ok("that folder is already on your PATH")


def _launched_by_double_click() -> bool:
    """True when hit.exe was opened from Explorer (it owns its console window),
    rather than typed into an existing terminal."""
    if os.environ.get("HIT_SIMULATE_DOUBLE_CLICK"):   # used by tests
        return True
    if os.name != "nt" or not getattr(sys, "frozen", False):
        return False
    try:
        import ctypes
        pids = (ctypes.c_uint * 4)()
        # A one-file exe runs as 2 processes (launcher + Python) sharing the console.
        # Opened from Explorer, those are the only ones; in a terminal the shell adds more.
        return ctypes.windll.kernel32.GetConsoleProcessList(pids, 4) <= 2
    except Exception:
        return False


def _user_path_has(folder: Path) -> bool:
    """Is `folder` on the *saved* user PATH (not just this process's copy)?"""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as k:
            cur, _ = winreg.QueryValueEx(k, "Path")
        return any(e and Path(e).resolve() == folder.resolve() for e in cur.split(";") if e)
    except OSError:
        return False


def _double_click_install() -> int:
    """What happens when someone double-clicks the downloaded hit.exe."""
    def wait():
        try:
            input(dim("\nPress Enter to close this window..."))
        except (EOFError, KeyboardInterrupt):
            pass

    from .logo import print_banner
    print_banner()
    try:
        this = _frozen_exe()
        target = _install_dir() / "hit.exe"
        installed = target.exists() and _user_path_has(target.parent)
        if installed and this and this.resolve() == target.resolve():
            ok("HIT is installed")
        else:
            say("HIT is a command-line tool: you use it by typing `hit` in a terminal.")
            say("To make that work, this will:")
            detail(f"copy hit.exe to {target.parent}")
            detail("add that folder to your PATH (for your Windows user only, no admin needed)")
            blank()
            try:
                ans = input("Install HIT now? [Y/n] ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                ans = "n"
            if ans not in ("", "y", "yes"):
                say("Nothing was changed.")
                wait()
                return 0
            blank()
            cmd_setup(None)
            ok("HIT is installed")
        blank()
        say(bold("How to start"))
        detail("1. Open a NEW terminal: press Win+R, type  powershell  and press Enter")
        detail("2. Check it works:           hit version")
        detail("3. Go to your project:       cd C:\\path\\to\\your\\project")
        detail("4. Start tracking it:        hit init")
        detail("5. Save your first version:  hit save everything as first version")
        blank()
        note("Docs: https://hitvcs.vercel.app/documents.html")
        note("You can delete the downloaded hit.exe now; the installed copy is used from here on.")
    except HitError as e:
        fail(str(e))
        if e.hint:
            hint(e.hint)
    except Exception as e:  # noqa: BLE001 - never let the window vanish on an error
        fail(f"setup failed: {e}")
    wait()
    return 0


def cmd_update(args) -> None:
    from . import updater
    say(dim("checking for a new version..."))
    try:
        rel = updater.fetch_latest(timeout=10)
    except Exception as e:  # noqa: BLE001
        raise HitError("could not reach the HIT update server",
                       f"check your internet connection ({e.__class__.__name__})")

    if not updater.is_newer(rel.version):
        ok(f"HIT is up to date")
        field("version", __version__)
        return

    ok(f"HIT {bold(rel.version)} is available" + dim(f"   (you have {__version__})"))
    if rel.published:
        field("released", rel.published)
    if rel.notes:
        blank()
        say("  What's new")
        for n in rel.notes[:12]:
            detail(f"{DOT} {n}")
    if getattr(args, "check", False):
        blank()
        hint("install it with `hit update`")
        return

    exe = updater.running_exe()
    if exe is None:
        blank()
        note("you are running HIT from Python source, not hit.exe")
        hint("download the new hit.exe from https://hitvcs.vercel.app")
        return

    blank()
    if not confirm(f"Update to {rel.version} now?", default=True):
        say("cancelled")
        return

    last = [0.0]

    def progress(got: int, total: int) -> None:
        now = time.time()
        if sys.stdout.isatty() and (now - last[0] > 0.1 or got == total):
            last[0] = now
            pct = f"{got * 100 // total:3d}%" if total else ""
            print(f"\r  downloading  {human_size(got)} / {human_size(total)}  {pct}   ", end="", flush=True)

    try:
        data = updater.download(rel, progress=progress)
    except Exception as e:  # noqa: BLE001
        print()
        raise HitError(f"download failed: {e}", "try again, or download hit.exe from https://hitvcs.vercel.app")
    print("\r" + " " * 70 + "\r", end="")
    try:
        updater.replace_exe(exe, data)
    except OSError as e:
        raise HitError(f"could not replace {exe.name}: {e}",
                       "close any other window that is running hit, then try again")
    ok(f"Updated HIT {__version__} {ARROW} {bold(rel.version)}")
    field("checksum", "verified")
    field("installed", short_path(str(exe)))
    hint("the new version is used the next time you run `hit`")


def cmd_version(args) -> None:
    from .logo import banner_lines
    for line in banner_lines():
        say(line)
    exe = _frozen_exe()
    if exe and not _on_path(exe.parent):
        blank()
        warn("hit.exe is not on your PATH, so `hit` only works inside this folder")
        hint("fix it once with `.\\hit.exe setup`")


def cmd_ui(args) -> None:
    from .ui.app import run_ui
    run_ui(args.path)


def cmd_export_git(args) -> None:
    """Make a .git folder so Git tools can open this repo (they share objects)."""
    import shutil
    repo = Repository.find()
    dst = repo.root / ".git"
    if dst.exists():
        raise HitError(".git already exists here")
    if not confirm("Copy .hit → .git so Git/VS Code can read this repo? (HIT keeps using .hit)", default=True):
        return
    shutil.copytree(repo.hit_dir, dst, ignore=shutil.ignore_patterns("hit"))
    ok("created .git — Git tools can now read this repo (they won't see HIT-only data)")


# --------------------------------------------------------------------------
# `hit help me` — interactive menu
# --------------------------------------------------------------------------

def cmd_help_me(args) -> None:
    from .explain import EXPLAIN
    menu = [
        ("Start tracking this folder", ["init"]),
        ("See what I changed", ["status"]),
        ("Save my work (commit)", None),
        ("See my history", ["log", "--oneline"]),
        ("See files in the last commit", ["files"]),
        ("Undo my last action", ["undo"]),
        ("Work on a new idea (branch)", "branch"),
        ("Switch to another branch", "switch"),
        ("Merge a branch into this one", "merge"),
        ("Put my changes aside for a moment", ["stash"]),
        ("Back up the whole project", ["snapshot"]),
        ("Send my code to GitHub", ["push"]),
        ("Get updates from GitHub", ["pull"]),
        ("Open the dashboard", ["ui"]),
        ("Explain a command", "explain"),
    ]
    say(bold("What do you want to do?"))
    for i, (label, _) in enumerate(menu, 1):
        say(f"  {i:2}. {label}")
    say(dim("  (or just type it in English, e.g. `hit save my work as first version`)"))
    try:
        choice = input("> ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return
    if not choice:
        return
    if not choice.isdigit():
        return run_english(choice.split())
    idx = int(choice) - 1
    if not 0 <= idx < len(menu):
        return
    label, action = menu[idx]
    if action is None:
        msg = input("Describe what you changed: ").strip() or "update"
        return dispatch(["add", "."]) or dispatch(["commit", "-m", msg])
    if action == "branch":
        name = input("Name for the new branch: ").strip()
        return dispatch(["switch", "-c", name]) if name else None
    if action == "switch":
        dispatch(["branch"])
        name = input("Which branch? ").strip()
        return dispatch(["switch", name]) if name else None
    if action == "merge":
        dispatch(["branch"])
        name = input("Merge which branch into the current one? ").strip()
        return dispatch(["merge", name]) if name else None
    if action == "explain":
        w = input("Which command? ").strip()
        return dispatch(["explain", *w.split()]) if w else None
    say(dim(f"→ hit {' '.join(action)}"))
    dispatch(list(action))


# --------------------------------------------------------------------------
# Parser
# --------------------------------------------------------------------------

class ArgError(Exception):
    pass


class Parser(argparse.ArgumentParser):
    def error(self, message):
        raise ArgError(message)


def build_parser() -> argparse.ArgumentParser:
    p = Parser(prog="hit", description="HIT - Version Control System — version control that speaks English.",
                                epilog="Tip: you can also type what you want, e.g.  hit save my work as first version\n"
                                       "An NLR Product · Made with 💖 For Developers",
                                add_help=True)
    p.add_argument("--yes", "-y", action="store_true", help="don't ask for confirmation (destructive commands still ask)")
    p.add_argument("--version", action="store_true", help="show version")
    sp = p.add_subparsers(dest="cmd", metavar="<command>")

    def add(name, fn, help, aliases=()):
        s = sp.add_parser(name, help=help, aliases=list(aliases))
        s.error = lambda message: (_ for _ in ()).throw(ArgError(message))
        s.set_defaults(fn=fn)
        return s

    s = add("init", cmd_init, "start a repository here (creates .hitignore + README, offers a LICENSE)")
    s.add_argument("path", nargs="?")
    s.add_argument("--template", "-t", help="extra .hitignore rules: python|node|java|web|flutter|go|rust|unity|general")
    s.add_argument("--license", "-l", help="add a LICENSE: mit | apache-2.0 | gpl-3.0")
    s.add_argument("--no-readme", action="store_true", help="don't create README.md")
    s.add_argument("--no-license", action="store_true", help="don't ask about a license")

    add("uninit", cmd_uninit, "remove HIT tracking from this folder (files stay)", aliases=["deinit"])

    s = add("import", cmd_import, "adopt an existing Git (.git) project into HIT", aliases=["adopt"])
    s.add_argument("path", nargs="?")
    s.add_argument("--keep-git", action="store_true", help="don't offer to delete .git")

    s = add("add", cmd_add, "stage files for the next commit", aliases=["stage"])
    s.add_argument("paths", nargs="*")
    s.add_argument("-f", "--force", action="store_true", help="add even if ignored")
    s.add_argument("-v", "--verbose", action="store_true", help="list every file")
    s.add_argument("-A", "--all", action="store_true", help="stage everything (same as `hit add .`)")
    s.add_argument("-u", "--update", action="store_true", help="stage only files already tracked")

    s = add("unstage", cmd_unstage, "remove files from the staging area")
    s.add_argument("paths", nargs="*")

    s = add("status", cmd_status, "show what changed", aliases=["st"])
    s.add_argument("-s", "--short", action="store_true", help="one line per file, like git status -s")
    s.add_argument("-b", "--branch", action="store_true", help=argparse.SUPPRESS)

    s = add("diff", cmd_diff, "show line-by-line changes")
    s.add_argument("revs", nargs="*", help="compare commits: hit diff a1b2 c3d4")
    s.add_argument("--staged", "--cached", action="store_true", help="what will go into the next commit")
    s.add_argument("--stat", action="store_true", help="summary instead of full text")
    s.add_argument("--name-only", action="store_true", help="only print file names")
    s.add_argument("--", dest="paths", nargs="*", default=[], help=argparse.SUPPRESS)

    s = add("commit", cmd_commit, "save a checkpoint", aliases=["save", "ci"])
    s.add_argument("-m", "--message")
    s.add_argument("-a", "--all", action="store_true", help="stage all tracked files first")
    s.add_argument("--amend", action="store_true", help="change the last commit instead")
    s.add_argument("--allow-empty", action="store_true")

    s = add("log", cmd_log, "show commit history", aliases=["history", "whatchanged"])
    s.add_argument("rev", nargs="?")
    s.add_argument("-n", type=int, help="show only N commits")
    s.add_argument("--oneline", action="store_true")
    s.add_argument("--graph", action="store_true")
    s.add_argument("--stat", action="store_true")
    s.add_argument("--all", action="store_true", help="all branches")
    s.add_argument("--", dest="path", nargs="?", help=argparse.SUPPRESS)

    s = add("files", cmd_files, "list every file in a commit", aliases=["ls"])
    s.add_argument("rev", nargs="?", help="commit (default HEAD)")
    s.add_argument("--tree", "-t", action="store_true", help="show as folder tree")
    s.add_argument("--changed", "-c", action="store_true", help="only files this commit changed")

    s = add("rm", cmd_rm, "stop tracking files from the next commit", aliases=["remove", "untrack"])
    s.add_argument("paths", nargs="+")
    s.add_argument("--keep", "--cached", action="store_true", help="keep the file on disk")

    s = add("purge", cmd_purge, "erase files from ALL history")
    s.add_argument("paths", nargs="+")

    add("wipe", cmd_wipe, "delete ALL commits (files stay)", aliases=["clear-history"])

    s = add("drop", cmd_drop, "remove one commit from history")
    s.add_argument("rev")

    s = add("squash", cmd_squash, "combine commits into one")
    s.add_argument("-n", type=int, help="last N commits (default: all)")
    s.add_argument("-m", "--message")

    s = add("branch", cmd_branch, "list / create / delete branches", aliases=["br"])
    s.add_argument("name", nargs="?")
    s.add_argument("start", nargs="?", help="commit to start from")
    s.add_argument("-d", "--delete", metavar="NAME")
    s.add_argument("-D", dest="force", action="store_true", help="force delete")
    s.add_argument("-m", "--move", nargs="+", metavar="NAME", help="rename: -m [old] new")
    s.add_argument("-a", "--all", action="store_true", help="include remote branches")
    s.add_argument("-v", "--verbose", action="store_true", help="show the last commit of each branch")
    s.add_argument("-l", "--list", action="store_true", help="list branches (the default)")

    s = add("switch", cmd_switch, "switch to a branch", aliases=["sw", "goto"])
    s.add_argument("target")
    s.add_argument("-c", "--create", action="store_true", help="create it first")
    s.add_argument("-f", "--force", action="store_true", help="discard local changes")

    s = add("checkout", cmd_checkout, "restore files or move to a commit", aliases=["co"])
    s.add_argument("target", nargs="?")
    s.add_argument("paths", nargs="*")
    s.add_argument("-f", "--force", action="store_true")
    s.add_argument("-b", dest="create", action="store_true", help="create the branch first")
    s.add_argument("-B", dest="create_force", action="store_true", help="create or reset the branch")

    s = add("merge", cmd_merge, "merge a branch into this one")
    s.add_argument("branch", nargs="?")
    s.add_argument("-m", "--message")
    s.add_argument("--abort", action="store_true")
    s.add_argument("--continue", dest="cont", action="store_true")
    s.add_argument("--no-ff", dest="no_ff", action="store_true", help="always make a merge commit")
    s.add_argument("--ff-only", dest="ff_only", action="store_true", help="refuse if a merge commit is needed")

    s = add("tag", cmd_tag, "name a commit (v1.0)")
    s.add_argument("name", nargs="?")
    s.add_argument("rev", nargs="?")
    s.add_argument("-m", "--message")
    s.add_argument("-d", "--delete", metavar="NAME")
    s.add_argument("-a", "--annotate", action="store_true", help="annotated tag (with a message)")
    s.add_argument("-l", "--list", action="store_true", help="list tags (the default)")
    s.add_argument("-f", "--force", action="store_true", help="replace an existing tag")

    s = add("reset", cmd_reset, "move the branch back to a commit")
    s.add_argument("rev", nargs="?")
    s.add_argument("--soft", action="store_true", help="keep changes staged")
    s.add_argument("--hard", action="store_true", help="throw changes away")
    s.add_argument("--mixed", action="store_true", help="keep changes, unstaged (default)")

    s = add("stash", cmd_stash, "set changes aside temporarily")
    s.add_argument("sub", nargs="?", help="push|pop|apply|list|drop")
    s.add_argument("index", nargs="?", type=int)
    s.add_argument("-m", "--message")
    s.add_argument("-u", "--untracked", action="store_true", help="include new files")

    s = add("ignore", cmd_ignore, "never track these patterns")
    s.add_argument("patterns", nargs="*")

    s = add("snapshot", cmd_snapshot, "save the whole history to one file", aliases=["backup"])
    s.add_argument("sub", nargs="?", help="[name] | list | delete <name>")
    s.add_argument("name", nargs="?")
    s.add_argument("--files", "-f", action="store_true", help="include working files too")
    s.add_argument("--all", "-a", action="store_true", help="list auto-backups too")
    s.add_argument("--list", "-l", action="store_true")

    s = add("restore", cmd_restore, "restore files, or the whole repo from a snapshot")
    s.add_argument("name", nargs="?", help="a file/folder to restore, or a snapshot name")
    s.add_argument("paths", nargs="*", help=argparse.SUPPRESS)
    s.add_argument("--staged", "--cached", action="store_true", help="unstage the files instead")
    s.add_argument("--source", metavar="REV", help="restore the files from this commit")
    s.add_argument("--snapshot", action="store_true", help="treat the name as a snapshot")

    s = add("undo", cmd_undo, "reverse the last action")
    s.add_argument("n", nargs="?", type=int)
    s.add_argument("--list", "-l", action="store_true", help="show the action journal")

    s = add("redo", cmd_redo, "re-apply an undone action")
    s.add_argument("n", nargs="?", type=int)

    s = add("push", cmd_push, "upload commits to GitHub", aliases=["upload"])
    s.add_argument("remote", nargs="?", default="origin")
    s.add_argument("branch", nargs="?")
    s.add_argument("-f", "--force", action="store_true")

    s = add("pull", cmd_pull, "download + merge from GitHub", aliases=["download"])
    s.add_argument("remote", nargs="?", default="origin")

    s = add("fetch", cmd_fetch, "download from GitHub without merging")
    s.add_argument("remote", nargs="?", default="origin")

    s = add("clone", cmd_clone, "download a repository")
    s.add_argument("url")
    s.add_argument("dir", nargs="?")

    s = add("remote", cmd_remote, "manage GitHub connection")
    s.add_argument("sub", nargs="?", help="add | remove | rename | show | get-url | set-url")
    s.add_argument("args", nargs="*")
    s.add_argument("-v", "--verbose", action="store_true", help="show the URLs")

    s = add("login", cmd_login, "save a GitHub token")
    s.add_argument("--host", default=None)
    s.add_argument("--username", "-u")
    s.add_argument("--token", "-t")

    s = add("logout", cmd_logout, "forget the saved token")
    s.add_argument("--host", default=None)

    s = add("projects", cmd_projects, "all HIT projects on this computer", aliases=["repos"])
    s.add_argument("sub", nargs="?", help="add|remove|clean")
    s.add_argument("args", nargs="*")
    s.add_argument("--fast", action="store_true", help="names only, no extra lookups")
    s.add_argument("--stats", "-s", action="store_true", help="also count commits, sizes and GitHub status")

    s = add("scan", cmd_scan, "find every Git/HIT project on this computer", aliases=["find"])
    s.add_argument("paths", nargs="*", help="folders/drives to search (default: home + all drives)")
    s.add_argument("--depth", type=int, default=6, help="how deep to look (default 6)")


    # ---- Git commands ----------------------------------------------------
    s = add("show", cmd_show, "show one commit and its changes")
    s.add_argument("rev", nargs="?")
    s.add_argument("--stat", action="store_true", help="only list the changed files")
    s.add_argument("--name-only", action="store_true", help="only print file names")

    s = add("ls-files", cmd_ls_files, "list tracked files")
    s.add_argument("-s", "--stage", action="store_true", help="show object ids too")

    s = add("ls-tree", cmd_ls_tree, "list the files inside a commit")
    s.add_argument("rev", nargs="?")

    s = add("rev-parse", cmd_rev_parse, "print the full id of a revision")
    s.add_argument("revs", nargs="*")

    s = add("describe", cmd_describe, "name a commit using the nearest tag")
    s.add_argument("rev", nargs="?")

    add("shortlog", cmd_shortlog, "commit counts per author")
    add("count-objects", cmd_count_objects, "how many objects the repository stores")

    s = add("blame", cmd_blame, "show who last changed each line of a file", aliases=["annotate"])
    s.add_argument("path")

    s = add("revert", cmd_revert, "undo a commit with a new commit (history kept)")
    s.add_argument("rev")
    s.add_argument("-m", "--message")

    s = add("cherry-pick", cmd_cherry_pick, "apply one commit from elsewhere onto this branch")
    s.add_argument("rev")
    s.add_argument("-m", "--message")

    s = add("mv", cmd_mv, "move or rename tracked files", aliases=["move", "rename"])
    s.add_argument("paths", nargs="+", metavar="SRC... DEST")

    s = add("clean", cmd_clean, "delete files HIT does not track")
    s.add_argument("-n", "--dry-run", action="store_true", help="only list them (default)")
    s.add_argument("-f", "--force", action="store_true", help="actually delete them")
    s.add_argument("-d", dest="directories", action="store_true", help=argparse.SUPPRESS)

    add("gc", cmd_gc, "pack loose objects to save space")
    add("fsck", cmd_fsck, "check the repository for damage", aliases=["check"])

    s = add("config", cmd_config, "get/set settings (user.name, user.email)")
    s.add_argument("key", nargs="?")
    s.add_argument("value", nargs="?")
    s.add_argument("--local", action="store_true", help="this repo only")
    s.add_argument("--global", dest="use_global", action="store_true", help="all your repos (the default)")
    s.add_argument("-l", "--list", action="store_true", help="show every setting")
    s.add_argument("--unset", action="store_true", help="remove a setting")

    s = add("explain", cmd_explain, "explain a command in plain English")
    s.add_argument("words", nargs="*")

    add("why", cmd_why, "explain the last error")
    add("version", cmd_version, "show version")
    add("setup", cmd_setup, "install hit.exe so `hit` works from any folder (adds to PATH)", aliases=["install"])

    s = add("update", cmd_update, "install the newest version of HIT", aliases=["upgrade", "self-update"])
    s.add_argument("--check", action="store_true", help="only check, don't install")

    s = add("ui", cmd_ui, "open the terminal dashboard (inside a repo: that repo; `hit ui all`: every project)", aliases=["dashboard"])
    s.add_argument("path", nargs="?", help="a project folder, or `all` for the full project list")

    add("export-git", cmd_export_git, "create a .git folder for Git tools")

    s = add("help", lambda a: None, "help; `hit help me` for an interactive guide")
    s.add_argument("words", nargs="*")
    return p


# --------------------------------------------------------------------------
# Dispatch: exact command, did-you-mean, or English
# --------------------------------------------------------------------------

_PARSER: argparse.ArgumentParser | None = None


def parser() -> argparse.ArgumentParser:
    global _PARSER
    if _PARSER is None:
        _PARSER = build_parser()
    return _PARSER


def known_commands() -> set[str]:
    names = set()
    for action in parser()._subparsers._group_actions:  # type: ignore[attr-defined]
        names.update(action.choices.keys())
    return names


def dispatch(argv: list[str]) -> int:
    """Run one exact hit command. Returns exit code."""
    # `hit log -- path` support: argparse can't do "--" dest; hoist manually
    if "--" in argv:
        i = argv.index("--")
        cmd, rest = argv[:i], argv[i + 1:]
        ns = parser().parse_args(cmd)
        if ns.cmd in ("diff",):
            ns.paths = rest
        elif ns.cmd in ("log", "history"):
            ns.path = rest[0] if rest else None
        elif ns.cmd in ("checkout", "co"):
            ns.paths = rest
        else:
            ns = parser().parse_args(cmd + rest)
    else:
        ns = parser().parse_args(argv)
    if ns.cmd == "help":
        if ns.words and ns.words[0] == "me":
            cmd_help_me(ns)
        elif ns.words:
            parser().parse_args([ns.words[0], "--help"])
        else:
            parser().print_help()
        return 0
    if ns.cmd == "undo" and ns.list:
        cmd_history(ns)
        return 0
    ns.fn(ns)
    return 0


def _looks_like_sentence(argv: list[str]) -> bool:
    """True when the whole line parses as a confident plain-English request."""
    try:
        from .nl import parse
        p = parse(" ".join(argv))
        return bool(p.intent and p.commands and p.confidence >= 1.0
                    and p.commands[0][:1] != argv[:1])
    except Exception:
        return False


def run_english(words: list[str]) -> int:
    from .nl import parse
    text = " ".join(words)
    p = parse(text)
    if not p.intent or not p.commands:
        say(red("I didn't understand: ") + f'"{text}"')
        if p.alternatives:
            say("Maybe you meant:")
            for alt in p.alternatives:
                ex = alt.examples[0] if alt.examples else alt.name
                say(f"  • {alt.explain}   {dim('e.g. hit ' + ex)}")
        say(dim("Try `hit help me` for a menu, or `hit help` for all commands."))
        return 1
    say(f"{cyan('→')} {p.intent.explain}")
    say(f"  {bold(p.pretty())}")
    if p.confidence < 1.0 and p.alternatives:
        say(dim("  (not 100% sure — alternatives: " + ", ".join(a.name for a in p.alternatives) + ")"))
    if not confirm("Run this?", default=True, force_ask=p.danger or p.confidence < 1.0):
        say("cancelled")
        return 0
    for cmd in p.commands:
        code = _run_exact(cmd)
        if code != 0:
            return code
    return 0


def _run_exact(argv: list[str]) -> int:
    try:
        return dispatch(argv)
    except HitError as e:
        _print_error(e)
        return 1
    except ArgError as e:
        say(red("error: ") + str(e))
        return 2


def _print_error(e: HitError) -> None:
    say(red("error: ") + str(e))
    if e.hint:
        say(dim("  hint: " + e.hint))
    record_error(str(e))


def main(argv: list[str] | None = None) -> int:
    """Entry point: run the command, with the daily update check around it."""
    from . import updater
    args_seen = list(sys.argv[1:] if argv is None else argv)
    try:
        updater.cleanup_after_update()
        if sys.stdout.isatty():                  # people, not scripts
            updater.start_background_check()
    except Exception:
        pass
    code = 0
    try:
        code = _main(argv)
    finally:
        try:
            words = [a for a in args_seen if not a.startswith("-")]
            updater.maybe_print_notice(words[0].lower() if words else None)
        except Exception:
            pass
    return code


def _main(argv: list[str] | None = None) -> int:
    global YES
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] in ("-y", "--yes"):
        YES = True
        argv = argv[1:]
    if not argv and _launched_by_double_click():
        return _double_click_install()
    if not argv:
        # no args: status if in a repo, otherwise the projects list
        try:
            Repository.find()
            argv = ["status"]
        except NotARepo:
            from .logo import print_banner
            print_banner()
            parser().print_help()
            return 0
    if argv[0] in ("--version", "-V"):
        cmd_version(None)
        return 0
    if argv[0] in ("-h", "--help"):
        parser().print_help()
        return 0
    first = argv[0].lower()
    commands = known_commands()
    try:
        from . import registry
        registry.touch(Repository.find().root)
    except Exception:
        pass
    try:
        if first in commands:
            # `hit push to github`, `hit save my work as x`: a real command word followed by
            # English filler — argparse might "accept" it with wrong meaning, so route to English.
            from .nl.intents import FILLER
            english_words = FILLER | {
                "github", "gh", "git", "everything", "changes", "change", "work", "code", "stuff",
                "latest", "history", "commits", "commit", "branches", "projects", "repos", "files",
                "folders", "message", "again", "back", "please", "instead",
            }
            rest = [a.lower() for a in argv[1:] if not a.startswith("-")]
            if rest and any(w in english_words for w in rest):
                return run_english(argv)
            try:
                return dispatch(argv)
            except HitError as e:
                # `hit show history` — a command word, but the rest is English.
                if len(argv) > 1 and not argv[1].startswith("-") and _looks_like_sentence(argv):
                    return run_english(argv)
                raise
            except ArgError as e:
                # e.g. `hit save my changes as ...` — `save` is a command, but the
                # rest isn't valid flags, so treat the whole line as English.
                if len(argv) > 1 and not argv[1].startswith("-"):
                    return run_english(argv)
                say(red("error: ") + str(e))
                say(dim(f"  try: hit {first} --help"))
                return 2
        # a single unknown word close to a command: did-you-mean
        from .nl.parser import suggest_commands
        if len(argv) == 1 or (len(argv) > 1 and argv[1].startswith("-")):
            close = suggest_commands(first)
            if close and len(argv) == 1:
                if confirm(f"Unknown command '{first}'. Did you mean `hit {close[0]}`?", default=True):
                    return dispatch([close[0]] + argv[1:])
                return 1
        # otherwise: English
        return run_english(argv)
    except HitError as e:
        _print_error(e)
        return 1
    except ArgError as e:
        say(red("error: ") + str(e))
        return 2
    except KeyboardInterrupt:
        print()
        return 130
    except SystemExit as e:
        return int(e.code or 0)


if __name__ == "__main__":
    sys.exit(main())
