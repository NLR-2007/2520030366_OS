"""The Repository: ties objects, index and refs together."""
from __future__ import annotations

import configparser
import fnmatch
import os
import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path

from .index import Index, IndexEntry
from .objects import (MODE_DIR, MODE_FILE, Commit, ObjectNotFound, ObjectStore,
                      Tag, build_tree, flatten_tree, mode_for_path, mode_from_stat)

PARALLEL_THRESHOLD = 64   # below this, threads cost more than they save
WORKERS = min(16, (os.cpu_count() or 4) * 2)
from .refs import RefError, Refs, write_lf

HIT_DIR = ".hit"
DEFAULT_BRANCH = "main"


def stat_is_link(st: os.stat_result) -> bool:
    import stat as _stat
    return _stat.S_ISLNK(st.st_mode)


def is_repo_dir(folder: Path) -> bool:
    """True if `folder` holds a real repository (.hit or .git with a HEAD file).
    ~/.hit (HIT's global settings folder) has no HEAD, so a home directory never counts."""
    folder = Path(folder)
    return (folder / HIT_DIR / "HEAD").is_file() or (folder / ".git" / "HEAD").is_file()


class HitError(Exception):
    """User-facing error. The CLI prints str(e) and exits 1."""

    def __init__(self, msg: str, hint: str | None = None):
        super().__init__(msg)
        self.hint = hint


class NotARepo(HitError):
    def __init__(self):
        super().__init__("not a HIT repository (no .hit folder here or above)",
                         "run `hit init` to start one here")


# --------------------------------------------------------------------------
# Config
# --------------------------------------------------------------------------

class Config:
    def __init__(self, paths: list[Path]):
        self.paths = paths
        self.cp = configparser.ConfigParser()
        self.cp.read([str(p) for p in paths if p.exists()])

    def get(self, section: str, key: str, default: str | None = None) -> str | None:
        return self.cp.get(section, key, fallback=default)

    def set(self, section: str, key: str, value: str, path: Path | None = None) -> None:
        target = path or self.paths[0]
        cp = configparser.ConfigParser()
        cp.read(str(target))
        if not cp.has_section(section):
            cp.add_section(section)
        cp.set(section, key, value)
        target.parent.mkdir(parents=True, exist_ok=True)
        with open(target, "w", newline="\n") as f:
            cp.write(f)
        self.cp.read([str(p) for p in self.paths if p.exists()])


def global_config_path() -> Path:
    return Path.home() / ".hitconfig"


def global_hit_dir() -> Path:
    d = Path.home() / ".hit"
    d.mkdir(exist_ok=True)
    return d


# --------------------------------------------------------------------------
# Ignore rules (.hitignore and .gitignore, gitignore-like semantics)
# --------------------------------------------------------------------------

class IgnoreRules:
    def __init__(self, root: Path):
        self.patterns: list[tuple[str, bool, bool]] = []  # (pattern, negate, dir_only)
        for name in (".hitignore", ".gitignore"):
            p = root / name
            if p.exists():
                self._load(p.read_text(errors="replace"))
        self.patterns.append((HIT_DIR, False, True))
        self.patterns.append((".git", False, True))

    def _load(self, text: str) -> None:
        for line in text.splitlines():
            line = line.rstrip()
            if not line or line.startswith("#"):
                continue
            negate = line.startswith("!")
            if negate:
                line = line[1:]
            dir_only = line.endswith("/")
            line = line.rstrip("/")
            self.patterns.append((line, negate, dir_only))

    def _compiled_rules(self):
        """Compile each pattern once. Windows file names are case-insensitive,
        so matching is too (same behaviour fnmatch had via normcase)."""
        if getattr(self, "_rules", None) is None:
            flags = re.IGNORECASE if os.name == "nt" else 0
            rules = []
            for pat, negate, dir_only in self.patterns:
                anchored = pat.startswith("/")
                p = pat.lstrip("/")
                rx = re.compile(fnmatch.translate(p), flags)
                path_rx = re.compile(fnmatch.translate(p + "/*"), flags) if ("/" in p or anchored) else None
                rules.append((rx, path_rx, negate, dir_only, "/" in p or anchored))
            self._rules = rules
        return self._rules

    def is_ignored(self, rel: str, is_dir: bool) -> bool:
        ignored = False
        parts = rel.split("/")
        for rx, path_rx, negate, dir_only, whole_path in self._compiled_rules():
            if dir_only and not is_dir:
                # A dir-only pattern still ignores files *inside* that dir
                if not any(rx.match(p) for p in parts[:-1]):
                    continue
                ignored = not negate
                continue
            if whole_path:
                match = bool(rx.match(rel) or path_rx.match(rel))
            else:
                match = any(rx.match(part) for part in parts)
            if match:
                ignored = not negate
        return ignored


# --------------------------------------------------------------------------
# Status result
# --------------------------------------------------------------------------

@dataclass
class Status:
    branch: str | None
    head: str | None
    staged: dict[str, str] = field(default_factory=dict)      # path -> A/M/D
    unstaged: dict[str, str] = field(default_factory=dict)    # path -> M/D
    untracked: list[str] = field(default_factory=list)
    conflicts: list[str] = field(default_factory=list)

    @property
    def clean(self) -> bool:
        return not (self.staged or self.unstaged or self.untracked or self.conflicts)


# --------------------------------------------------------------------------
# Repository
# --------------------------------------------------------------------------

class Repository:
    def __init__(self, root: Path):
        self.root = Path(root).resolve()
        self.hit_dir = self.root / HIT_DIR
        if not (self.hit_dir / "HEAD").is_file() and (self.root / ".git" / "HEAD").is_file():
            # A plain Git project: same on-disk format, so HIT can work in it directly.
            self.hit_dir = self.root / ".git"
            for d in ("hit/snapshots", "hit/backups"):
                (self.hit_dir / d).mkdir(parents=True, exist_ok=True)
        self.store = ObjectStore(self.hit_dir)
        self.refs = Refs(self.hit_dir)
        self.index = Index(self.hit_dir / "index")
        self.config = Config([self.hit_dir / "config", global_config_path()])
        self.extras_dir = self.hit_dir / "hit"
        if self.index.unsupported:
            # Git wrote an index HIT can't read (rare); rebuild it from HEAD.
            for rel, (mode, sha) in self.head_files().items():
                p = self.root / rel
                self.index.add(IndexEntry.from_file(self.root, rel, sha, mode) if p.exists()
                               else IndexEntry(rel, sha, mode, 0))
            self.index.unsupported = False
            self.index.save()

    # ---- discovery / creation --------------------------------------------

    @classmethod
    def find(cls, start: Path | None = None) -> "Repository":
        cur = Path(start or os.getcwd()).resolve()
        while True:
            if is_repo_dir(cur):
                return cls(cur)
            if cur.parent == cur:
                raise NotARepo()
            cur = cur.parent

    @property
    def is_git_dir(self) -> bool:
        return self.hit_dir.name == ".git"

    @classmethod
    def init(cls, root: Path, template: str | None = None) -> "Repository":
        root = Path(root).resolve()
        hit = root / HIT_DIR
        if hit.exists():
            raise HitError(f"{root} is already a HIT repository")
        for d in ("objects", "objects/pack", "objects/info", "refs/heads", "refs/tags",
                  "hit/snapshots", "hit/backups"):
            (hit / d).mkdir(parents=True)
        write_lf(hit / "HEAD", f"ref: refs/heads/{DEFAULT_BRANCH}\n")
        write_lf(hit / "description", "HIT repository\n")
        cfg = configparser.ConfigParser()
        cfg["core"] = {"repositoryformatversion": "0", "filemode": "false", "bare": "false"}
        with open(hit / "config", "w", newline="\n") as f:
            cfg.write(f)
        from .templates import write_default_ignore, write_ignore_template
        write_default_ignore(root)
        if template:
            write_ignore_template(root, template)
        repo = cls(root)
        from .registry import register
        register(repo)
        return repo

    # ---- identity ---------------------------------------------------------

    def identity(self) -> tuple[str, str]:
        name = self.config.get("user", "name") or os.environ.get("HIT_AUTHOR_NAME")
        email = self.config.get("user", "email") or os.environ.get("HIT_AUTHOR_EMAIL")
        if not name:
            name = os.environ.get("USERNAME") or os.environ.get("USER") or "HIT User"
        if not email:
            email = f"{name.replace(' ', '.').lower()}@hit.local"
        return name, email

    # ---- paths ------------------------------------------------------------

    def rel(self, path: str | Path) -> str:
        p = Path(path)
        if not p.is_absolute():
            p = Path.cwd() / p
        try:
            return p.resolve().relative_to(self.root).as_posix()
        except ValueError:
            raise HitError(f"{path} is outside the repository")

    def ignore(self) -> IgnoreRules:
        return IgnoreRules(self.root)

    def walk_files(self) -> list[str]:
        """All non-ignored files in the working tree (relative posix paths)."""
        rules = self.ignore()
        out: list[str] = []
        for dirpath, dirnames, filenames in os.walk(self.root):
            rel_dir = Path(dirpath).relative_to(self.root).as_posix()
            rel_dir = "" if rel_dir == "." else rel_dir
            keep = []
            for d in dirnames:
                rd = f"{rel_dir}/{d}" if rel_dir else d
                if not rules.is_ignored(rd, True):
                    keep.append(d)
            dirnames[:] = sorted(keep)
            for f in sorted(filenames):
                rf = f"{rel_dir}/{f}" if rel_dir else f
                if not rules.is_ignored(rf, False):
                    out.append(rf)
        return out

    # ---- resolving revisions ---------------------------------------------

    def resolve(self, rev: str) -> str:
        """Turn 'HEAD', 'main', 'HEAD~2', 'a1b2c3', 'v1.0' into a commit sha."""
        rev = rev.strip()
        if rev in ("HEAD", "@"):
            sha = self.refs.head()
            if not sha:
                raise HitError("no commits yet", "make your first commit with `hit commit`")
            return sha
        m = re.match(r"^(.+?)(~(\d*)|\^(\d*))$", rev)
        if m:
            base = self.resolve(m.group(1))
            if m.group(2).startswith("~"):
                n = int(m.group(3) or 1)
                for _ in range(n):
                    c = self.store.read_commit(base)
                    if not c.parents:
                        raise HitError(f"{rev}: history does not go back that far")
                    base = c.parents[0]
                return base
            n = int(m.group(4) or 1)
            c = self.store.read_commit(base)
            if n == 0:
                return base
            if len(c.parents) < n:
                raise HitError(f"{rev}: commit has no parent #{n}")
            return c.parents[n - 1]
        for candidate in (f"refs/heads/{rev}", f"refs/tags/{rev}", f"refs/remotes/{rev}", rev):
            sha = self.refs.read(candidate)
            if sha:
                kind, _ = self.store.read(sha)
                if kind == "tag":
                    return self.store.read_commit(sha).sha
                return sha
        try:
            return self.store.resolve_prefix(rev)
        except ObjectNotFound:
            raise HitError(f"unknown revision or branch: '{rev}'",
                           "use `hit log` or `hit branch` to see what exists")

    def head_commit(self) -> Commit | None:
        sha = self.refs.head()
        return self.store.read_commit(sha) if sha else None

    def head_files(self) -> dict[str, tuple[int, str]]:
        c = self.head_commit()
        return flatten_tree(self.store, c.tree) if c else {}

    def commit_files(self, sha: str) -> dict[str, tuple[int, str]]:
        c = self.store.read_commit(sha)
        return flatten_tree(self.store, c.tree)

    # ---- staging ----------------------------------------------------------

    def _hash_file(self, rel: str) -> tuple[str, int]:
        p = self.root / rel
        if p.is_symlink():
            data = os.readlink(p).encode()
        else:
            data = p.read_bytes()
        return self.store.write_blob(data), mode_for_path(p)

    def _index_mtime(self) -> int:
        try:
            return int(self.index.path.stat().st_mtime)
        except OSError:
            return 0

    def _stage_one(self, rel: str, index_mtime: int = 0) -> IndexEntry | None:
        """Hash one file into the store. Returns None if it is unchanged since
        it was last staged (see Index.stat_unchanged for the exact rule)."""
        p = self.root / rel
        st = p.lstat()
        old = self.index.get(rel)
        if self.index.stat_unchanged(old, st):
            return None
        if stat_is_link(st):
            data = os.readlink(p).encode()
        else:
            with open(p, "rb") as f:
                data = f.read()
        sha = self.store.write_blob(data)
        if old and old.sha == sha and old.mode == mode_from_stat(st):
            # content identical; refresh the cached stat so next time is instant
            self.index.add(IndexEntry.from_stat(rel, sha, old.mode, st))
            return None
        return IndexEntry.from_stat(rel, sha, mode_from_stat(st), st)

    def blob_sizes(self, shas) -> dict[str, int]:
        """Sizes of blobs, using the staging area first (no disk reads for the
        current commit), then the object store's on-disk cache."""
        shas = list(shas)
        known = {e.sha: e.size for e in self.index.entries.values() if e.size}
        out = {s: known[s] for s in shas if s in known}
        rest = [s for s in shas if s not in out]
        if rest:
            out.update(self.store.sizes(rest))
        return out

    def stage_files(self, rels: list[str]) -> list[str]:
        """Stage many files, in parallel when there are lots of them.
        Returns only the files whose content actually changed."""
        index_mtime = self._index_mtime()
        results: list[IndexEntry | None]
        if len(rels) >= PARALLEL_THRESHOLD:
            from concurrent.futures import ThreadPoolExecutor
            with ThreadPoolExecutor(max_workers=WORKERS) as pool:
                results = list(pool.map(lambda r: self._stage_one(r, index_mtime), rels))
        else:
            results = [self._stage_one(r, index_mtime) for r in rels]
        changed = []
        for entry in results:
            if entry is not None:
                self.index.add(entry)
                changed.append(entry.path)
        return changed

    def add(self, paths: list[str]) -> list[str]:
        """Stage paths (files or dirs). Returns the files whose staged state changed."""
        rules = self.ignore()
        staged: list[str] = []
        head = self.head_files()
        for path in paths:
            abs_p = (Path.cwd() / path) if not Path(path).is_absolute() else Path(path)
            rel = self.rel(abs_p)
            if rel == ".":
                rel = ""
            if abs_p.is_dir():
                prefix = rel + "/" if rel else ""
                present = [f for f in self.walk_files() if f.startswith(prefix)]
                staged += self.stage_files(present)
                # files deleted from the working tree under this dir get unstaged too
                present_set = set(present)
                for f in list(self.index.paths()):
                    if f.startswith(prefix) and f not in present_set and not (self.root / f).exists():
                        self.index.remove(f)
                        staged.append(f)
            elif abs_p.exists():
                if rules.is_ignored(rel, False) and rel not in head:
                    raise HitError(f"'{path}' is ignored by .hitignore", "use `hit add -f` to force it")
                staged += self.stage_files([rel])
            elif self.index.get(rel):
                self.index.remove(rel)
                staged.append(rel)
            else:
                raise HitError(f"'{path}' does not exist")
        self.index.save()
        return staged

    def unstage(self, paths: list[str] | None) -> None:
        """Reset the index for paths back to HEAD (or everything)."""
        head = self.head_files()
        targets = [self.rel(p) for p in paths] if paths else None
        for rel in (targets or self.index.paths()):
            in_head = head.get(rel)
            self.index.remove(rel)
            if in_head:
                mode, sha = in_head
                self.index.add(IndexEntry(rel, sha, mode, 0))
        if targets is None:
            for rel, (mode, sha) in head.items():
                if not self.index.get(rel):
                    self.index.add(IndexEntry(rel, sha, mode, 0))
        self.index.save()

    def rm(self, paths: list[str], keep_file: bool = False) -> list[str]:
        removed = []
        for path in paths:
            rel = self.rel(path)
            abs_p = self.root / rel
            targets = [rel]
            if abs_p.is_dir():
                targets = [p for p in self.index.paths() if p.startswith(rel + "/")]
            for t in targets:
                if not self.index.remove(t):
                    raise HitError(f"'{t}' is not tracked")
                if not keep_file and (self.root / t).exists():
                    (self.root / t).unlink()
                removed.append(t)
            if not keep_file and abs_p.is_dir() and not any(abs_p.iterdir()):
                abs_p.rmdir()
        self.index.save()
        return removed

    # ---- commit -----------------------------------------------------------

    def write_index_tree(self) -> str:
        return build_tree(self.store, self.index.as_tree_files())

    def commit(self, message: str, allow_empty: bool = False, parents: list[str] | None = None,
               amend: bool = False) -> Commit:
        if self.index.conflicts():
            raise HitError("you still have unresolved conflicts",
                           "fix the files, then `hit add` them, then commit again")
        name, email = self.identity()
        head = self.refs.head()
        if amend:
            if not head:
                raise HitError("nothing to amend")
            old = self.store.read_commit(head)
            parents = old.parents
            message = message or old.message
        elif parents is None:
            parents = [head] if head else []
        tree = self.write_index_tree()
        if not allow_empty and not amend:
            if parents and self.store.read_commit(parents[0]).tree == tree:
                raise HitError("nothing to commit", "stage changes first with `hit add <file>` or `hit add .`")
            if not parents and not self.index.paths():
                raise HitError("nothing to commit", "stage changes first with `hit add <file>` or `hit add .`")
        if not message.strip():
            raise HitError("commit message is empty")
        c = Commit.new(tree, parents, name, email, message)
        sha = self.store.write_commit(c)
        c.sha = sha
        if not self.refs.current_branch() and not head:
            self.refs.set_head_branch(DEFAULT_BRANCH)
        self.refs.update_head(sha)
        return c

    # ---- log --------------------------------------------------------------

    def log(self, start: str | None = None, limit: int | None = None, all_branches: bool = False) -> list[Commit]:
        """Commits reachable from start (default HEAD), newest first."""
        heads: list[str] = []
        if all_branches:
            heads = list(self.refs.branches().values())
            h = self.refs.head()
            if h:
                heads.append(h)
        else:
            h = self.resolve(start) if start else self.refs.head()
            if h:
                heads = [h]
        seen: set[str] = set()
        out: list[Commit] = []
        frontier = [self.store.read_commit(h) for h in dict.fromkeys(heads)]
        while frontier:
            frontier.sort(key=lambda c: c.commit_time, reverse=True)
            c = frontier.pop(0)
            if c.sha in seen:
                continue
            seen.add(c.sha)
            out.append(c)
            if limit and len(out) >= limit:
                break
            for p in c.parents:
                if p not in seen:
                    frontier.append(self.store.read_commit(p))
        return out

    def ancestors(self, sha: str) -> set[str]:
        seen: set[str] = set()
        stack = [sha]
        while stack:
            s = stack.pop()
            if s in seen:
                continue
            seen.add(s)
            stack.extend(self.store.read_commit(s).parents)
        return seen

    def merge_base(self, a: str, b: str) -> str | None:
        anc_a = self.ancestors(a)
        # BFS from b, first hit in anc_a is a good-enough common ancestor
        queue = [b]
        seen: set[str] = set()
        while queue:
            s = queue.pop(0)
            if s in seen:
                continue
            seen.add(s)
            if s in anc_a:
                return s
            queue.extend(self.store.read_commit(s).parents)
        return None

    # ---- status -----------------------------------------------------------

    def status(self) -> Status:
        st = Status(self.refs.current_branch(), self.refs.head())
        head = self.head_files()
        idx = self.index.as_tree_files()
        st.conflicts = self.index.conflicts()

        conflicted = set(st.conflicts)
        for path in (set(head) | set(idx)) - conflicted:
            h = head.get(path)
            i = idx.get(path)
            if h and not i:
                st.staged[path] = "D"
            elif i and not h:
                st.staged[path] = "A"
            elif h[1] != i[1] or h[0] != i[0]:
                st.staged[path] = "M"

        work = set(self.walk_files())

        def check(path: str) -> str | None:
            """'D' deleted, 'M' modified, None unchanged — one lstat per file."""
            try:
                s = (self.root / path).lstat()
            except (FileNotFoundError, NotADirectoryError):
                return "D"
            except OSError:
                return None
            e = self.index.get(path)
            if self.index.stat_unchanged(e, s):
                return None
            sha, _mode = self._hash_file(path)
            return "M" if sha != idx[path][1] else None

        paths = list(idx)
        if len(paths) >= PARALLEL_THRESHOLD:
            from concurrent.futures import ThreadPoolExecutor
            with ThreadPoolExecutor(max_workers=WORKERS) as pool:
                results = list(pool.map(check, paths))
        else:
            results = [check(p) for p in paths]
        for path, res in zip(paths, results):
            if res:
                st.unstaged[path] = res
        for path in sorted(work - set(idx) - conflicted):
            st.untracked.append(path)
        return st

    def _file_changed(self, rel: str, idx_entry: tuple[int, str]) -> bool:
        e = self.index.get(rel)
        p = self.root / rel
        try:
            s = p.lstat()
        except FileNotFoundError:
            return True
        if self.index.stat_unchanged(e, s):
            return False
        sha, mode = self._hash_file(rel)
        return sha != idx_entry[1]

    # ---- checkout ---------------------------------------------------------

    def checkout_tree(self, files: dict[str, tuple[int, str]], force: bool = False) -> None:
        """Make the working tree + index match `files` exactly (tracked files only)."""
        current = self.index.as_tree_files()
        if not force:
            st = self.status()
            dirty = set(st.unstaged) | set(st.staged)
            affected = {p for p in dirty if current.get(p) != files.get(p)}
            if affected:
                raise HitError("you have uncommitted changes that would be overwritten:\n  " +
                               "\n  ".join(sorted(affected)),
                               "commit them, `hit stash` them, or use --force to discard")
        for path in current:
            if path not in files:
                p = self.root / path
                if p.exists():
                    p.unlink()
                    self._prune_empty_dirs(p.parent)
        self.index.clear()
        for path, (mode, sha) in files.items():
            p = self.root / path
            needs_write = current.get(path) != (mode, sha) or not p.exists()
            if not needs_write and force:
                # index matches, but the working file itself may have been edited
                from .objects import hash_object
                try:
                    needs_write = hash_object("blob", p.read_bytes()) != sha
                except OSError:
                    needs_write = True
            if needs_write:
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_bytes(self.store.read_blob(sha))
            self.index.add(IndexEntry.from_file(self.root, path, sha, mode))
        self.index.save()

    def _prune_empty_dirs(self, d: Path) -> None:
        while d != self.root and d.exists() and not any(d.iterdir()):
            d.rmdir()
            d = d.parent

    def checkout_file(self, rel: str, rev: str | None = None) -> None:
        """Restore one file from the index (default) or a commit."""
        if rev:
            files = self.commit_files(self.resolve(rev))
            if rel not in files:
                raise HitError(f"'{rel}' does not exist in {rev}")
            mode, sha = files[rel]
        else:
            e = self.index.get(rel)
            if not e:
                raise HitError(f"'{rel}' is not tracked")
            mode, sha = e.mode, e.sha
        p = self.root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(self.store.read_blob(sha))
        self.index.add(IndexEntry.from_file(self.root, rel, sha, mode))
        self.index.save()

    def previous_branch(self) -> str | None:
        """The branch we were on before the last switch (for `hit switch -`)."""
        p = self.state_file("PREV_HEAD")
        if p.exists():
            name = p.read_text().strip()
            if name and self.refs.branch_exists(name):
                return name
        return None

    def _remember_branch(self) -> None:
        cur = self.refs.current_branch()
        if cur:
            write_lf(self.state_file("PREV_HEAD"), cur + "\n")

    def switch(self, target: str, create: bool = False, force: bool = False) -> str:
        """Switch to a branch (or commit, which auto-creates a branch to avoid detached HEAD)."""
        if target == "-":
            prev = self.previous_branch()
            if not prev:
                raise HitError("no previous branch to go back to",
                               "switch to a branch by name, e.g. `hit switch main`")
            target = prev
        if create:
            self._remember_branch()
            self.refs.create_branch(target, self.refs.head() or "")
            self.refs.set_head_branch(target)
            return target
        if self.refs.branch_exists(target):
            sha = self.refs.read(f"refs/heads/{target}")
            self.checkout_tree(self.commit_files(sha), force=force)
            self._remember_branch()
            self.refs.set_head_branch(target)
            return target
        # a commit / tag: create a branch pointing at it so nothing is lost
        sha = self.resolve(target)
        base = re.sub(r"[^A-Za-z0-9._-]", "-", target)[:20]
        name = f"from-{base}"
        n = 1
        while self.refs.branch_exists(name):
            n += 1
            name = f"from-{base}-{n}"
        self.checkout_tree(self.commit_files(sha), force=force)
        self.refs.create_branch(name, sha)
        self.refs.set_head_branch(name)
        return name

    # ---- reset ------------------------------------------------------------

    def reset(self, rev: str, mode: str = "mixed") -> str:
        sha = self.resolve(rev)
        files = self.commit_files(sha)
        if mode == "hard":
            self.checkout_tree(files, force=True)
        elif mode == "mixed":
            self.index.clear()
            for path, (m, s) in files.items():
                self.index.add(IndexEntry(path, s, m, 0))
            self.index.save()
        self.refs.update_head(sha)
        return sha

    # ---- tags -------------------------------------------------------------

    def tag(self, name: str, rev: str = "HEAD", message: str | None = None) -> str:
        if self.refs.exists(f"refs/tags/{name}"):
            raise HitError(f"tag '{name}' already exists")
        sha = self.resolve(rev)
        if message:
            n, e = self.identity()
            from .objects import local_tz
            import time
            tagger = f"{n} <{e}> {int(time.time())} {local_tz()}"
            sha = self.store.write("tag", Tag(sha, "commit", name, tagger, message).serialize())
        self.refs.write(f"refs/tags/{name}", sha)
        return sha

    # ---- misc -------------------------------------------------------------

    def state_file(self, name: str) -> Path:
        return self.hit_dir / name

    def in_merge(self) -> bool:
        return self.state_file("MERGE_HEAD").exists()
