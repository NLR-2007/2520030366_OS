"""Global list of HIT projects on this machine (~/.hit/projects.json)."""
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from .repo import HIT_DIR, global_hit_dir, is_repo_dir

if TYPE_CHECKING:
    from .repo import Repository


def _file() -> Path:
    return global_hit_dir() / "projects.json"


def _load() -> list[dict]:
    p = _file()
    if not p.exists():
        return []
    try:
        return json.loads(p.read_text())
    except json.JSONDecodeError:
        return []


def _save(items: list[dict]) -> None:
    _file().write_text(json.dumps(items, indent=2))


def register(repo: "Repository") -> None:
    add_path(repo.root)


SKIP_DIRS = {"node_modules", ".venv", "venv", "env", "__pycache__", "AppData", "Library", ".cache",
             "site-packages", ".gradle", ".m2", ".npm", ".cargo", "Windows", "Program Files", "Program Files (x86)",
             "ProgramData", "$Recycle.Bin", "System Volume Information", ".Trash", "Temp", "tmp", ".idea",
             ".vscode", "build", "dist", "target", "bin", "obj", ".git", ".hit", "Pods", "vendor"}


def default_scan_roots() -> list[Path]:
    """Where projects usually live: home folder + every fixed drive (Windows) or / (Unix)."""
    roots = [Path.home()]
    if os.name == "nt":
        import string
        for letter in string.ascii_uppercase:
            d = Path(f"{letter}:\\")
            if d.exists():
                roots.append(d)
    else:
        roots.append(Path("/"))
    return roots


def scan(roots: list[Path] | None = None, max_depth: int = 6, progress=None) -> list[Path]:
    """Find every Git / HIT project under the given roots."""
    found: list[Path] = []
    seen: set[Path] = set()
    for root in roots or default_scan_roots():
        root = Path(root)
        if not root.exists():
            continue
        base_depth = len(root.parts)
        for dirpath, dirnames, _files in os.walk(root, topdown=True, onerror=lambda e: None):
            p = Path(dirpath)
            if progress and len(found) % 1 == 0:
                progress(p)
            is_repo = (".git" in dirnames or ".hit" in dirnames) and is_repo_dir(p)
            if is_repo:
                rp = p.resolve()
                if rp not in seen:
                    seen.add(rp)
                    found.append(rp)
                dirnames[:] = []       # don't descend into a repo (nested repos are rare)
                continue
            if len(p.parts) - base_depth >= max_depth:
                dirnames[:] = []
                continue
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith((".", "$"))]
    return found


def touch(path: Path) -> None:
    """Record that a project was just used (a hit command ran in it / it was opened)."""
    try:
        path = Path(path).resolve()
        items = _load()
        for it in items:
            if Path(it["path"]).resolve() == path:
                it["last_used"] = int(time.time())
                _save(items)
                return
        if is_repo_dir(path):
            items.append({"name": path.name, "path": str(path), "added": int(time.time()),
                          "last_used": int(time.time())})
            _save(items)
    except OSError:
        pass


def add_path(path: Path) -> bool:
    path = Path(path).resolve()
    if not is_repo_dir(path):
        return False
    items = _load()
    for it in items:
        if Path(it["path"]).resolve() == path:
            return False
    items.append({"name": path.name, "path": str(path), "added": int(time.time())})
    _save(items)
    return True


def remove_path(path: Path) -> bool:
    path = Path(path).resolve()
    items = _load()
    new = [it for it in items if Path(it["path"]).resolve() != path]
    _save(new)
    return len(new) != len(items)


def clean() -> list[str]:
    items = _load()
    gone = [it["path"] for it in items if not is_repo_dir(Path(it["path"]))]
    _save([it for it in items if it["path"] not in gone])
    return gone


@dataclass
class ProjectInfo:
    name: str
    path: str
    exists: bool
    branch: str | None = None
    head: str | None = None
    last_message: str = ""
    last_time: int = 0
    last_used: int = 0

    @property
    def recency(self) -> int:
        """Newest of: last commit, last time used. Drives the default sort order."""
        return max(self.last_time, self.last_used)
    commits: int = 0
    size: int = 0
    dirty: bool | None = None
    kind: str = "hit"          # "hit" or "git" (a plain Git project HIT opens directly)
    github: str = ""           # "-", "pushed", "N commit(s) not pushed", "never pushed"
    stats_done: bool = False


def dir_size(path: Path) -> int:
    total = 0
    for root, _dirs, files in os.walk(path):
        for f in files:
            try:
                total += (Path(root) / f).stat().st_size
            except OSError:
                pass
    return total


def quick_info(info: "ProjectInfo") -> None:
    """Cheap facts: branch + last commit (a few file reads)."""
    try:
        from .objects import ObjectStore
        from .refs import Refs
        root = Path(info.path)
        hit_dir = root / HIT_DIR if (root / HIT_DIR).is_dir() else root / ".git"
        refs = Refs(hit_dir)
        info.branch = refs.current_branch()
        info.head = refs.head()
        if info.head:
            c = ObjectStore(hit_dir).read_commit(info.head)
            info.last_message = c.summary
            info.last_time = c.commit_time
    except Exception:
        pass


def full_stats(info: "ProjectInfo") -> None:
    """Expensive facts: commit count, size, dirty state, GitHub sync. Run in the background."""
    try:
        from .remote import sync_state
        from .repo import Repository
        repo = Repository(Path(info.path))
        if info.head:
            info.commits = len(repo.log(limit=5000))
        info.size = dir_size(repo.hit_dir)
        info.dirty = not repo.status().clean
        sy = sync_state(repo)
        info.github = "-" if not sy.connected else ("pushed" if sy.pushed else sy.label)
    except Exception:
        info.github = "?"
    info.stats_done = True


def projects(with_stats: bool = True) -> list[ProjectInfo]:
    out = []
    for it in _load():
        p = Path(it["path"])
        info = ProjectInfo(it.get("name", p.name), str(p), is_repo_dir(p))
        info.kind = "hit" if (p / HIT_DIR / "HEAD").is_file() else "git"
        info.last_used = int(it.get("last_used", 0))
        if info.exists:
            quick_info(info)
            if with_stats:
                full_stats(info)
        out.append(info)
    out.sort(key=lambda i: (i.exists, i.recency), reverse=True)   # most recent first, missing last
    return out
