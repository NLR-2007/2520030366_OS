# HIT - Version Control System : one-line installer for Windows (no Python needed)
#
#   irm https://hitvcs.vercel.app/install.ps1 | iex
#
# What it does: downloads hit.exe from the latest GitHub release, checks its
# SHA-256 checksum, puts it in %LOCALAPPDATA%\HIT\bin and adds that folder to
# your user PATH. No admin rights needed. Safe to run again to update.

$ErrorActionPreference = "Stop"
$ProgressPreference    = "SilentlyContinue"   # the progress bar makes downloads ~10x slower in PowerShell 5.1

# Old Windows PowerShell may default to TLS 1.0, which GitHub refuses.
try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
} catch { }

$Repo     = "NLR-2007/hit-releases"
# Direct download links: no GitHub API call, so no rate limit on shared networks.
$ExeUrl   = "https://github.com/$Repo/releases/latest/download/hit.exe"
$SumsUrl  = "https://github.com/$Repo/releases/latest/download/SHA256SUMS.txt"
$Dir      = Join-Path $env:LOCALAPPDATA "HIT\bin"
$Exe      = Join-Path $Dir "hit.exe"
$Tmp      = Join-Path $env:TEMP ("hit-download-" + [guid]::NewGuid().ToString() + ".exe")

function Say($msg, $color = "Gray") { Write-Host $msg -ForegroundColor $color }

Say ""
Say "HIT - Version Control System installer" "White"
Say "  from $ExeUrl"

New-Item -ItemType Directory -Force -Path $Dir | Out-Null

# ---- download (with retries) -------------------------------------------------
$ok = $false
for ($i = 1; $i -le 3 -and -not $ok; $i++) {
    try {
        Invoke-WebRequest -Uri $ExeUrl -OutFile $Tmp -UseBasicParsing -TimeoutSec 300
        $ok = $true
    } catch {
        Say "  download attempt $i failed: $($_.Exception.Message)" "Yellow"
        Start-Sleep -Seconds (2 * $i)
    }
}
if (-not $ok) {
    Say ""
    Say "Could not download hit.exe." "Red"
    Say "  Check your internet connection, or download it by hand from:"
    Say "  https://github.com/$Repo/releases/latest"
    Say "  then run it once as:  .\hit.exe setup"
    return
}

$size = (Get-Item $Tmp).Length
if ($size -lt 5MB) {
    Remove-Item $Tmp -Force -ErrorAction SilentlyContinue
    Say "The downloaded file is too small ($size bytes) - the download was blocked or incomplete." "Red"
    Say "  Try again, or download by hand: https://github.com/$Repo/releases/latest"
    return
}

# ---- verify checksum ---------------------------------------------------------
try {
    $sums = (Invoke-WebRequest -Uri $SumsUrl -UseBasicParsing -TimeoutSec 60).Content
    if ($sums -is [byte[]]) { $sums = [Text.Encoding]::UTF8.GetString($sums) }
    $expected = ($sums -split "`n" | Where-Object { $_ -match "hit\.exe" } | Select-Object -First 1) -split "\s+" | Select-Object -First 1
    $actual = (Get-FileHash -Algorithm SHA256 $Tmp).Hash.ToLower()
    if ($expected -and ($expected.ToLower() -ne $actual)) {
        Remove-Item $Tmp -Force -ErrorAction SilentlyContinue
        Say "Checksum mismatch - the download was corrupted. Nothing was installed. Please try again." "Red"
        return
    }
    if ($expected) { Say "  checksum verified" "Green" }
} catch {
    Say "  (could not fetch the checksum file; continuing)" "Yellow"
}

# ---- install -----------------------------------------------------------------
try {
    Copy-Item $Tmp $Exe -Force
} catch {
    Say "Could not replace $Exe - is HIT running right now? Close it and run this again." "Red"
    return
} finally {
    Remove-Item $Tmp -Force -ErrorAction SilentlyContinue
}
Unblock-File -Path $Exe -ErrorAction SilentlyContinue   # clear the 'downloaded from the internet' mark

# ---- PATH (user level, no admin) ---------------------------------------------
$userPath = [Environment]::GetEnvironmentVariable("Path", "User")
if (-not $userPath) { $userPath = "" }
if (($userPath -split ";") -notcontains $Dir) {
    [Environment]::SetEnvironmentVariable("Path", ($userPath.TrimEnd(";") + ";" + $Dir).TrimStart(";"), "User")
    Say "  added $Dir to your PATH" "Green"
}
$env:Path = "$env:Path;$Dir"   # usable in this window right away

Say ""
& $Exe version
Say ""
Say "Installed. You can use 'hit' in this window now; other windows need to be reopened." "Green"
Say "Start with:  hit init   then   hit save everything as first version"
