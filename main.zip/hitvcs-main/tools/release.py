"""Publish a new HIT version in one step.

    python tools/release.py 0.4.1 "Faster push" "Fixed the dashboard on small screens"

What it does, in order (it stops at the first failure, before anything is published):
  1. writes the version into hit/__init__.py and pyproject.toml
  2. runs the full test suite
  3. builds dist/hit.exe and checks it reports the new version
  4. writes dist/SHA256SUMS.txt
  5. publishes a GitHub release on NLR-2007/hit-releases with hit.exe + checksum
  6. writes website/latest.json, adds the notes to tools/changelog.json and
     regenerates every website page (tools/build_site.py)
  7. commits, tags and pushes this repo - Vercel then deploys the website, and
     every installed HIT sees the new version within a day

Requires: the GitHub CLI (`gh`) logged in with access to NLR-2007/hit-releases.
"""
from __future__ import annotations

import datetime
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RELEASES_REPO = "NLR-2007/hit-releases"


def run(cmd: list[str], **kw) -> subprocess.CompletedProcess:
    print("  $", " ".join(cmd))
    return subprocess.run(cmd, cwd=ROOT, check=True, **kw)


def set_version(version: str) -> None:
    init = ROOT / "hit" / "__init__.py"
    init.write_text(re.sub(r'__version__ = "[^"]+"', f'__version__ = "{version}"', init.read_text()))
    py = ROOT / "pyproject.toml"
    py.write_text(re.sub(r'(?m)^version = "[^"]+"', f'version = "{version}"', py.read_text()))


def main() -> int:
    if len(sys.argv) < 2 or not re.fullmatch(r"\d+\.\d+\.\d+", sys.argv[1]):
        print(__doc__)
        return 2
    version, notes = sys.argv[1], sys.argv[2:] or ["Improvements and fixes"]
    tag = f"v{version}"
    print(f"Releasing HIT {version}")

    print("1. version"); set_version(version)
    print("2. tests"); run([sys.executable, "-m", "pytest", "tests", "-q"],
                           env={**__import__("os").environ, "HIT_NO_UPDATE_CHECK": "1", "PYTHONIOENCODING": "utf-8"})
    print("3. build"); run([sys.executable, "build_exe.py"])
    exe = ROOT / "dist" / "hit.exe"
    out = subprocess.run([str(exe), "version"], capture_output=True, text=True, encoding="utf-8", errors="replace")
    if version not in out.stdout:
        raise SystemExit(f"built exe reports {out.stdout!r}, expected {version}")

    print("4. checksum")
    data = exe.read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    (ROOT / "dist" / "SHA256SUMS.txt").write_text(f"{sha} *hit.exe\n")

    print("5. GitHub release")
    body = "\n".join([
        "## Install or update",
        "",
        "- **New users:** download `hit.exe` below and double-click it.",
        "- **Already have HIT:** run `hit update`.",
        "",
        f"## What's new in {version}",
        "",
        *[f"- {n}" for n in notes],
        "",
        "`SHA256SUMS.txt` contains the checksum of `hit.exe`.",
    ])
    notes_file = ROOT / "dist" / "RELEASE_NOTES.md"
    notes_file.write_text(body, encoding="utf-8")
    run(["gh", "release", "create", tag, str(exe), str(ROOT / "dist" / "SHA256SUMS.txt"),
         "-R", RELEASES_REPO, "--title", f"HIT {version}", "--notes-file", str(notes_file), "--latest"])

    print("6. website")
    latest = {
        "version": version,
        "url": f"https://github.com/{RELEASES_REPO}/releases/download/{tag}/hit.exe",
        "sha256": sha,
        "size": len(data),
        "published": datetime.date.today().isoformat(),
        "notes": notes,
    }
    (ROOT / "website" / "latest.json").write_text(json.dumps(latest, indent=2) + "\n")
    (ROOT / "website" / "install.ps1").write_text((ROOT / "install.ps1").read_text(encoding="utf-8"), encoding="utf-8")
    changelog_file = ROOT / "tools" / "changelog.json"
    changelog = [r for r in json.loads(changelog_file.read_text(encoding="utf-8")) if r["version"] != version]
    changelog.insert(0, {"version": version, "date": latest["published"], "title": notes[0], "notes": notes})
    changelog_file.write_text(json.dumps(changelog, indent=2) + "\n", encoding="utf-8")
    run([sys.executable, "tools/build_site.py"])

    print("7. commit, tag, push")
    git = ["git", "--git-dir=.hit", "--work-tree=."]
    run(git + ["add", "-A"])
    run(git + ["commit", "-m", f"Release {version}"])
    run(git + ["tag", "-a", tag, "-m", f"HIT {version}"])
    run(git + ["push", "origin", "main"])
    run(git + ["push", "origin", tag])
    print(f"\nDone. HIT {version} is published; installed copies will offer it within a day.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
