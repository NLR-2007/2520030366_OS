"""Generate every page of the HIT website from one layout.

    python tools/build_site.py

Pages: index (home), download, documents (guide), commands, examples, releases,
privacy, license. Header and footer are shared, so they never drift apart.

Content that describes the program comes from the program itself: the command
reference from the real argument parser, the phrasebook and every example
snippet are checked against HIT's real parsers (the build fails if one doesn't
parse), the release list from tools/changelog.json, and the download box from
website/latest.json.
"""
from __future__ import annotations

import argparse
import contextlib
import html
import io
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SITE = ROOT / "website"
sys.path.insert(0, str(ROOT))

from hit import __version__            # noqa: E402
from hit.cli import ArgError, build_parser  # noqa: E402
from hit.nl import parse                # noqa: E402
from hit.nl.intents import INTENTS      # noqa: E402

RELEASES_REPO = "NLR-2007/hit-releases"
DL = f"https://github.com/{RELEASES_REPO}/releases/latest/download/hit.exe"
GH_RELEASES = f"https://github.com/{RELEASES_REPO}/releases"
ISSUES = f"https://github.com/{RELEASES_REPO}/issues"
INSTALL_CMD = "irm https://hitvcs.vercel.app/install.ps1 | iex"
EMAIL = "support.nlrgroupofcompanies@gmail.com"
COMPANY = "https://nlrgroupofcompany.in"
e = html.escape

LATEST = json.loads((SITE / "latest.json").read_text(encoding="utf-8"))
CHANGELOG = json.loads((ROOT / "tools" / "changelog.json").read_text(encoding="utf-8"))
SIZE_MB = f"{LATEST['size'] / 1e6:.0f} MB"

DOWNLOAD_ICON = ('<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" '
                 'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12m0 0l-4.5-4.5M12 '
                 '15l4.5-4.5M4 17v2a2 2 0 002 2h12a2 2 0 002-2v-2"/></svg>')

NAV = [("download", "download.html", "Download"), ("docs", "documents.html", "Docs"),
       ("commands", "commands.html", "Commands"), ("examples", "examples.html", "Examples"),
       ("releases", "releases.html", "Releases")]


def md(text: str) -> str:
    """Escape, then turn `code` into <code>."""
    return re.sub(r"`([^`]+)`", r"<code>\1</code>", e(text))


# ---------------------------------------------------------------- layout
def layout(page: str, title: str, description: str, body: str, head: str = "") -> str:
    links = "\n".join(
        f'      <li><a href="{href}"{" aria-current=page" if key == page else ""}>{label}</a></li>'
        for key, href, label in NAV)
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{e(title)}</title>
  <meta name="description" content="{e(description)}">
  <meta property="og:title" content="{e(title)}">
  <meta property="og:description" content="{e(description)}">
  <meta property="og:type" content="website">
  <meta property="og:image" content="https://hitvcs.vercel.app/images/brand/og.png">
  <meta name="twitter:card" content="summary_large_image">
  <link rel="icon" href="favicon.ico" sizes="any">
  <link rel="icon" href="favicon-32.png" type="image/png">
  <link rel="apple-touch-icon" href="apple-touch-icon.png">
  <link rel="stylesheet" href="style.css">
  <script src="main.js" defer></script>{head}
</head>
<body>

<header class="site-header">
  <div class="container nav" id="nav">
    <a class="brand" href="index.html" aria-label="HIT home">
      <img class="brand-logo" src="images/brand/hit-mark.png" width="30" height="32" alt="">
      <span class="brand-name">HIT</span>
      <span class="brand-sub">Version Control</span>
    </a>
    <ul class="nav-links">
{links}
    </ul>
    <a class="btn btn-primary btn-sm nav-cta" href="{DL}">Download</a>
    <button class="menu-btn" type="button" aria-expanded="false" aria-controls="nav">Menu</button>
  </div>
</header>

<main>
{body}
</main>

<footer class="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div>
        <a class="brand" href="index.html" aria-label="HIT home"><img class="footer-logo" src="images/brand/hit-logo.png" width="120" height="44" alt="HIT Version Control"></a>
        <p style="margin-top:14px; max-width:26em;">Version control that understands plain English. A product of <a href="{COMPANY}">NLR Group of Companies</a>.</p>
      </div>
      <div>
        <h4>Product</h4>
        <ul>
          <li><a href="download.html">Download</a></li>
          <li><a href="releases.html">Release notes</a></li>
          <li><a href="documents.html#updates">Updating HIT</a></li>
        </ul>
      </div>
      <div>
        <h4>Learn</h4>
        <ul>
          <li><a href="documents.html">Documentation</a></li>
          <li><a href="commands.html">Command reference</a></li>
          <li><a href="examples.html">Examples</a></li>
          <li><a href="documents.html#faq">FAQ</a></li>
        </ul>
      </div>
      <div>
        <h4>Company</h4>
        <ul>
          <li><a href="{COMPANY}">NLR Group of Companies</a></li>
          <li><a href="mailto:{EMAIL}">Contact support</a></li>
          <li><a href="{ISSUES}">Report a problem</a></li>
          <li><a href="privacy.html">Privacy</a></li>
          <li><a href="license.html">License agreement</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; 2026 NLR Group of Companies. All rights reserved.</span>
      <span>&ldquo;Git&rdquo; and &ldquo;GitHub&rdquo; are trademarks of their owners. HIT is not affiliated with them.</span>
    </div>
  </div>
</footer>

</body>
</html>
"""


def page_head(eyebrow: str, title: str, lead: str, extra: str = "") -> str:
    return f"""  <section class="page-head">
    <div class="container">
      <div class="eyebrow">{eyebrow}</div>
      <h1>{title}</h1>
      <p class="lede">{lead}</p>{extra}
    </div>
  </section>"""


def with_sidebar(title: str, items: list[tuple[str, str]], content: str) -> str:
    nav = "\n".join(f'        <li><a href="#{i}">{t}</a></li>' for i, t in items)
    return f"""  <div class="container docs">
    <nav class="docs-nav" aria-label="{e(title)}">
      <h4>{e(title)}</h4>
      <ol>
{nav}
      </ol>
    </nav>
    <div class="doc">
{content}
    </div>
  </div>"""


def codeline(cid: str, text: str) -> str:
    return (f'<div class="codeline"><code id="{cid}">{e(text)}</code>'
            f'<button class="copy" type="button" data-copy="#{cid}">Copy</button></div>')


def cta_band() -> str:
    return f"""  <section class="cta-band">
    <div class="container">
      <h2>Start with your next commit.</h2>
      <p>Download HIT, open your project folder and type <code class="dark">hit init</code>. If you don&rsquo;t like what happened, <code class="dark">hit undo</code>.</p>
      <div class="cta-row">
        <a class="btn btn-light" href="{DL}">{DOWNLOAD_ICON} Download for Windows</a>
        <a class="btn btn-ghost" href="documents.html#start">Getting started guide</a>
      </div>
      <div class="cta-meta"><span>Version {e(LATEST['version'])}</span><span>Free to use</span><span>No account needed</span></div>
    </div>
  </section>"""


# ---------------------------------------------------------------- checks against the real program
_PARSER = build_parser()


def check_command(line: str) -> None:
    """Fail the build if an example line is neither a valid command nor understood English."""
    words = line.split()
    assert words[0] == "hit", line
    rest = line[4:]
    try:
        with contextlib.redirect_stderr(io.StringIO()), contextlib.redirect_stdout(io.StringIO()):
            _PARSER.parse_args(_split(rest))
        return
    except (SystemExit, ArgError):
        pass
    if parse(rest).commands:
        return
    raise SystemExit(f"example does not parse as a command or as English: {line!r}")


def _split(s: str) -> list[str]:
    import shlex
    return shlex.split(s, posix=True)


# ---------------------------------------------------------------- home
def home() -> str:
    phrases = [("save my work as fixed login", 'hit add . && hit commit -m "fixed login"'),
               ("undo my last commit", "hit reset --soft HEAD~1"),
               ("make a new branch called dark-mode", "hit switch -c dark-mode"),
               ("send my code to github", "hit push")]
    for say, _ in phrases:
        check_command("hit " + say)
    rows = "\n".join(f'        <div class="phrase"><div class="say">{e(s)}</div><div class="runs">{e(r)}</div></div>'
                     for s, r in phrases)
    body = f"""
  <section class="hero">
    <div class="container hero-grid">
      <div>
        <a class="release-link" href="releases.html">
          <span class="tag">{e(LATEST['version'])}</span> {e(CHANGELOG[0]['title'])} &mdash; what&rsquo;s new &rarr;
        </a>
        <h1>Version control you can talk to.</h1>
        <p class="lede">HIT does what Git does &mdash; commit, branch, merge, push to GitHub &mdash; but you can type what you want in plain English. It shows the exact command before running it, and any action can be undone.</p>
        <div class="cta-row">
          <a class="btn btn-primary" href="{DL}">{DOWNLOAD_ICON} Download for Windows</a>
          <a class="btn btn-outline" href="documents.html#start">Get started</a>
        </div>
        <div class="cta-meta">
          <span>Free to use</span><span>Windows 10 &amp; 11</span><span>No Python needed</span><span>{SIZE_MB}</span>
        </div>
      </div>

      <div class="term" role="img" aria-label="HIT saving work from a plain English request, then undoing it">
        <div class="term-bar"><i></i><i></i><i></i><b>weather-app &mdash; PowerShell</b></div>
<pre><span class="p">PS&gt;</span> <span class="c">hit save my work as fixed login redirect</span>
<span class="b">&rarr;</span> Save a checkpoint of your work (stage everything + commit)
  <span class="c">hit add .  &amp;&amp;  hit commit -m "fixed login redirect"</span>
Run this? [Y/n] <span class="c">y</span>
<span class="g">&#10004;</span> Committed <span class="y">489f9f7</span> on <span class="c">main</span>
  <span class="m">message  </span> fixed login redirect
  <span class="m">changes  </span> 2 files &middot; <span class="g">1 added</span>, <span class="y">1 modified</span>

    <span class="y">M</span>  src/api.py
    <span class="g">A</span>  src/auth.py

<span class="p">PS&gt;</span> <span class="c">hit undo</span>
Undo <span class="c">commit 489f9f7: fixed login redirect</span>?  <span class="m">just now</span>
Continue? [Y/n] <span class="c">y</span>
<span class="g">&#10004;</span> Undid 1 action
  <span class="m">hint  put it back with `hit redo`</span></pre>
      </div>
    </div>
  </section>

  <div class="container">
    <div class="facts" aria-label="Tested facts">
      <div class="fact"><strong>78</strong><span>Git command forms tested, from checkout&nbsp;-b to remote&nbsp;-v</span></div>
      <div class="fact"><strong>10,000</strong><span>files in one repository, tested for speed</span></div>
      <div class="fact"><strong>1</strong><span>command to undo any action you took</span></div>
      <div class="fact"><strong>0</strong><span>accounts, sign-ups or tracking</span></div>
    </div>
  </div>

  <section class="block">
    <div class="container split">
      <div class="section-head" style="margin-bottom:0">
        <div class="eyebrow">Plain English</div>
        <h2>Say it the way you think it.</h2>
        <p>If you already know Git commands, use them &mdash; they all work. If you don&rsquo;t, describe what you want. HIT understands more than 40 kinds of request, tolerates typos, and always asks before it runs anything.</p>
        <p class="more"><a href="examples.html">See examples and the full phrasebook &rarr;</a></p>
      </div>
      <div class="phrases">
{rows}
      </div>
    </div>
  </section>

  <section class="block tint">
    <div class="container">
      <div class="section-head">
        <div class="eyebrow">Dashboard</div>
        <h2>Every project, commit and file in one screen.</h2>
        <p>Type <code>hit ui</code> in any terminal. Browse branches and commits, open any file in any commit, see red and green line changes, and commit, undo or push with one key.</p>
      </div>
      <div class="shot">
        <img src="images/dashboard.svg" width="1300" height="780" alt="The HIT dashboard: branches on the left, the commit list in the middle, the files of the selected commit on the right, and a red and green line diff of src/api.py underneath.">
      </div>
      <p class="caption">Unedited screenshot of <code>hit ui</code> showing a sample project. <a href="documents.html#dashboard">Dashboard keys &rarr;</a></p>
    </div>
  </section>

  <section class="block">
    <div class="container">
      <div class="section-head">
        <div class="eyebrow">Features</div>
        <h2>Built so that mistakes are cheap.</h2>
        <p>Version control is only useful if you trust it. HIT asks before doing anything destructive, backs up first, and remembers every action.</p>
      </div>
      <div class="features">
        <div class="feature">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16v10H9l-5 4z"/><path d="M8 9h8M8 12h5"/></svg>
          <h3>Understands plain English</h3>
          <p>Describe the change you want. HIT shows the real command first, so you learn Git as you go.</p>
        </div>
        <div class="feature">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 14L4 9l5-5"/><path d="M4 9h11a5 5 0 010 10h-3"/></svg>
          <h3>Undo anything</h3>
          <p>Commits, merges, resets, deleted branches, even &ldquo;delete all history&rdquo; &mdash; <code>hit undo</code> reverses it.</p>
        </div>
        <div class="feature">
          <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16M3 10h6"/></svg>
          <h3>Terminal dashboard</h3>
          <p>All your projects in one list, sorted by recent activity. <code>hit scan</code> finds every Git project on your PC.</p>
        </div>
        <div class="feature">
          <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="6" cy="6" r="2"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="8" r="2"/><path d="M6 8v8M18 10c0 4-6 3-11 7"/></svg>
          <h3>Real Git underneath</h3>
          <p>Stores history in Git&rsquo;s own format. GitHub, VS Code and <code>git</code> read HIT projects, and HIT opens yours.</p>
        </div>
        <div class="feature">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6z"/><path d="M9 12l2 2 4-4"/></svg>
          <h3>Safe clean-up tools</h3>
          <p>Erase a leaked password from every commit, drop or squash commits &mdash; each confirms, backs up and can be undone.</p>
        </div>
        <div class="feature">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 12a8 8 0 11-2.3-5.7"/><path d="M20 4v5h-5"/></svg>
          <h3>Updates itself</h3>
          <p>A short reminder when a new version is out; <code>hit update</code> downloads, verifies and installs it.</p>
        </div>
      </div>
    </div>
  </section>

  <section class="block tint">
    <div class="container split">
      <div class="section-head" style="margin-bottom:0">
        <div class="eyebrow">Works with Git</div>
        <h2>Built on Git, not instead of it.</h2>
        <p>You don&rsquo;t lose anything by trying HIT. Your projects stay normal Git repositories, and you can switch back to <code>git</code> at any moment.</p>
      </div>
      <ul class="checks">
        <li><b>Standard repository format</b><span>Every commit, branch and tag is readable by Git, GitHub Desktop and VS Code.</span></li>
        <li><b>Push and pull with GitHub</b><span>First push asks for the repository address and a token, once. After that it&rsquo;s just <code>hit push</code>.</span></li>
        <li><b>Opens your existing projects</b><span>Point HIT at any folder that already uses Git &mdash; no conversion, nothing copied.</span></li>
        <li><b>Nothing leaves your PC unless you push</b><span>No account, no tracking. <a href="privacy.html">See exactly what HIT sends</a>.</span></li>
      </ul>
    </div>
  </section>

  <section class="block">
    <div class="container">
      <div class="section-head">
        <div class="eyebrow">Explore</div>
        <h2>Everything you need, one page each.</h2>
      </div>
      <div class="cards">
        <a class="card" href="download.html"><h3>Download &amp; install</h3><p>Install in two minutes, verify the checksum, remove it any time.</p><span>Download &rarr;</span></a>
        <a class="card" href="documents.html"><h3>Documentation</h3><p>Getting started, core ideas, the dashboard, GitHub and the FAQ.</p><span>Read the guide &rarr;</span></a>
        <a class="card" href="commands.html"><h3>Command reference</h3><p>Every HIT command and the Git flags it understands, searchable.</p><span>Browse commands &rarr;</span></a>
        <a class="card" href="examples.html"><h3>Examples</h3><p>Copy-ready snippets for everyday tasks and the plain English phrasebook.</p><span>See examples &rarr;</span></a>
        <a class="card" href="releases.html"><h3>Release notes</h3><p>What changed in each version, and how to update.</p><span>What&rsquo;s new &rarr;</span></a>
        <a class="card" href="privacy.html"><h3>Privacy</h3><p>The complete list of times HIT connects to the internet.</p><span>Read &rarr;</span></a>
      </div>
    </div>
  </section>

{cta_band()}"""
    return layout("home", "HIT — Version control you can talk to",
                  "HIT is version control for Windows that understands plain English, can undo any action, and works "
                  "with Git and GitHub. Free to use. From NLR Group of Companies.", body)


# ---------------------------------------------------------------- download
def download() -> str:
    v, sha = LATEST["version"], LATEST["sha256"]
    verify = codeline("verify-cmd", "(Get-FileHash .\\hit.exe -Algorithm SHA256).Hash")
    body = f"""{page_head("Download", "Download HIT", "One file for Windows 10 and 11. Double-click it and HIT installs itself for your Windows user &mdash; no admin rights, no Python, no account.")}

  <section class="block" style="padding-top:48px">
    <div class="container">
      <div class="dl-card">
        <div class="dl-main">
          <div class="dl-os">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 5.5l7.5-1v7H3zM11.5 4.3L21 3v8.5h-9.5zM3 12.5h7.5v7L3 18.5zM11.5 12.5H21V21l-9.5-1.3z"/></svg>
            <div><h2>HIT for Windows</h2><p>Version {e(v)} &middot; released {e(LATEST['published'])} &middot; {SIZE_MB} &middot; 64-bit</p></div>
          </div>
          <div class="cta-row" style="margin:0">
            <a class="btn btn-primary" href="{DL}">{DOWNLOAD_ICON} Download hit.exe</a>
            <a class="btn btn-outline" href="releases.html">Release notes</a>
          </div>
        </div>
        <dl class="dl-meta">
          <div><dt>Requires</dt><dd>Windows 10 or 11, 64-bit</dd></div>
          <div><dt>Installs to</dt><dd><code>%LOCALAPPDATA%\\HIT\\bin</code></dd></div>
          <div><dt>Admin rights</dt><dd>Not needed</dd></div>
          <div class="wide"><dt>SHA-256</dt><dd><code class="hash" id="sha">{e(sha)}</code> <button class="copy-sm" type="button" data-copy="#sha">Copy</button></dd></div>
        </dl>
      </div>
    </div>
  </section>

  <section class="block tint" id="install">
    <div class="container">
      <div class="section-head">
        <div class="eyebrow">Install</div>
        <h2>Three steps, about two minutes.</h2>
      </div>
      <div class="steps">
        <div class="step">
          <div class="text">
            <h3>Open hit.exe</h3>
            <p>Windows may show &ldquo;Windows protected your PC&rdquo; because HIT is new and not code-signed yet. Click <b>More info</b>, then <b>Run anyway</b>.</p>
          </div>
          <div class="shot narrow" style="background:#0067c0"><img src="images/install-step0-smartscreen.png" width="658" height="621" loading="lazy" alt="Windows SmartScreen dialog for hit.exe, showing the Run anyway and Don't run buttons"></div>
        </div>
        <div class="step">
          <div class="text">
            <h3>Press Enter to install</h3>
            <p>HIT tells you exactly what it will do &mdash; copy itself into your user folder and add itself to PATH &mdash; and asks before doing it.</p>
          </div>
          <div class="shot" style="background:#0c0c0c"><img src="images/install-step1-prompt.png" width="961" height="312" loading="lazy" alt="HIT installer explaining the steps and asking: Install HIT now? [Y/n]"></div>
        </div>
        <div class="step">
          <div class="text">
            <h3>Open a new terminal and start</h3>
            <p>Open a <b>new</b> PowerShell window and type <code>hit version</code>. Then go to your project folder and type <code>hit init</code>. You can delete the downloaded file.</p>
          </div>
          <div class="shot" style="background:#0c0c0c"><img src="images/install-step2-done.png" width="1121" height="396" loading="lazy" alt="HIT installer finished, listing five steps to get started"></div>
        </div>
      </div>
    </div>
  </section>

  <section class="block">
    <div class="container">
      <div class="options">
        <div class="option" id="powershell">
          <div class="eyebrow">Option</div>
          <h3>Install with one command</h3>
          <p>Paste into PowerShell. It downloads the latest version, verifies its checksum and installs it, without the Windows warning. Run it again any time to reinstall.</p>
          {codeline("install-cmd", INSTALL_CMD)}
        </div>
        <div class="option" id="verify">
          <div class="eyebrow">Security</div>
          <h3>Verify your download</h3>
          <p>In PowerShell, in the folder where you saved the file. The result must match the SHA-256 above.</p>
          {verify}
        </div>
        <div class="option" id="update">
          <div class="eyebrow">Updates</div>
          <h3>Keep HIT up to date</h3>
          <p>HIT reminds you once a day when a new version is out. Install it with:</p>
          {codeline("update-cmd", "hit update")}
        </div>
        <div class="option" id="uninstall">
          <div class="eyebrow">Remove</div>
          <h3>Uninstall</h3>
          <p>Delete the folder <code>%LOCALAPPDATA%\\HIT</code>, then remove it from <b>Settings &rarr; System &rarr; About &rarr; Advanced system settings &rarr; Environment Variables &rarr; Path</b> (your user variables). Your projects are not touched.</p>
        </div>
      </div>
      <p class="caption">Older versions and checksum files are on the <a href="{GH_RELEASES}">GitHub releases page</a>. Problems installing? Write to <a href="mailto:{EMAIL}">{EMAIL}</a>.</p>
    </div>
  </section>

{cta_band()}"""
    return layout("download", "Download HIT for Windows",
                  f"Download HIT {v} for Windows 10 and 11. Free, {SIZE_MB}, installs without admin rights.", body)


# ---------------------------------------------------------------- documentation
def documents() -> str:
    items = [("start", "Getting started"), ("concepts", "Core concepts"), ("help", "Getting help"),
             ("dashboard", "Dashboard"), ("github", "GitHub"), ("existing", "Existing Git projects"),
             ("updates", "Updating HIT"), ("files", "Files and folders"), ("faq", "FAQ")]
    content = f"""
      <section id="start">
        <h2>Getting started</h2>
        <p>First <a href="download.html">install HIT</a>. Then tell it who you are, once. This name appears on your commits:</p>
        <pre class="block">hit config user.name "Your Name"
hit config user.email "you@example.com"</pre>
        <p>Go to your project folder and start tracking it:</p>
        <pre class="block">cd C:\\projects\\my-app
hit init</pre>
        <p><code>hit init</code> creates a hidden <code>.hit</code> folder, a <code>.hitignore</code> file with the right rules for your kind of project (Node, Python, Java and others are detected automatically), a starter <code>README.md</code>, and offers to add a LICENSE.</p>
        <p>Save your first version, make changes, look at them, save again:</p>
        <pre class="block">hit save everything as first version
hit what changed
hit diff
hit save my work as fixed the login bug</pre>
        <p>Made a mistake? <code>hit undo</code>. Ready to share? <code>hit push to github</code>. Want to see it all? <code>hit ui</code>. More in <a href="examples.html">Examples</a>.</p>
      </section>

      <section id="concepts">
        <h2>Core concepts</h2>
        <p>Your work can be in three places. Commit often &mdash; it is instant and local. Push when you want the online copy updated.</p>
        <pre class="block">your files  --- hit add / hit commit --->  .hit (history on your PC)  --- hit push --->  GitHub
                                                                       &lt;--- hit pull ---</pre>
        <dl>
          <dt>Commit</dt><dd>A saved snapshot of all tracked files, with a message, your name and the time. Each commit points to the one before it; that chain is your history.</dd>
          <dt>Staging</dt><dd><code>hit add</code> chooses what goes into the next commit. <code>hit save &hellip;</code> stages and commits in one step.</dd>
          <dt>Branch</dt><dd>A separate line of work. <code>main</code> is the default. Try an idea on a branch, then merge it back or delete it.</dd>
          <dt>Merge</dt><dd>Combining one branch into another. If both changed the same lines, HIT marks the spot with <code>&lt;&lt;&lt;&lt;&lt;&lt;&lt;</code> and <code>&gt;&gt;&gt;&gt;&gt;&gt;&gt;</code>. Keep the lines you want, <code>hit add</code> the file, then <code>hit merge --continue</code>.</dd>
          <dt>Undo</dt><dd>HIT records every action in a journal. <code>hit undo</code> restores the state before the last one; <code>hit redo</code> puts it back.</dd>
          <dt>Snapshot</dt><dd>The whole history saved into one file. <code>hit restore &lt;name&gt;</code> brings it back.</dd>
        </dl>
      </section>

      <section id="help">
        <h2>Getting help</h2>
        <p>Help is built into HIT, so you rarely need this website:</p>
        <div class="table-wrap"><table class="table">
          <thead><tr><th style="width:40%">Type</th><th>To get</th></tr></thead>
          <tbody>
            <tr><td><code>hit help</code></td><td>The list of commands</td></tr>
            <tr><td><code>hit &lt;command&gt; --help</code></td><td>Every option of one command</td></tr>
            <tr><td><code>hit explain &lt;command&gt;</code></td><td>What a command does, in plain words</td></tr>
            <tr><td><code>hit why</code></td><td>An explanation of the last error</td></tr>
            <tr><td><code>hit help me</code></td><td>A menu of common tasks</td></tr>
          </tbody>
        </table></div>
        <p style="margin-top:16px">The full list is in the <a href="commands.html">command reference</a>.</p>
      </section>

      <section id="dashboard">
        <h2>Dashboard</h2>
        <p><code>hit ui</code> opens a full-screen dashboard in your terminal. Inside a project it opens that project; <code>hit ui all</code> starts at the list of every project on your PC. It refreshes by itself when you commit from another window.</p>
        <div class="shot" style="margin:0 0 20px"><img src="images/dashboard.svg" width="1300" height="780" loading="lazy" alt="HIT dashboard showing branches, commits, files and a line diff"></div>
        <div class="table-wrap"><table class="table">
          <thead><tr><th style="width:22%">Key</th><th>Inside a project</th></tr></thead>
          <tbody>
            <tr><td><code>c</code></td><td>Commit everything (asks for a message)</td></tr>
            <tr><td><code>d</code></td><td>Delete what is selected &mdash; a file (stop tracking, or purge from history), a commit, or a branch</td></tr>
            <tr><td><code>u</code></td><td>Undo the last action</td></tr>
            <tr><td><code>p</code> / <code>l</code></td><td>Push to / pull from GitHub</td></tr>
            <tr><td><code>b</code></td><td>New branch</td></tr>
            <tr><td><code>s</code></td><td>Snapshot the whole history</td></tr>
            <tr><td><code>o</code></td><td>Open the project on GitHub</td></tr>
            <tr><td><code>r</code></td><td>Refresh now</td></tr>
            <tr><td><code>/</code></td><td>Type a command or plain English</td></tr>
            <tr><td><code>Esc</code></td><td>Back to all projects</td></tr>
            <tr><td><code>?</code></td><td>All keys</td></tr>
          </tbody>
        </table></div>
        <p style="margin-top:16px">On the project list: <code>f</code> finds every Git project on your PC, <code>g</code> downloads a project from GitHub, <code>d</code> removes a project (a backup is kept).</p>
      </section>

      <section id="github">
        <h2>GitHub</h2>
        <ol>
          <li>Create an empty repository on github.com.</li>
          <li>Create a token: GitHub &rarr; Settings &rarr; Developer settings &rarr; Personal access tokens &rarr; <b>Tokens (classic)</b> &rarr; Generate new token &rarr; tick <b>repo</b>. Copy it; GitHub shows it only once.</li>
          <li>In your project run <code>hit push to github</code>. Paste the repository address when asked, then your username and the token.</li>
        </ol>
        <p>After that, <code>hit push</code> and <code>hit pull</code> need nothing else. The token is stored only on your computer and sent only to GitHub. <code>hit logout</code> removes it.</p>
        <p><code>hit status</code> and the dashboard show whether your latest commit is on GitHub, with a link to it.</p>
      </section>

      <section id="existing">
        <h2>Existing Git projects</h2>
        <p>HIT opens folders that already use Git directly &mdash; nothing is converted or copied. To see all of them in the dashboard:</p>
        <pre class="block">hit scan          # finds every Git project on your PC
hit ui all        # lists them, most recently used first</pre>
        <p>You can keep using <code>git</code>, VS Code or GitHub Desktop on the same project. Commits made with either program are visible in both.</p>
      </section>

      <section id="updates">
        <h2>Updating HIT</h2>
        <p>You never need to download HIT again after installing it once:</p>
        {codeline("doc-update", "hit update")}
        <p><code>hit update</code> shows what&rsquo;s new, downloads the new version, verifies its SHA-256 checksum and replaces the old one. <code>hit update --check</code> only looks. In plain English: <code>hit check for updates</code>.</p>
        <h3>Daily reminder</h3>
        <p>Once a day, in the background, HIT checks whether a newer version exists. If one does, you see one line after a command:</p>
        <pre class="block">  HIT 0.4.1 is available  (you have {__version__})  -  run `hit update`</pre>
        <p>The check never slows a command down, is silent when you are offline, and sends no files or personal data &mdash; see <a href="privacy.html">Privacy</a>. Turn it off or on with:</p>
        <pre class="block">hit config update.check false
hit config update.check true</pre>
      </section>

      <section id="files">
        <h2>Files and folders</h2>
        <div class="table-wrap"><table class="table">
          <thead><tr><th style="width:44%">Where</th><th>What it is</th></tr></thead>
          <tbody>
            <tr><td><code>your-project\\.hit\\</code></td><td>The project&rsquo;s history, in standard Git format</td></tr>
            <tr><td><code>your-project\\.hit\\hit\\</code></td><td>Undo journal, snapshots and automatic backups</td></tr>
            <tr><td><code>your-project\\.hitignore</code></td><td>Files HIT should never track (same rules as .gitignore, which is also honoured)</td></tr>
            <tr><td><code>%USERPROFILE%\\.hitconfig</code></td><td>Your name, email and settings</td></tr>
            <tr><td><code>%USERPROFILE%\\.hit\\</code></td><td>Project list, saved GitHub login, update status, and backups of removed histories</td></tr>
            <tr><td><code>%LOCALAPPDATA%\\HIT\\bin\\hit.exe</code></td><td>The installed program</td></tr>
          </tbody>
        </table></div>
      </section>

      <section id="faq">
        <h2>FAQ</h2>
        <div class="faq">
          <details><summary>&ldquo;hit is not recognized&rdquo; after installing</summary>
            <div>Open a <b>new</b> terminal window &mdash; existing windows don&rsquo;t see the updated PATH. If it still fails, run <code>.\\hit.exe setup</code> in the folder where you downloaded HIT.</div></details>
          <details><summary>Why does Windows warn me when I open hit.exe?</summary>
            <div>Windows SmartScreen warns about programs it hasn&rsquo;t seen many times and programs without a paid code-signing certificate. HIT is new and not signed yet. Every release publishes its SHA-256 checksum; see <a href="download.html#verify">Verify your download</a>.</div></details>
          <details><summary>&ldquo;nothing to push yet&rdquo;</summary>
            <div>You haven&rsquo;t committed. HIT offers to commit for you first, or run <code>hit save my work as &hellip;</code>.</div></details>
          <details><summary>&ldquo;GitHub rejected your credentials&rdquo;</summary>
            <div>The token is wrong, expired, or belongs to an account that can&rsquo;t write to that repository. Run <code>hit logout</code>, then <code>hit login</code> with a new classic token that has the <b>repo</b> scope.</div></details>
          <details><summary>&ldquo;remote has commits you don&rsquo;t have&rdquo;</summary>
            <div>Someone pushed since you last pulled. Run <code>hit pull</code>, then <code>hit push</code>.</div></details>
          <details><summary>I committed but the dashboard doesn&rsquo;t show it</summary>
            <div>It refreshes within a couple of seconds; press <code>r</code> to refresh now. Commits from all branches are listed.</div></details>
          <details><summary>Is HIT free? Can I use it on commercial projects?</summary>
            <div>Yes. HIT is free to use and you can manage any project with it, including commercial ones, and everything you create with it is yours. Selling or redistributing HIT itself needs permission. See the <a href="license.html">license agreement</a>.</div></details>
          <details><summary>Does it work on macOS or Linux?</summary>
            <div>The download is for Windows 10 and 11 (64-bit). macOS and Linux versions are planned.</div></details>
          <details><summary>Where do I report a problem?</summary>
            <div>On the <a href="{ISSUES}">issues page</a>, or by email to <a href="mailto:{EMAIL}">{EMAIL}</a>. Include the output of <code>hit version</code>.</div></details>
        </div>
      </section>"""
    # Old single-page links (documents.html#commands etc.) go to their new pages.
    redirect = """
  <script>(function(){var m={install:"download.html#install",english:"examples.html#phrasebook",commands:"commands.html","git-flags":"commands.html#git-flags",license:"license.html",overview:"documents.html"};var h=location.hash.slice(1);if(m[h])location.replace(m[h]);})();</script>"""
    body = page_head("Documentation", "Learn HIT",
                     f"Everything from your first commit to working with GitHub. Describes version {e(__version__)}.") \
        + "\n" + with_sidebar("On this page", items, content)
    return layout("docs", "Documentation — HIT",
                  "How to use HIT: getting started, core concepts, the dashboard, GitHub, updates and answers to "
                  "common questions.", body, head=redirect)


# ---------------------------------------------------------------- commands
GROUPS = [
    ("start", "Start and save", ["init", "add", "unstage", "status", "diff", "commit", "log", "show", "files"]),
    ("branches", "Branches and merging", ["branch", "switch", "checkout", "merge", "tag", "cherry-pick", "revert"]),
    ("undo", "Undo and safety", ["undo", "redo", "reset", "stash", "snapshot", "restore"]),
    ("cleanup", "Clean-up", ["rm", "mv", "clean", "ignore", "purge", "drop", "squash", "wipe"]),
    ("github", "GitHub", ["remote", "login", "logout", "push", "pull", "fetch", "clone"]),
    ("projects", "Projects and dashboard", ["ui", "projects", "scan", "import", "uninit", "export-git"]),
    ("inspect", "Inspect and maintain", ["blame", "ls-files", "ls-tree", "rev-parse", "describe", "shortlog",
                                         "count-objects", "gc", "fsck"]),
    ("settings", "Help and settings", ["help", "explain", "why", "config", "update", "setup", "version"]),
]
DANGEROUS = {"purge", "drop", "squash", "wipe", "restore", "uninit", "reset"}


def _commands() -> dict[str, tuple[str, list[str]]]:
    """name -> (help text, aliases) straight from the real parser."""
    sub = _PARSER._subparsers._group_actions[0]          # noqa: SLF001
    helps = {a.dest: (a.help or "") for a in sub._choices_actions}   # noqa: SLF001
    out: dict[str, tuple[str, list[str]]] = {}
    seen: dict[int, str] = {}
    for name, p in sub.choices.items():
        if id(p) in seen:
            out[seen[id(p)]][1].append(name)
            continue
        seen[id(p)] = name
        out[name] = (helps.get(name, ""), [])
    return out


def commands() -> str:
    cmds = _commands()
    placed = {c for _, _, names in GROUPS for c in names}
    groups = list(GROUPS)
    rest = sorted(c for c in cmds if c not in placed)
    if rest:
        groups.append(("other", "Other", rest))
    parts, rows_all = [], 0
    for gid, title, names in groups:
        rows = []
        for n in names:
            if n not in cmds:
                continue
            text, aliases = cmds[n]
            star = ' <span class="warn" title="Asks first, backs up, can be undone">*</span>' if n in DANGEROUS else ""
            alias = (f'<div class="aliases">also: {", ".join(f"<code>{e(a)}</code>" for a in aliases)}</div>'
                     if aliases else "")
            rows.append(f"<tr><td><code>hit {e(n)}</code>{star}</td><td>{e(text[:1].upper() + text[1:])}.{alias}</td></tr>")
        rows_all += len(rows)
        parts.append(f'      <section id="{gid}">\n        <h2>{e(title)}</h2>\n'
                     f'        <div class="table-wrap"><table class="table cmd-table">'
                     f'<thead><tr><th style="width:36%">Command</th><th>What it does</th></tr></thead>'
                     f'<tbody>{"".join(rows)}</tbody></table></div>\n      </section>')
    flags = """
      <section id="git-flags">
        <h2>Git flags</h2>
        <p>If you know Git, keep typing what you know. These all work in HIT:</p>
        <pre class="block">hit status -s                 hit add -A / -u
hit diff --stat / --staged    hit log --oneline --graph --all
hit commit -am "msg"          hit commit --amend
hit checkout -b feature       hit switch -
hit branch -v / -d / -m       hit merge --no-ff / --ff-only
hit tag -a v1.0 -m "msg"      hit tag -l
hit reset --soft / --hard     hit rm --cached file
hit restore file              hit restore --staged file
hit remote -v                 hit remote get-url / rename / remove
hit config --list / --global  hit show --stat HEAD</pre>
        <p><code>hit restore</code> understands both meanings: give it a file and it restores the file; give it a snapshot name and it restores the whole history.</p>
      </section>"""
    intro = f"""
      <input class="filter" type="search" placeholder="Search {rows_all} commands, e.g. branch, undo, push" aria-label="Search commands" data-filter=".cmd-table">
      <p class="note">Commands marked <span class="warn">*</span> ask first, take a backup, and can be undone with <code>hit undo</code>. Run <code>hit &lt;command&gt; --help</code> for every option.</p>"""
    items = [(gid, title) for gid, title, _ in groups] + [("git-flags", "Git flags")]
    body = page_head("Reference", "Command reference",
                     "Every HIT command, generated from the program itself. Prefer words? Every command can also be "
                     "typed in <a href=\"examples.html#phrasebook\">plain English</a>.") \
        + "\n" + with_sidebar("Groups", items, intro + "\n" + "\n".join(parts) + flags)
    return layout("commands", "Command reference — HIT",
                  "Every HIT command and the Git flags it understands: commit, branch, merge, undo, push, pull and more.",
                  body)


# ---------------------------------------------------------------- examples
RECIPES = [
    ("first", "Start a new project", "Track a folder and save its first version.",
     ["cd C:\\projects\\my-app", "hit init", "hit save everything as first version"]),
    ("daily", "Save your work", "See what changed, review it, then save.",
     ["hit status", "hit diff", 'hit commit -am "fixed the login redirect"']),
    ("branch", "Try an idea on a branch", "Work separately, then bring it back into main.",
     ["hit switch -c dark-mode", 'hit commit -am "dark mode colours"', "hit switch main", "hit merge dark-mode",
      "hit branch -d dark-mode"]),
    ("mistake", "Fix a mistake", "Reverse the last action, or put one file back.",
     ["hit undo", "hit redo", "hit restore src/app.py", "hit reset --soft HEAD~1"]),
    ("github", "Put a project on GitHub", "The first push asks for the address and a token, once.",
     ["hit push to github", "hit push", "hit pull"]),
    ("clone", "Get a project from GitHub", "Download a repository with its whole history.",
     ["hit clone https://github.com/owner/project.git"]),
    ("stash", "Put work aside", "Switch tasks without committing half-done work.",
     ["hit stash", "hit switch main", "hit stash pop"]),
    ("secret", "Remove a leaked password", "Erase a file from every commit. Asks first, backs up, can be undone.",
     ["hit purge secrets.env", "hit ignore secrets.env"]),
    ("history", "Look through history", "Who changed what, and when.",
     ["hit log --oneline --graph --all", "hit show HEAD", "hit blame src/app.py"]),
    ("release", "Mark a release", "Name the current commit so you can find it later.",
     ['hit tag -a v1.0 -m "first public version"', "hit push"]),
    ("backup", "Back up the whole history", "Save every commit into one file and bring it back later.",
     ["hit snapshot", "hit snapshot list"]),
    ("projects", "See all your projects", "Find every Git project on your PC and open the dashboard.",
     ["hit scan", "hit ui all"]),
]


def examples() -> str:
    cards = []
    for rid, title, desc, lines in RECIPES:
        for ln in lines:
            if ln.startswith("hit "):
                check_command(ln)
        code = "\n".join(e(ln) for ln in lines)
        cards.append(f"""        <article class="recipe" id="{rid}">
          <h3>{e(title)}</h3>
          <p>{e(desc)}</p>
          <div class="snippet"><pre id="r-{rid}">{code}</pre><button class="copy" type="button" data-copy="#r-{rid}">Copy</button></div>
        </article>""")

    # Phrasebook: every example sentence, run through the real English parser.
    order = ["init", "status", "diff", "add", "commit", "amend", "log", "files", "undo", "redo", "uncommit",
             "discard", "restore_file", "branch_create", "branch_list", "switch", "merge", "merge_continue",
             "merge_abort", "branch_rename", "branch_delete", "tag", "stash", "stash_pop", "push", "pull",
             "clone", "remote_add", "remote_list", "login", "ignore", "rm", "purge", "squash", "wipe",
             "snapshot", "snapshot_list", "restore_snapshot", "ui", "projects", "scan", "import",
             "self_update", "config_user", "config_email", "help", "explain", "why"]
    rank = {n: i for i, n in enumerate(order)}
    rows, seen = [], set()
    for intent in sorted(INTENTS, key=lambda it: rank.get(it.name, len(rank))):
        for ex in intent.examples:
            if ex in seen:
                continue
            seen.add(ex)
            p = parse(ex)
            if not p.commands:
                continue
            rows.append(f"<tr><td>hit {e(ex)}</td><td><code>{e(p.pretty())}</code></td><td>{e(intent.explain)}</td></tr>")

    body = f"""{page_head("Examples", "Examples and snippets", "Copy-ready commands for everyday tasks. Each one is checked against HIT itself when this page is built, so they always work.")}

  <section class="block" style="padding-top:48px">
    <div class="container">
      <div class="recipes">
{chr(10).join(cards)}
      </div>
    </div>
  </section>

  <section class="block tint" id="phrasebook">
    <div class="container">
      <div class="section-head">
        <div class="eyebrow">Phrasebook</div>
        <h2>Plain English HIT understands.</h2>
        <p>If the first word isn&rsquo;t a command, HIT reads the whole line as English, shows the exact command and asks before running it. Every row below is produced by HIT&rsquo;s own parser &mdash; {len(rows)} phrases.</p>
      </div>
      <input class="filter" type="search" placeholder="Filter phrases, e.g. branch, undo, github" aria-label="Filter phrasebook" data-filter="#phrasebook-table">
      <div class="table-wrap"><table class="table phrase-table" id="phrasebook-table"><thead><tr><th style="width:36%">You type</th><th style="width:32%">HIT runs</th><th>Meaning</th></tr></thead><tbody>{"".join(rows)}</tbody></table></div>
    </div>
  </section>

{cta_band()}"""
    return layout("examples", "Examples — HIT",
                  "Copy-ready HIT commands for everyday tasks, and the full plain English phrasebook.", body)


# ---------------------------------------------------------------- releases
def releases() -> str:
    entries = []
    for i, rel in enumerate(CHANGELOG):
        v = rel["version"]
        notes = "\n".join(f"            <li>{md(n)}</li>" for n in rel["notes"])
        if v == LATEST["version"]:
            action = (f'<div class="rel-actions"><a class="btn btn-primary btn-sm" href="{DL}">Download {e(v)}</a>'
                      f'<a class="btn btn-outline btn-sm" href="{GH_RELEASES}/tag/v{e(v)}">Checksums</a></div>')
            badge = '<span class="badge">Latest</span>'
        else:
            action, badge = "", ""
        entries.append(f"""        <article class="release" id="v{e(v)}">
          <div class="rel-side">
            <div class="rel-version">{e(v)} {badge}</div>
            <time datetime="{e(rel['date'])}">{e(rel['date'])}</time>
          </div>
          <div class="rel-body">
            <h2>{e(rel['title'])}</h2>
            <ul>
{notes}
            </ul>
            {action}
          </div>
        </article>""")
    extra = f"""
      <div class="cta-row" style="margin-top:24px">
        <a class="btn btn-primary" href="{DL}">{DOWNLOAD_ICON} Download {e(LATEST['version'])}</a>
      </div>"""
    body = f"""{page_head("Releases", "Release notes", "What changed in each version of HIT. Already installed? Run <code>hit update</code> &mdash; you&rsquo;ll get everything below automatically.", extra)}

  <section class="block" style="padding-top:24px">
    <div class="container">
      <div class="releases">
{chr(10).join(entries)}
      </div>
      <p class="caption">Every published file and its SHA-256 checksum are on the <a href="{GH_RELEASES}">GitHub releases page</a>.</p>
    </div>
  </section>"""
    return layout("releases", "Release notes — HIT",
                  f"What's new in HIT {LATEST['version']} and every earlier version.", body)


# ---------------------------------------------------------------- privacy
def privacy() -> str:
    body = f"""{page_head("Privacy", "What HIT sends over the internet", "Your code stays on your computer. This page is the complete list of times HIT connects to anything.")}

  <section class="block" style="padding-top:48px">
    <div class="container narrow">
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>When</th><th>Where to</th><th>What is sent</th></tr></thead>
          <tbody>
            <tr><td>You run <code>hit push</code>, <code>pull</code>, <code>fetch</code> or <code>clone</code></td><td>GitHub (or the server you chose)</td><td>Your commits &mdash; only when you ask.</td></tr>
            <tr><td>Once a day, in the background</td><td>hitvcs.vercel.app</td><td>A request for the newest version number. No files, no project names, no personal data.</td></tr>
            <tr><td>You run <code>hit update</code></td><td>GitHub releases</td><td>Downloads the new <code>hit.exe</code> and checks its SHA-256 checksum.</td></tr>
            <tr><td>Everything else</td><td>&mdash;</td><td>Nothing. HIT works fully offline.</td></tr>
          </tbody>
        </table>
      </div>

      <div class="prose">
        <h2>What HIT does not do</h2>
        <ul>
          <li>No account, sign-up or email address is needed.</li>
          <li>No analytics, usage tracking or crash reports are sent.</li>
          <li>Your GitHub token is stored only on your computer and sent only to GitHub.</li>
        </ul>
        <h2>Turning off the update check</h2>
        <p>The daily version check can be switched off at any time:</p>
        {codeline("off", "hit config update.check false")}
        <p>Setting the environment variable <code>HIT_NO_UPDATE_CHECK=1</code> also turns it off.</p>
        <h2>This website</h2>
        <p>This website uses no cookies and no analytics. It is hosted on Vercel, which keeps standard server logs. Fonts are loaded from Google Fonts.</p>
        <h2>Questions</h2>
        <p>Write to <a href="mailto:{EMAIL}">{EMAIL}</a>.</p>
      </div>
    </div>
  </section>"""
    return layout("privacy", "Privacy — HIT",
                  "HIT works offline. The complete list of times it connects to the internet, and what it sends.", body)


# ---------------------------------------------------------------- license
def license_page() -> str:
    text = (ROOT / "LICENSE").read_text(encoding="utf-8").strip()
    body = f"""{page_head("Legal", "License agreement", "HIT is free to use, including on commercial projects. It is not open source: HIT itself may not be sold, redistributed, modified or reverse-engineered without written permission. Everything you create with HIT belongs to you.")}

  <section class="block" style="padding-top:48px">
    <div class="container narrow">
      <div class="summary">
        <div><h3>You may</h3><ul><li>Use HIT free of charge on your own computers</li><li>Manage any project with it, including commercial ones</li><li>Keep everything you create with it</li><li>Share the official download link</li></ul></div>
        <div><h3>You may not, without permission</h3><ul><li>Sell HIT or include it in a paid product or service</li><li>Copy or redistribute hit.exe itself</li><li>Modify, decompile or reverse-engineer it</li><li>Remove its name, branding or copyright notices</li></ul></div>
      </div>
      <p class="note">This summary is for convenience. The agreement below is what applies. For permission, write to <a href="mailto:{EMAIL}">{EMAIL}</a>.</p>
      <div class="license-text">{e(text)}</div>
    </div>
  </section>"""
    return layout("license", "License agreement — HIT",
                  "The HIT end-user license agreement: free to use, including commercial projects.", body)


PAGES = {
    "index.html": home, "download.html": download, "documents.html": documents, "commands.html": commands,
    "examples.html": examples, "releases.html": releases, "privacy.html": privacy, "license.html": license_page,
}


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.parse_args()
    for name, build in PAGES.items():
        (SITE / name).write_text(build(), encoding="utf-8")
        print(f"wrote website/{name}")


if __name__ == "__main__":
    main()
