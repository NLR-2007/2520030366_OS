"""Build a single-file hit.exe (Windows) / hit binary (Linux, macOS) with PyInstaller.

    pip install pyinstaller
    python build_exe.py          -> dist/hit.exe

Users then just copy hit.exe somewhere on their PATH. No Python needed.
On Windows the exe gets the HIT logo as its icon (hit/hit.ico) and version
details (Properties -> Details, Task Manager).
"""
import re
import subprocess
import sys
from pathlib import Path

root = Path(__file__).parent
version = re.search(r'__version__ = "([^"]+)"', (root / "hit" / "__init__.py").read_text()).group(1)
nums = tuple(int(n) for n in version.split(".")) + (0,) * (4 - len(version.split(".")))

VERSION_INFO = f"""VSVersionInfo(
  ffi=FixedFileInfo(filevers={nums}, prodvers={nums}, mask=0x3f, flags=0x0, OS=0x40004,
                    fileType=0x1, subtype=0x0, date=(0, 0)),
  kids=[
    StringFileInfo([StringTable('040904B0', [
      StringStruct('CompanyName', 'NLR Group of Companies'),
      StringStruct('FileDescription', 'HIT Version Control'),
      StringStruct('FileVersion', '{version}'),
      StringStruct('InternalName', 'hit'),
      StringStruct('LegalCopyright', '(c) 2026 NLR Group of Companies. All rights reserved.'),
      StringStruct('OriginalFilename', 'hit.exe'),
      StringStruct('ProductName', 'HIT - Version Control System'),
      StringStruct('ProductVersion', '{version}')])]),
    VarFileInfo([VarStruct('Translation', [1033, 1200])])
  ]
)
"""

cmd = [
    sys.executable, "-m", "PyInstaller",
    "--onefile", "--name", "hit", "--console", "--clean", "--noconfirm",
    "--collect-all", "textual",      # Textual ships .tcss/.css data files
    "--collect-all", "dulwich",
    "--hidden-import", "hit.ui.app",
]
if sys.platform == "win32":
    version_file = root / "build" / "version_info.txt"
    version_file.parent.mkdir(exist_ok=True)
    version_file.write_text(VERSION_INFO, encoding="utf-8")
    cmd += ["--icon", str(root / "hit" / "hit.ico"), "--version-file", str(version_file)]
cmd.append(str(root / "hit_entry.py"))
print(" ".join(cmd))
sys.exit(subprocess.call(cmd, cwd=root))
