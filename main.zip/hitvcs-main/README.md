# HIT — version control that speaks English

HIT is a local-first, **Git-compatible** version control system built for people who
find Git hard to remember. Every Git-style command is there, plus:

- **Plain English commands** — `hit save my work as fixed login`, `hit undo`, `hit send my code to github`.
  HIT shows the exact command it will run and asks before running it, so you learn as you go.
- **`hit undo`** — reverses *any* action: commit, merge, reset, purge, restore, branch delete.
- **Terminal dashboard** (`hit ui`) — see every HIT project on your computer, drill into commits,
  browse the files in each commit, delete what you don't need, snapshot, push.
- **`hit files`** — list every file inside any commit with added/modified/deleted markers.
- **`hit purge`** — erase a file from *all* history (leaked secret, giant binary), with automatic backup.
- **`hit snapshot` / `hit restore`** — save the whole repository history into one file and bring it back later.
- **100% offline** — the network is touched only when *you* run `push`, `pull`, `fetch` or `clone`.
- **Works with GitHub** — `.hit/` is a real Git repository on disk, so `hit push` talks to GitHub
  natively (no `git` binary needed), and Git tools can read a HIT repo.

## Install

**Option A — you have Python 3.10+** (Windows / macOS / Linux):
```bash
pip install git+https://github.com/NLR-2007/hitvcs.git
hit version
```
(or, once published: `pip install hit-vcs`)

**Option B — no Python needed (Windows):** paste this into PowerShell:
```powershell
irm https://raw.githubusercontent.com/NLR-2007/hitvcs/main/install.ps1 | iex
```
It downloads the latest `hit.exe`, puts it in `%LOCALAPPDATA%\HITin` and adds that to your PATH.
Open a **new** terminal and run `hit version`.

**Or download directly:** [hit.exe](https://github.com/NLR-2007/hitvcs/releases/latest/download/hit.exe) (33 MB) — then run `.\hit.exe setup` once in that folder.
If Windows shows *"Windows protected your PC"*, click **More info → Run anyway** (HIT is not code-signed yet;
the PowerShell one-liner above doesn't trigger this warning).

**From source (developers):**
```bash
git clone https://github.com/NLR-2007/hitvcs.git && cd HIT-VCS
pip install -e .[dev]
pytest
```

**Build the standalone exe yourself:** `pip install pyinstaller && python build_exe.py` → `dist/hit.exe` (~33 MB).

Requires Python 3.10+. Dependencies: [Dulwich](https://www.dulwich.io/) (Git protocol) and
[Textual](https://textual.textualize.io/) (terminal UI). Optional: `pip install keyring` to keep
your GitHub token in the OS keychain.

## Two minutes with HIT

```text
$ hit init --template python
✓ started a HIT repository in /home/you/myapp

$ hit save my work as first version
→ Save a checkpoint of your work (stage everything + commit)
  hit add .  &&  hit commit -m "first version"
Run this? [Y/n]
✓ [main 0fcf4f0] first version   (12 files tracked)

$ hit what changed                 # → hit status
$ hit show history                 # → hit log
$ hit show files in last commit    # → hit files
$ hit make a new branch called dark-mode
$ hit merge dark-mode
$ hit oops                         # → hit undo
$ hit send my code to github       # → hit push (asks for the URL + token the first time)
$ hit ui                           # the dashboard
```

If HIT isn't sure what you meant, it offers alternatives. Typos like `hit comit` get a
"did you mean" prompt. `hit help me` gives you a numbered menu. `hit explain merge` explains
any command; `hit why` explains the last error.

## Commands

| Area | Commands |
|---|---|
| Core | `init` `add` `unstage` `status` `diff` `commit` `log` `show` `branch` `switch` `checkout` `merge` `tag` `reset` `stash` `ignore` |
| Files & history | `files` `ls-files` `ls-tree` `blame` `rm` `mv` `clean` `purge` `drop` `squash` `wipe` `revert` `cherry-pick` |
| Safety | `undo` `redo` `snapshot` `restore` |
| GitHub | `remote` `login` `logout` `push` `pull` `fetch` `clone` |
| Inspect | `rev-parse` `describe` `shortlog` `count-objects` `whatchanged` |
| Maintenance | `gc` `fsck` |
| Beginner layer | `hit <plain english>` `help me` `explain` `why` |
| Machine | `projects` `scan` `import` `ui` `config` `setup` `export-git` |

**Git flags work too** — `status -s`, `add -A/-u`, `diff --stat`, `log --oneline --graph`,
`branch -v`, `checkout -b`, `switch -`, `merge --no-ff`, `tag -a -m`, `commit -am/--amend`,
`reset --soft/--hard`, `rm --cached`, `restore <file>/--staged/--source`,
`remote -v/get-url/rename`, `config --list/--global/--unset`.

`hit <command> --help` shows the flags. Every destructive command (purge, restore, reset --hard,
drop, squash, branch delete) confirms first, backs up first, and is undoable.

## The dashboard (`hit ui`)

```
┌ Branches ──┬ Commits ───────────────────────┬ Files in a1b2c3 ──────────┐
│ * main     │ a1b2c3  fixed login    2h ago  │ ▼ src/                     │
│   dark     │ 9f8e7d  add navbar     1d ago  │     M auth.py     1.2 KB   │
│            │ 55aa11  initial        3d ago  │     A nav.py      0.8 KB   │
│            │                                │ D old.txt                  │
├────────────┴────────────────────────────────┴────────────────────────────┤
│ diff / file preview                                                      │
├──────────────────────────────────────────────────────────────────────────┤
│ > save my work as fixed login_                                           │
└──────────────────────────────────────────────────────────────────────────┘
 Enter open · d delete · D purge · u undo · c commit · s snapshot · p push
```

Run `hit ui` anywhere to see **all your HIT projects**; inside a repo it opens that project.
`d` on a file asks: stop tracking, delete from disk, or purge from all history.
`d` on a commit: uncommit (keep changes) or drop it. `d` on a project: remove from list,
delete history, or delete the folder — a backup goes to `~/.hit/trash` first.

## Where things live

```
myproject/.hit/          Git-compatible repository (objects, refs, index, config)
myproject/.hit/hit/      HIT-only: undo journal, snapshots, auto-backups, stash
~/.hitconfig             your name/email
~/.hit/projects.json     list of your HIT projects (for `hit projects` and the dashboard)
~/.hit/credentials.json  GitHub token (or the OS keyring if `keyring` is installed)
```

## GitHub

1. Create an empty repository on github.com.
2. `hit push` — HIT asks for the URL (you can type `user/repo`) and, once, a
   [personal access token](https://github.com/settings/tokens) with the `repo` scope.
3. That's it. `hit pull` gets changes back; `hit clone user/repo` downloads a repo.

Because `.hit/` uses Git's format, `git --git-dir=.hit log` works, and `hit export-git`
creates a `.git` folder so VS Code / GitHub Desktop can open the project too.

## Development

```bash
pip install -e .[dev]
pytest                    # 23 end-to-end tests, incl. Git interop, push/pull, the full command surface and a 1,500-file repo
```

Layout: `hit/objects.py` (object store) · `index.py` · `refs.py` · `repo.py` (core) ·
`diff.py` · `merge.py` · `journal.py` (undo) · `snapshot.py` · `history.py` (purge/drop/squash) ·
`stash.py` · `remote.py` (Dulwich) · `registry.py` · `nl/` (English parser) · `cli.py` · `ui/` (Textual).

## License

Proprietary. HIT is distributed to users as `hit.exe` from https://github.com/NLR-2007/hit-releases
under the end-user license in [LICENSE](LICENSE). This source repository is private.

## Releasing

`python tools/release.py <version> "note" "note"` runs the tests, builds `hit.exe`, publishes it to
hit-releases, updates `website/latest.json` (read by every installed HIT's daily update check) and pushes.
