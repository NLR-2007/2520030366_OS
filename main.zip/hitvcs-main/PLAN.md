# HIT — Plan (v1, locked 2026-09-19)

**Pitch:** Git that speaks English and can't lose your work. Local-first, fully offline,
Git-compatible on disk, pushes to GitHub natively.

## Decisions
- Language: **Python 3.10+**. Deps: Dulwich (Git protocol), Textual (TUI). Everything else stdlib.
- Repo folder: `.hit/` in Git's exact format (SHA-1 objects, refs, index v2). HIT extras in `.hit/hit/`.
- Feature 4 ("saving all commits") = **`hit snapshot` / `hit restore`**: whole history → one file, and back.
- Offline: network only on explicit `push` / `pull` / `fetch` / `clone`. No LLM tier — the English
  layer is an offline intent table + fuzzy matching.
- License: MIT.

## Features (all implemented)
| Area | Commands |
|---|---|
| Core | init, add, unstage, status, diff, commit, log, branch, switch, checkout, merge, tag, reset, stash, ignore |
| New | files, rm, purge, drop, squash, snapshot, restore, undo, redo, projects, ui |
| GitHub | remote, login, logout, push, pull, fetch, clone |
| Beginner | plain-English input with confirm, did-you-mean, help me, explain, why |

## Safety rules
- Destructive commands (purge, drop, squash, restore, reset --hard, branch -d) always confirm,
  even with `--yes`; take an automatic backup snapshot; and are reversible with `hit undo`.
- The undo journal records ref + index state before/after every action (`.hit/hit/journal.json`).
- Checking out an old commit creates a branch — there is no detached HEAD footgun.

## Milestones
1. Object store + init/add/status/commit/log ✔
2. diff, branch, switch, checkout, merge (3-way + conflicts), tag, reset, stash, ignore ✔
3. journal/undo, files, rm, purge, drop, squash, snapshot/restore, project registry ✔
4. English layer + help me / explain / why / did-you-mean ✔
5. push/pull/fetch/clone via Dulwich ✔ (tested against a local bare Git repo)
6. `hit ui` Textual dashboard: projects → commits → files, delete flows, command bar ✔
7. Packaging: `pip install -e .` ✔ · single-file `.exe` via PyInstaller — **not done yet**

## Out of scope for v1
Submodules, interactive rebase, bisect, worktrees, hooks, LFS, shallow clones, delta-compressed
packfiles written by HIT (HIT writes loose objects; it *reads* packfiles).
