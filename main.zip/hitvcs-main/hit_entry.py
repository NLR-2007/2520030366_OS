"""Entry point for the standalone executable (PyInstaller needs a non-package script)."""
import sys
from hit.cli import main

if __name__ == "__main__":
    sys.exit(main())
