// HIT website: menu, copy buttons, table filter, docs navigation highlight.
(function () {
  "use strict";

  // Mobile menu
  var nav = document.getElementById("nav");
  var menu = document.querySelector(".menu-btn");
  if (nav && menu) {
    menu.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      menu.setAttribute("aria-expanded", open ? "true" : "false");
      menu.textContent = open ? "Close" : "Menu";
    });
    nav.querySelectorAll(".nav-links a").forEach(function (a) {
      a.addEventListener("click", function () {
        nav.classList.remove("open");
        menu.setAttribute("aria-expanded", "false");
        menu.textContent = "Menu";
      });
    });
  }

  // Copy buttons: <button class="copy" data-copy="#id">
  document.querySelectorAll("[data-copy]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var el = document.querySelector(btn.getAttribute("data-copy"));
      if (!el) return;
      var text = el.textContent.trim();
      var done = function () {
        var old = btn.textContent;
        btn.textContent = "Copied";
        setTimeout(function () { btn.textContent = old; }, 1600);
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(done, function () { select(el); });
      } else {
        select(el);
      }
    });
  });
  function select(el) {
    var range = document.createRange();
    range.selectNodeContents(el);
    var sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
  }

  // Table filter: <input class="filter" data-filter="#table-id or .table-class">
  // Filters every matching table; a table left with no rows hides its section.
  document.querySelectorAll("[data-filter]").forEach(function (input) {
    var tables = Array.prototype.slice.call(document.querySelectorAll(input.getAttribute("data-filter")));
    if (!tables.length) return;
    input.addEventListener("input", function () {
      var q = input.value.trim().toLowerCase();
      tables.forEach(function (table) {
        var shown = 0;
        table.querySelectorAll("tbody tr").forEach(function (r) {
          var hit = !q || r.textContent.toLowerCase().indexOf(q) !== -1;
          r.style.display = hit ? "" : "none";
          if (hit) shown++;
        });
        var section = tables.length > 1 ? table.closest("section") : null;
        if (section) section.style.display = shown ? "" : "none";
      });
    });
  });

  // Docs: highlight the section currently on screen
  var links = document.querySelectorAll(".docs-nav a[href^='#']");
  if (links.length && "IntersectionObserver" in window) {
    var byId = {};
    links.forEach(function (a) { byId[a.getAttribute("href").slice(1)] = a; });
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting && byId[e.target.id]) {
          links.forEach(function (a) { a.classList.remove("active"); });
          byId[e.target.id].classList.add("active");
        }
      });
    }, { rootMargin: "-20% 0px -70% 0px" });
    Object.keys(byId).forEach(function (id) {
      var s = document.getElementById(id);
      if (s) observer.observe(s);
    });
  }
})();
