"""Tests for the update system (hit/updater.py), against a local HTTP server."""
import hashlib
import http.server
import json
import os
import sys
import threading
import time
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


@pytest.fixture
def server(tmp_path, monkeypatch):
    """Serve tmp_path/www over HTTP and point HIT's update URL at it."""
    www = tmp_path / "www"
    www.mkdir()
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    monkeypatch.setenv("USERPROFILE", str(home))
    monkeypatch.delenv("HIT_NO_UPDATE_CHECK", raising=False)

    class Handler(http.server.SimpleHTTPRequestHandler):
        def __init__(self, *a, **kw):
            super().__init__(*a, directory=str(www), **kw)

        def log_message(self, *a):
            pass

    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{httpd.server_address[1]}"
    monkeypatch.setenv("HIT_UPDATE_URL", base + "/latest.json")
    yield www, base
    httpd.shutdown()


def publish(www: Path, base: str, version: str, payload: bytes, notes=None, sha=None):
    (www / "hit.exe").write_bytes(payload)
    (www / "latest.json").write_text(json.dumps({
        "version": version,
        "url": base + "/hit.exe",
        "sha256": sha or hashlib.sha256(payload).hexdigest(),
        "size": len(payload),
        "published": "2026-09-22",
        "notes": notes or ["Something new"],
    }))


def fresh_updater():
    import importlib
    import hit.updater as u
    return importlib.reload(u)


def test_version_compare():
    u = fresh_updater()
    assert u.is_newer("0.4.0", "0.3.9")
    assert u.is_newer("0.10.0", "0.9.9")          # numeric, not alphabetical
    assert u.is_newer("1.0", "0.99.99")
    assert not u.is_newer("0.3.1", "0.3.1")
    assert not u.is_newer("0.3.0", "0.3.1")
    assert u.parse_version("v0.4.1") == (0, 4, 1)


def test_fetch_latest_and_cache(server):
    www, base = server
    publish(www, base, "9.9.9", b"x" * 2_000_000, notes=["Faster push"])
    u = fresh_updater()
    rel = u.fetch_latest(timeout=5)
    assert rel.version == "9.9.9" and rel.notes == ["Faster push"]
    state = json.loads((Path(os.environ["HOME"]) / ".hit" / "update.json").read_text())
    assert state["latest"] == "9.9.9" and state["last_check"] > 0


def test_background_check_runs_once_a_day(server):
    www, base = server
    publish(www, base, "9.9.9", b"x" * 2_000_000)
    u = fresh_updater()
    u.start_background_check()
    u._bg.join(5)
    first = u._load_state()["last_check"]
    assert u._load_state()["latest"] == "9.9.9"
    u._bg = None
    u.start_background_check()                   # checked moments ago -> must not start again
    assert u._bg is None
    assert u._load_state()["last_check"] == first


def test_check_can_be_turned_off(server, monkeypatch):
    www, base = server
    publish(www, base, "9.9.9", b"x" * 2_000_000)
    monkeypatch.setenv("HIT_NO_UPDATE_CHECK", "1")
    u = fresh_updater()
    u.start_background_check()
    assert u._bg is None
    assert not u.checks_enabled()


def test_offline_is_silent(server, monkeypatch):
    monkeypatch.setenv("HIT_UPDATE_URL", "http://127.0.0.1:9/latest.json")   # nothing listens here
    u = fresh_updater()
    u.start_background_check()
    u._bg.join(10)
    state = u._load_state()
    assert state.get("last_check", 0) > 0          # recorded, so it won't retry until tomorrow
    assert "latest" not in state


def test_notice_once_a_day(server, monkeypatch, capsys):
    www, base = server
    publish(www, base, "9.9.9", b"x" * 2_000_000)
    u = fresh_updater()
    u.fetch_latest(timeout=5)
    monkeypatch.setattr(sys.stdout, "isatty", lambda: True)
    u.maybe_print_notice("status")
    assert "9.9.9 is available" in capsys.readouterr().out
    u.maybe_print_notice("status")                 # same day -> quiet
    assert "available" not in capsys.readouterr().out
    state = u._load_state(); state["last_notice"] = 0; u._save_state(state)
    u.maybe_print_notice("rev-parse")              # script-style command -> quiet
    assert "available" not in capsys.readouterr().out


def test_no_notice_when_up_to_date(server, monkeypatch, capsys):
    www, base = server
    from hit import __version__
    publish(www, base, __version__, b"x" * 2_000_000)
    u = fresh_updater()
    u.fetch_latest(timeout=5)
    monkeypatch.setattr(sys.stdout, "isatty", lambda: True)
    u.maybe_print_notice("status")
    assert "available" not in capsys.readouterr().out


def test_download_verifies_checksum(server):
    www, base = server
    payload = os.urandom(2_000_000)
    publish(www, base, "9.9.9", payload, sha="0" * 64)          # wrong checksum
    u = fresh_updater()
    rel = u.fetch_latest(timeout=5)
    with pytest.raises(ValueError, match="checksum"):
        u.download(rel)
    publish(www, base, "9.9.9", payload)                        # correct checksum
    rel = u.fetch_latest(timeout=5)
    assert u.download(rel) == payload


def test_replace_exe_swaps_and_keeps_backup(tmp_path):
    u = fresh_updater()
    exe = tmp_path / "hit.exe"
    exe.write_bytes(b"old version")
    backup = u.replace_exe(exe, b"new version")
    assert exe.read_bytes() == b"new version"
    assert backup.read_bytes() == b"old version"
    assert not (tmp_path / "hit.new.exe").exists()
    # a second update also works while an old backup is still lying around
    u.replace_exe(exe, b"newer version")
    assert exe.read_bytes() == b"newer version"
