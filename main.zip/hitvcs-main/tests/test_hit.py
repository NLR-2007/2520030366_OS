"""End-to-end tests for HIT. Run with: pytest"""
import os
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def repo(tmp_path, monkeypatch):
    monkeypatch.setenv("HIT_AUTHOR_NAME", "Tester")
    monkeypatch.setenv("HIT_AUTHOR_EMAIL", "t@example.com")
    monkeypatch.setenv("HIT_FORCE_YES", "1")
    monkeypatch.setenv("HIT_NO_UPDATE_CHECK", "1")
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    monkeypatch.setenv("USERPROFILE", str(tmp_path / "home"))
    (tmp_path / "home").mkdir()
    work = tmp_path / "work"
    work.mkdir()
    monkeypatch.chdir(work)
    return work


def hit(*args, cwd=None, check=True) -> str:
    env = dict(os.environ, PYTHONIOENCODING="utf-8", NO_COLOR="1")
    r = subprocess.run([sys.executable, "-m", "hit", *args], cwd=cwd, capture_output=True, text=True,
                       encoding="utf-8", env=env)
    if check and r.returncode != 0:
        raise AssertionError(f"hit {' '.join(args)} failed ({r.returncode}):\n{r.stdout}\n{r.stderr}")
    return r.stdout + r.stderr


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)


# --------------------------------------------------------------------------

def test_init_add_commit_log(repo):
    out = hit("init")
    assert "Repository ready" in out
    write(repo / "a.txt", "hello\n")
    write(repo / "src/b.py", "x = 1\n")
    hit("add", ".")
    out = hit("commit", "-m", "first")
    assert "first" in out
    out = hit("log", "--oneline")
    assert "first" in out
    out = hit("files")
    assert "a.txt" in out and "src/b.py" in out


def test_status_and_diff(repo):
    hit("init")
    write(repo / "a.txt", "one\n")
    hit("add", ".")
    hit("commit", "-m", "c1")
    write(repo / "a.txt", "two\n")
    out = hit("status")
    assert "Changed but not staged" in out and "a.txt" in out
    assert hit("status", "-s").strip() == "M a.txt"
    out = hit("diff")
    assert "-one" in out and "+two" in out


def test_english_commit(repo):
    hit("init")
    write(repo / "a.txt", "hi\n")
    out = hit("save", "my", "work", "as", "First Version")
    assert 'commit -m "First Version"' in out
    assert "First Version" in hit("log", "--oneline")


def test_ignore(repo):
    hit("init", "--template", "python")
    write(repo / "keep.py", "1")
    write(repo / "__pycache__/x.pyc", "1")
    write(repo / "debug.log", "1")
    hit("add", ".")
    out = hit("status")
    assert "keep.py" in out and "x.pyc" not in out and "debug.log" not in out


def test_branch_merge_fast_forward(repo):
    hit("init")
    write(repo / "a.txt", "base\n")
    hit("add", ".")
    hit("commit", "-m", "base")
    hit("switch", "-c", "feature")
    write(repo / "f.txt", "feature\n")
    hit("add", ".")
    hit("commit", "-m", "feat")
    hit("switch", "main")
    assert not (repo / "f.txt").exists()
    out = hit("merge", "feature")
    assert "Fast-forwarded" in out
    assert (repo / "f.txt").exists()


def test_merge_three_way_and_conflict(repo):
    hit("init")
    write(repo / "a.txt", "line1\nline2\nline3\n")
    hit("add", ".")
    hit("commit", "-m", "base")
    hit("switch", "-c", "b")
    write(repo / "a.txt", "line1\nline2\nline3-b\n")
    hit("commit", "-am", "b")
    hit("switch", "main")
    write(repo / "a.txt", "line1-main\nline2\nline3\n")
    hit("commit", "-am", "main")
    out = hit("merge", "b")
    assert "Merged" in out
    assert (repo / "a.txt").read_text() == "line1-main\nline2\nline3-b\n"
    # now a real conflict
    hit("switch", "-c", "c")
    write(repo / "a.txt", "C\nline2\nline3-b\n")
    hit("commit", "-am", "c")
    hit("switch", "main")
    write(repo / "a.txt", "MAIN\nline2\nline3-b\n")
    hit("commit", "-am", "main2")
    out = hit("merge", "c")
    assert "conflicts" in out
    text = (repo / "a.txt").read_text()
    assert "<<<<<<<" in text and ">>>>>>>" in text
    write(repo / "a.txt", "RESOLVED\nline2\nline3-b\n")
    hit("add", "a.txt")
    out = hit("merge", "--continue")
    assert "merge committed" in out


def test_undo_redo(repo):
    hit("init")
    write(repo / "a.txt", "1\n")
    hit("add", ".")
    hit("commit", "-m", "one")
    write(repo / "a.txt", "2\n")
    hit("commit", "-am", "two")
    assert "two" in hit("log", "--oneline")
    hit("undo")
    assert "two" not in hit("log", "--oneline")
    hit("redo")
    assert "two" in hit("log", "--oneline")


def test_reset_modes(repo):
    hit("init")
    write(repo / "a.txt", "1\n")
    hit("add", ".")
    hit("commit", "-m", "one")
    write(repo / "a.txt", "2\n")
    hit("commit", "-am", "two")
    hit("reset", "--soft", "HEAD~1")
    assert "Staged for the next commit" in hit("status")
    hit("reset", "--hard", "HEAD")
    assert (repo / "a.txt").read_text() == "1\n"


def test_stash(repo):
    hit("init")
    write(repo / "a.txt", "1\n")
    hit("add", ".")
    hit("commit", "-m", "one")
    write(repo / "a.txt", "wip\n")
    hit("stash")
    assert (repo / "a.txt").read_text() == "1\n"
    hit("stash", "pop")
    assert (repo / "a.txt").read_text() == "wip\n"


def test_rm_and_purge(repo):
    hit("init")
    write(repo / "secret.env", "TOKEN=1\n")
    write(repo / "a.txt", "a\n")
    hit("add", ".")
    hit("commit", "-m", "leak")
    write(repo / "a.txt", "b\n")
    hit("commit", "-am", "more")
    hit("purge", "secret.env")
    assert "secret.env" not in hit("files", "HEAD~1")
    assert "secret.env" not in hit("files")
    assert not (repo / "secret.env").exists()
    hit("undo")
    assert "secret.env" in hit("files", "HEAD~1")
    hit("rm", "--keep", "secret.env")
    hit("commit", "-m", "untrack")
    assert "D  secret.env" in hit("files")          # shown as deleted in this commit
    assert "secret.env" in hit("status")            # now untracked, but still on disk
    assert (repo / "secret.env").exists()


def test_snapshot_restore(repo):
    hit("init")
    write(repo / "a.txt", "1\n")
    hit("add", ".")
    hit("commit", "-m", "one")
    hit("snapshot", "point-a")
    write(repo / "a.txt", "2\n")
    hit("commit", "-am", "two")
    assert "two" in hit("log", "--oneline")
    hit("restore", "point-a")
    assert "two" not in hit("log", "--oneline")
    assert (repo / "a.txt").read_text() == "1\n"
    assert "point-a" in hit("snapshot", "list")


def test_tag_and_checkout_old_commit_creates_branch(repo):
    hit("init")
    write(repo / "a.txt", "1\n")
    hit("add", ".")
    hit("commit", "-m", "one")
    hit("tag", "v1")
    write(repo / "a.txt", "2\n")
    hit("commit", "-am", "two")
    out = hit("switch", "v1")
    assert "new branch" in out
    assert (repo / "a.txt").read_text() == "1\n"


def test_squash_and_drop(repo):
    hit("init")
    for i in range(3):
        write(repo / "a.txt", f"{i}\n")
        hit("add", ".")
        hit("commit", "-m", f"c{i}")
    hit("squash", "-n", "2", "-m", "squashed")
    log = hit("log", "--oneline")
    assert "squashed" in log and "c0" in log and "c1" not in log
    hit("drop", "HEAD")
    assert "squashed" not in hit("log", "--oneline")


def test_git_compatible(repo):
    if not shutil_which("git"):
        pytest.skip("git not installed")
    hit("init")
    write(repo / "a.txt", "1\n")
    write(repo / "d/b.txt", "2\n")
    hit("add", ".")
    hit("commit", "-m", "one")
    r = subprocess.run(["git", "--git-dir=.hit", "log", "--oneline"], cwd=repo, capture_output=True, text=True)
    assert r.returncode == 0 and "one" in r.stdout
    r = subprocess.run(["git", "--git-dir=.hit", "fsck"], cwd=repo, capture_output=True, text=True)
    assert r.returncode == 0, r.stderr


def test_push_pull_clone_local(repo, tmp_path):
    if not shutil_which("git"):
        pytest.skip("git not installed")
    bare = tmp_path / "remote.git"
    subprocess.run(["git", "init", "--bare", "-q", str(bare)], check=True)
    hit("init")
    write(repo / "a.txt", "1\n")
    hit("add", ".")
    hit("commit", "-m", "one")
    hit("remote", "add", "origin", str(bare))
    out = hit("push")
    assert "Push successful" in out
    clone_dir = tmp_path / "clone"
    hit("clone", str(bare), str(clone_dir), cwd=tmp_path)
    assert (clone_dir / "a.txt").read_text() == "1\n"
    write(clone_dir / "b.txt", "from clone\n")
    hit("add", ".", cwd=clone_dir)
    hit("commit", "-m", "two", cwd=clone_dir)
    hit("push", cwd=clone_dir)
    out = hit("pull")
    assert (repo / "b.txt").read_text() == "from clone\n"
    # diverged push is rejected
    write(repo / "c.txt", "c\n")
    hit("add", ".")
    hit("commit", "-m", "three")
    write(clone_dir / "d.txt", "d\n")
    hit("add", ".", cwd=clone_dir)
    hit("commit", "-m", "four", cwd=clone_dir)
    hit("push", cwd=clone_dir)
    out = hit("push", check=False)
    assert "you don't have" in out


def test_english_parser_table():
    from hit.nl import parse
    cases = {
        "what changed": [["status"]],
        "show history": [["log"]],
        "undo": [["undo"]],
        "save my changes as fixed login": [["add", "."], ["commit", "-m", "fixed login"]],
        "make a new branch called dark-mode": [["switch", "-c", "dark-mode"]],
        "switch to main": [["switch", "main"]],
        "merge dark-mode into main": [["merge", "dark-mode"]],
        "remove secrets.env from all history": [["purge", "secrets.env"]],
        "send my code to github": [["push"]],
        "show files in last commit": [["files"]],
        "tag this as v1.0": [["tag", "v1.0"]],
        "discard my changes": [["reset", "--hard", "HEAD"]],
        "undo my last commit": [["reset", "--soft", "HEAD~1"]],
    }
    for text, expected in cases.items():
        p = parse(text)
        assert p.commands == expected, f"{text!r} -> {p.commands}"
    assert parse("remove secrets.env from all history").danger
    assert parse("comit everything").intent.name == "commit"


def test_explain_and_why(repo):
    assert "checkpoint" in hit("explain", "commit").lower()
    hit("init")
    hit("commit", "-m", "x", check=False)  # nothing to commit -> error recorded
    assert "staged" in hit("why").lower()


def shutil_which(name):
    import shutil
    return shutil.which(name)


# --------------------------------------------------------------------------
# Git command compatibility — these must keep working.
# --------------------------------------------------------------------------

def test_git_command_surface(repo):
    """Every Git command form HIT advertises must run without an error."""
    hit("init")
    write(repo / "a.txt", "one\n")
    write(repo / "src/b.py", "x = 1\n")
    hit("add", ".")
    hit("commit", "-m", "first")

    # inspection
    assert "first" in hit("show")
    assert "a.txt" in hit("show", "--stat", "HEAD")
    assert "a.txt" in hit("show", "--name-only")
    assert "a.txt" in hit("ls-files")
    assert "src/b.py" in hit("ls-tree", "HEAD")
    assert len(hit("rev-parse", "HEAD").strip()) == 40
    assert "one" in hit("blame", "a.txt")   # blame prints each line with its commit
    assert "commit" in hit("shortlog").lower()
    assert "object" in hit("count-objects").lower()
    assert "a.txt" in hit("status", "-s") or hit("status", "-s").strip() == ""
    assert "first" in hit("whatchanged")

    # staging variants
    write(repo / "a.txt", "two\n")
    hit("add", "-u")
    hit("commit", "-m", "second")
    write(repo / "c.txt", "new\n")
    hit("add", "-A")
    hit("commit", "-m", "third")
    assert "c.txt" in hit("files")

    # branches
    hit("checkout", "-b", "feature")
    assert "feature" in hit("branch", "-v")
    hit("switch", "-")                       # back to the previous branch
    assert "* main" in hit("branch").replace("*  ", "* ")
    hit("switch", "feature")
    write(repo / "f.txt", "f\n")
    hit("add", ".")
    hit("commit", "-m", "on feature")
    hit("switch", "main")
    out = hit("merge", "--no-ff", "feature")
    assert "Merged" in out                   # --no-ff forces a merge commit
    assert len(hit("log", "--oneline").strip().splitlines()) == 5

    # tags
    hit("tag", "-a", "v1", "-m", "release one")
    assert "v1" in hit("tag", "-l")
    assert "v1" in hit("describe")

    # move / clean
    hit("mv", "c.txt", "renamed.txt")
    assert (repo / "renamed.txt").exists()
    hit("commit", "-am", "rename")
    write(repo / "junkfile.txt", "x\n")
    assert "junkfile.txt" in hit("clean", "-n")
    assert (repo / "junkfile.txt").exists()      # -n must not delete
    hit("clean", "-f")
    assert not (repo / "junkfile.txt").exists()

    # revert / cherry-pick
    head_before = hit("rev-parse", "HEAD").strip()
    hit("revert", "HEAD")
    assert hit("rev-parse", "HEAD").strip() != head_before
    assert "Revert" in hit("log", "--oneline")

    # restore a file, Git style
    write(repo / "a.txt", "broken\n")
    hit("restore", "a.txt")
    assert (repo / "a.txt").read_text() == "two\n"
    hit("add", "a.txt")
    hit("restore", "--staged", "a.txt")

    # remotes and config
    hit("remote", "add", "origin", "https://github.com/x/y.git")
    assert "origin" in hit("remote", "-v")
    assert "github.com" in hit("remote", "get-url", "origin")
    hit("remote", "rename", "origin", "upstream")
    assert "upstream" in hit("remote")
    hit("remote", "remove", "upstream")
    hit("config", "user.name", "Tester Two")
    assert "Tester Two" in hit("config", "user.name")
    assert "user" in hit("config", "--list").lower()

    # maintenance
    assert "healthy" in hit("fsck").lower()
    hit("gc")
    assert "healthy" in hit("fsck").lower()   # still intact after packing


def test_restore_file_vs_snapshot(repo):
    """`hit restore` must tell a file apart from a snapshot name."""
    hit("init")
    write(repo / "a.txt", "one\n")
    hit("add", ".")
    hit("commit", "-m", "one")
    hit("snapshot", "point-a")
    write(repo / "a.txt", "two\n")
    hit("commit", "-am", "two")

    write(repo / "a.txt", "scratch\n")
    hit("restore", "a.txt")                   # a path -> restore the file
    assert (repo / "a.txt").read_text() == "two\n"

    hit("restore", "point-a")                 # a snapshot name -> restore history
    assert "two" not in hit("log", "--oneline")


def test_english_still_routes_after_command_words(repo):
    """Command words followed by English must still be understood."""
    hit("init")
    write(repo / "a.txt", "one\n")
    hit("add", ".")
    hit("commit", "-m", "first")
    assert "first" in hit("show", "history")          # not `hit show <rev>`
    assert "a.txt" in hit("show", "files", "in", "last", "commit")
    assert "commit" in hit("show", "my", "branches").lower() or "branch" in hit("show", "my", "branches").lower()


# --------------------------------------------------------------------------
# Large repositories and timestamp races
# --------------------------------------------------------------------------

def test_same_size_edit_in_same_second_is_committed(repo):
    """Racy-clean regression: an edit to same-size content right after a commit
    must never be skipped as 'unchanged'."""
    hit("init", "--no-license", "--no-readme")
    for i in range(8):
        write(repo / "a.txt", f"{i}\n")          # always 2 bytes
        hit("add", ".")
        hit("commit", "-m", f"v{i}")      # fails with "nothing to commit" if the edit was missed
    log = hit("log", "--oneline")
    assert all(f"v{i}" in log for i in range(8))


def test_many_files(repo):
    """1,500 files in nested folders: add, commit, status, edit, commit — all correct."""
    hit("init", "--no-license", "--no-readme")
    for i in range(1500):
        write(repo / f"pkg{i % 15}" / f"mod{i % 4}" / f"f{i}.txt", f"content {i}\n")
    out = hit("add", ".")
    assert "1501" in out or "1500" in out           # + .hitignore
    hit("commit", "-m", "big")
    assert "Clean working tree" in hit("status")
    assert "Nothing new to stage" in hit("add", ".")   # nothing re-staged

    for i in range(0, 1500, 100):                      # edit 15 files
        write(repo / f"pkg{i % 15}" / f"mod{i % 4}" / f"f{i}.txt", f"edited {i}\n")
    (repo / "pkg0" / "mod0" / "f0.txt").unlink()       # and delete one (it was edited too)
    short = hit("status", "-s")
    assert short.count(" M ") + short.count(" D ") == 15
    out = hit("add", "-A")
    assert "15 files" in out
    hit("commit", "-m", "edits")
    assert "15" in hit("diff", "HEAD~1", "HEAD", "--stat")
    assert "1500 files" in hit("files") or "1500" in hit("files")
    assert "healthy" in hit("fsck").lower()


def test_ref_files_use_lf_line_endings(repo):
    """Git reports CRLF ref files as corrupt; HIT must always write LF."""
    hit("init", "--no-license", "--no-readme")
    write(repo / "a.txt", "a\n")
    hit("add", ".")
    hit("commit", "-m", "x")
    hit("switch", "-c", "feature")
    for rel in ("HEAD", "refs/heads/main", "refs/heads/feature"):
        assert b"\r\n" not in (repo / ".hit" / rel).read_bytes(), rel
